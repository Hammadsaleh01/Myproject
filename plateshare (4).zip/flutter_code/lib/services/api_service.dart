// PlateShare Final Year Project - Flutter API Service
// Recommended File Path: lib/services/api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // Replace with your hosted backend URL, e.g., 'https://your-plateshare-api.com/api'
  // Or 'http://10.0.2.2:3000/api' for Android Emulator local testing
  static const String baseUrl = 'http://10.0.2.2:3000/api';

  static Future<Map<String, String>> _getHeaders() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('plateshare_token');
    
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // --- Authentication ---
  static Future<http.Response> register(Map<String, dynamic> userData) async {
    final url = Uri.parse('$baseUrl/auth/register');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(userData),
    );
    return response;
  }

  static Future<http.Response> login(String email, String password) async {
    final url = Uri.parse('$baseUrl/auth/login');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'email': email,
        'password': password,
      }),
    );
    return response;
  }

  static Future<http.Response> getMe() async {
    final url = Uri.parse('$baseUrl/auth/me');
    final headers = await _getHeaders();
    final response = await http.get(url, headers: headers);
    return response;
  }

  // --- Food Listings (CRUD) ---
  static Future<http.Response> getAllListings() async {
    final url = Uri.parse('$baseUrl/listings');
    final headers = await _getHeaders();
    final response = await http.get(url, headers: headers);
    return response;
  }

  static Future<http.Response> getMyListings() async {
    final url = Uri.parse('$baseUrl/listings/my');
    final headers = await _getHeaders();
    final response = await http.get(url, headers: headers);
    return response;
  }

  static Future<http.Response> createListing(Map<String, dynamic> listingData) async {
    final url = Uri.parse('$baseUrl/listings');
    final headers = await _getHeaders();
    final response = await http.post(
      url,
      headers: headers,
      body: jsonEncode(listingData),
    );
    return response;
  }

  static Future<http.Response> updateListing(String id, Map<String, dynamic> listingData) async {
    final url = Uri.parse('$baseUrl/listings/$id');
    final headers = await _getHeaders();
    final response = await http.put(
      url,
      headers: headers,
      body: jsonEncode(listingData),
    );
    return response;
  }

  static Future<http.Response> deleteListing(String id) async {
    final url = Uri.parse('$baseUrl/listings/$id');
    final headers = await _getHeaders();
    final response = await http.delete(url, headers: headers);
    return response;
  }

  static Future<http.Response> updateListingStatus(String id, String status) async {
    final url = Uri.parse('$baseUrl/listings/$id/status');
    final headers = await _getHeaders();
    final response = await http.patch(
      url,
      headers: headers,
      body: jsonEncode({'status': status}),
    );
    return response;
  }

  // --- Notifications ---
  static Future<http.Response> getNotifications() async {
    final url = Uri.parse('$baseUrl/notifications');
    final headers = await _getHeaders();
    final response = await http.get(url, headers: headers);
    return response;
  }

  static Future<http.Response> markNotificationRead(String id) async {
    final url = Uri.parse('$baseUrl/notifications/$id/read');
    final headers = await _getHeaders();
    final response = await http.patch(url, headers: headers);
    return response;
  }

  static Future<http.Response> markAllNotificationsRead() async {
    final url = Uri.parse('$baseUrl/notifications/read-all');
    final headers = await _getHeaders();
    final response = await http.post(url, headers: headers);
    return response;
  }
}
