import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, 
  MapPin, 
  Building, 
  Utensils, 
  Heart, 
  CheckCircle2, 
  ShieldCheck, 
  Sliders, 
  Sparkles,
  ArrowRight,
  TrendingUp,
  ExternalLink,
  PhoneCall,
  Info
} from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { PublicExplore } from './components/PublicExplore.tsx';
import { PakistanCityExplorer } from './components/PakistanCityExplorer.tsx';
import { AuthModals } from './components/AuthModals.tsx';
import { UserProfileModal } from './components/UserProfileModal.tsx';
import { DemoAccountsBar } from './components/DemoAccountsBar.tsx';
import { 
  RestaurantDashboard, 
  NgoDashboard, 
  DonorDashboard, 
  BeneficiaryDashboard, 
  AdminDashboard 
} from './components/RoleDashboards.tsx';
import { ALL_PAKISTAN_CITIES } from './data/pakistanLocations.ts';
import { api } from './services/api.ts';

function PlateShareMainApp() {
  const { user, selectedCity, setSelectedCity, notifications, markNotifAsRead, markAllNotifsAsRead } = useAuth();

  const [activeNavTab, setActiveNavTab] = useState<string>('home');
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [registerModalOpen, setRegisterModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);

  // Push notification alert toast
  const [toastNotification, setToastNotification] = useState<any | null>(null);

  // Live national impact & directory stats
  const [partners, setPartners] = useState<any[]>([]);

  useEffect(() => {
    // If a new unread notification arrives, show a brief push banner
    if (notifications.length > 0) {
      const latestUnread = notifications.find(n => !n.isRead);
      if (latestUnread) {
        setToastNotification(latestUnread);
        const timer = setTimeout(() => setToastNotification(null), 6000);
        return () => clearTimeout(timer);
      }
    }
  }, [notifications]);

  useEffect(() => {
    // Load organizations directory
    const loadDirectory = async () => {
      try {
        const res = await api.auth.getAllUsers();
        setPartners(res.users || []);
      } catch (err) {
        console.warn('Directory load error:', err);
      }
    };
    loadDirectory();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-indigo-100 selection:text-indigo-900">
      
      {/* 1. TOP RESPONSIVE NAVIGATION BAR */}
      <Navbar
        onOpenLogin={() => setLoginModalOpen(true)}
        onOpenRegister={() => setRegisterModalOpen(true)}
        onOpenProfile={() => setProfileModalOpen(true)}
        activeNavTab={activeNavTab}
        setActiveNavTab={setActiveNavTab}
        onOpenExplore={() => setActiveNavTab('explore')}
      />

      {/* 2. REAL-TIME NOTIFICATION POPUP TOAST */}
      <AnimatePresence>
        {toastNotification && (
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-20 right-4 z-50 w-full max-w-sm bg-slate-900 text-white rounded-2xl shadow-2xl border border-slate-800 p-4 cursor-pointer"
            onClick={() => {
              setActiveNavTab('notifications');
              markNotifAsRead(toastNotification.id);
              setToastNotification(null);
            }}
          >
            <div className="flex items-start gap-3">
              <div className="bg-indigo-500/20 p-2 rounded-xl text-indigo-300 shrink-0">
                <Bell className="w-5 h-5 animate-bounce" />
              </div>
              <div className="flex-1 text-xs">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span>PlateShare Pakistan Alert</span>
                  <span className="bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono">Live</span>
                </div>
                <h5 className="font-bold text-white mt-0.5 text-xs">{toastNotification.title}</h5>
                <p className="text-slate-300 mt-1 leading-snug line-clamp-2">{toastNotification.message}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. LOGGED-IN ROLE BANNER & SHORTCUT BAR */}
      {user && (
        <div className="bg-white border-b border-slate-200/80 shadow-2xs">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-slate-500">Logged in as:</span>
              <span className="font-extrabold text-slate-900">{user.name}</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 uppercase">
                {user.role}
              </span>
              <span className="text-slate-400">•</span>
              <span className="text-slate-600 font-medium">📍 {user.city}, {user.area || 'Pakistan'}</span>
              <span className="text-slate-400">•</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                user.verificationStatus === 'Verified' || user.verificationStatus === 'Approved'
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-amber-100 text-amber-800'
              }`}>
                {user.verificationStatus}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setActiveNavTab('dashboard')}
                className={`px-3 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                  activeNavTab === 'dashboard'
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Open {user.role} Dashboard</span>
              </button>

              <button
                onClick={() => setProfileModalOpen(true)}
                className="px-3 py-1 rounded-lg font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
              >
                Profile &amp; Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. MAIN WORKSPACE / CONTENT CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        
        {/* VIEW 1: Home & Surplus Food Feed */}
        {(activeNavTab === 'home' || activeNavTab === 'food') && (
          <PublicExplore
            onOpenLogin={() => setLoginModalOpen(true)}
            onOpenRegister={() => setRegisterModalOpen(true)}
            onNavigateToTab={setActiveNavTab}
          />
        )}

        {/* VIEW 2: Explore Cities across Pakistan */}
        {activeNavTab === 'explore' && (
          <PakistanCityExplorer onClose={() => setActiveNavTab('home')} />
        )}

        {/* VIEW 3: Role-Specific Authorized Dashboard */}
        {activeNavTab === 'dashboard' && (
          <div className="flex flex-col gap-6">
            {!user ? (
              <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center flex flex-col items-center justify-center gap-3">
                <span className="text-4xl">🔒</span>
                <h3 className="text-lg font-extrabold text-slate-900">Sign In Required</h3>
                <p className="text-xs text-slate-500 max-w-md">
                  Please log in with your authorized PlateShare account to access role-specific workflows (Restaurant food creation, NGO pickups, meal allocation, or Admin moderation).
                </p>
                <button
                  onClick={() => setLoginModalOpen(true)}
                  className="mt-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl text-xs transition shadow-xs cursor-pointer"
                >
                  Log In Now
                </button>
              </div>
            ) : (
              <>
                {user.role === 'Restaurant' && <RestaurantDashboard onRefresh={() => {}} />}
                {user.role === 'NGO' && <NgoDashboard onRefresh={() => {}} />}
                {user.role === 'Donor' && <DonorDashboard />}
                {user.role === 'Beneficiary' && <BeneficiaryDashboard />}
                {user.role === 'Admin' && <AdminDashboard />}
              </>
            )}
          </div>
        )}

        {/* VIEW 4: Verified Organizations Directory */}
        {activeNavTab === 'organizations' && (
          <div className="flex flex-col gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-black text-slate-900 tracking-tight">Verified PlateShare Partners &amp; NGOs</h2>
                <p className="text-xs text-slate-500 mt-1">
                  Browse authorized food rescue organizations, registered community kitchens, and donating restaurants across Pakistan.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500">Filter:</span>
                <select
                  value={selectedCity}
                  onChange={e => setSelectedCity(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                >
                  <option value="All Cities">🇵🇰 All Pakistan</option>
                  {ALL_PAKISTAN_CITIES.map(c => (
                    <option key={c.name} value={c.name}>{c.name} ({c.province})</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {partners
                .filter(p => selectedCity === 'All Cities' || (p.city && p.city.toLowerCase() === selectedCity.toLowerCase()))
                .map(partner => (
                  <div key={partner.id} className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col justify-between gap-3">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          partner.role === 'NGO' ? 'bg-indigo-50 text-indigo-700' :
                          partner.role === 'Restaurant' ? 'bg-emerald-50 text-emerald-700' :
                          'bg-slate-100 text-slate-600'
                        }`}>
                          {partner.role}
                        </span>
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${
                          partner.verificationStatus === 'Verified' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {partner.verificationStatus}
                        </span>
                      </div>

                      <h4 className="font-extrabold text-base text-slate-900 mt-2">{partner.name}</h4>
                      <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {partner.area ? `${partner.area}, ` : ''}{partner.city}, {partner.province || 'Pakistan'}
                      </p>

                      {partner.role === 'NGO' && partner.capacity && (
                        <div className="mt-3 p-2 bg-indigo-50/50 rounded-xl text-[11px] text-indigo-900">
                          <b>Capacity:</b> {partner.capacity} meals/day
                          {partner.registrationNumber && <span className="block font-mono text-[10px] text-slate-500">Reg: {partner.registrationNumber}</span>}
                        </div>
                      )}

                      {partner.role === 'Restaurant' && partner.operatingHours && (
                        <div className="mt-3 p-2 bg-emerald-50/50 rounded-xl text-[11px] text-emerald-900">
                          <b>Operating Hours:</b> {partner.operatingHours}
                        </div>
                      )}
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                      <span>Contact: {partner.phone}</span>
                      <span className="text-emerald-600 font-bold">Active Partner</span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* VIEW 5: National Impact Metrics */}
        {activeNavTab === 'impact' && (
          <div className="flex flex-col gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <h2 className="text-xl font-black text-slate-900 tracking-tight">PlateShare Pakistan Impact Analytics</h2>
              <p className="text-xs text-slate-500 mt-1">Real-time metrics measuring food security, waste reduction, and civic mobilization.</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Meals Redistributed</span>
                <span className="text-3xl font-black text-indigo-600 block mt-1">12,840+</span>
                <span className="text-[11px] text-emerald-600 font-semibold block mt-1">↑ 18% this month</span>
              </div>
              <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">CO2 Emissions Averted</span>
                <span className="text-3xl font-black text-emerald-600 block mt-1">15.4 Tons</span>
                <span className="text-[11px] text-slate-500 font-semibold block mt-1">Landfill diversion</span>
              </div>
              <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Partner Restaurants</span>
                <span className="text-3xl font-black text-slate-900 block mt-1">48</span>
                <span className="text-[11px] text-indigo-600 font-semibold block mt-1">Across 7 cities</span>
              </div>
              <div className="p-5 bg-white rounded-3xl border border-slate-200 shadow-xs text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Verified NGOs</span>
                <span className="text-3xl font-black text-purple-600 block mt-1">32</span>
                <span className="text-[11px] text-slate-500 font-semibold block mt-1">100% vetted</span>
              </div>
            </div>

            {/* City Distribution Summary */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
              <h3 className="font-extrabold text-base text-slate-900 mb-4">Operations by Region</h3>
              <div className="space-y-3">
                {[
                  { city: 'Islamabad / Rawalpindi', meals: 4200, pct: 33 },
                  { city: 'Lahore', meals: 3850, pct: 30 },
                  { city: 'Abbottabad & Hazara', meals: 2450, pct: 19 },
                  { city: 'Peshawar', meals: 1320, pct: 10 },
                  { city: 'Karachi & Other Cities', meals: 1020, pct: 8 }
                ].map(r => (
                  <div key={r.city} className="flex flex-col gap-1">
                    <div className="flex justify-between text-xs font-bold text-slate-700">
                      <span>{r.city}</span>
                      <span>{r.meals.toLocaleString()} meals ({r.pct}%)</span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${r.pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* VIEW 6: Notifications Inbox */}
        {activeNavTab === 'notifications' && (
          <div className="max-w-2xl mx-auto bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-lg font-black text-slate-900 tracking-tight">Notification Center</h3>
                <p className="text-xs text-slate-500">Live operational alerts, food matchings, and handover statuses</p>
              </div>
              {notifications.length > 0 && (
                <button
                  onClick={markAllNotifsAsRead}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                >
                  Mark all as read
                </button>
              )}
            </div>

            {notifications.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs">
                No notifications right now.
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {notifications.map(notif => (
                  <div
                    key={notif.id}
                    onClick={() => markNotifAsRead(notif.id)}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer text-xs flex items-start gap-3 ${
                      notif.isRead
                        ? 'bg-slate-50 border-slate-200 text-slate-600'
                        : 'bg-indigo-50/60 border-indigo-200 text-indigo-950 font-medium'
                    }`}
                  >
                    <div className={`p-1.5 rounded-lg mt-0.5 shrink-0 ${notif.isRead ? 'bg-slate-200 text-slate-600' : 'bg-indigo-600 text-white'}`}>
                      <Bell className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center">
                        <h5 className="font-bold text-xs">{notif.title}</h5>
                        <span className="text-[10px] text-slate-400">
                          {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-[11px] mt-0.5 text-slate-600 leading-relaxed">{notif.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* VIEW 7: How PlateShare Works */}
        {activeNavTab === 'how-it-works' && (
          <div className="flex flex-col gap-8 max-w-4xl mx-auto">
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xs text-center">
              <span className="px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold uppercase tracking-wider">
                End-to-End Food Rescue Protocol
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-3">
                How PlateShare Connects Pakistan
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-2 max-w-2xl mx-auto leading-relaxed">
                From commercial kitchens to vulnerable households: An automated, verified, and dignified food redistribution workflow across Pakistani cities.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold text-base">
                  1
                </div>
                <h4 className="font-extrabold text-base text-slate-900">Surplus Food Posting</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Verified restaurants and banquet halls log available surplus food, specifying meal portions, storage requirements (Hot/Refrigerated), preparation times, and strict pickup deadlines.
                </p>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold text-base">
                  2
                </div>
                <h4 className="font-extrabold text-base text-slate-900">Intelligent Geo-Matching</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  PlateShare calculates distances using the Haversine formula and evaluates NGO verification, vehicle capacity, and localized service areas to match and notify the most suitable local NGOs.
                </p>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold text-base">
                  3
                </div>
                <h4 className="font-extrabold text-base text-slate-900">Secure OTP Handover</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  When an NGO accepts, they schedule a pickup time and generate a 6-digit cryptographic OTP. Upon arrival at the restaurant, the kitchen staff validates the OTP to officially confirm handover.
                </p>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold text-base">
                  4
                </div>
                <h4 className="font-extrabold text-base text-slate-900">Dignified Delivery &amp; Protection</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Food is delivered to digital beneficiaries or NGO-managed offline assistance cases. The system enforces atomic anti-duplicate locks to prevent duplicate distributions within the same period.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 8: Trust & Safety */}
        {activeNavTab === 'trust' && (
          <div className="flex flex-col gap-8 max-w-4xl mx-auto">
            <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white p-6 sm:p-10 rounded-3xl shadow-lg">
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold uppercase tracking-wider border border-emerald-500/30">
                Integrity &amp; Privacy First
              </span>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white mt-3">
                PlateShare Trust &amp; Safety Standard
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-2xl leading-relaxed">
                Protecting donor trust, humanitarian dignity, and food safety across Pakistan through role-based governance, strict verification, and privacy preservation.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-2">
                <span className="text-2xl">🛡️</span>
                <h4 className="font-extrabold text-sm text-slate-900">Vetted Partner Network</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Restaurants and NGOs must complete verification before publishing donations or handling food. Accounts start in <b>Pending Verification</b> until authorized by platform administrators.
                </p>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-2">
                <span className="text-2xl">🔒</span>
                <h4 className="font-extrabold text-sm text-slate-900">Beneficiary Privacy &amp; CNIC Masking</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Vulnerable beneficiaries are never exposed to donors, restaurants, or the public. National CNIC numbers are masked (<code>****-****1234</code>) and accessed strictly on a need-to-know basis.
                </p>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-2">
                <span className="text-2xl">📋</span>
                <h4 className="font-extrabold text-sm text-slate-900">Anti-Duplicate Protection</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Atomic concurrency controls block double food allocations within the active distribution period (Daily/Weekly). Every action is permanently recorded in immutable audit logs.
                </p>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* 5. AUTH MODALS (LOGIN & REGISTER) */}
      <AuthModals
        loginOpen={loginModalOpen}
        registerOpen={registerModalOpen}
        onCloseLogin={() => setLoginModalOpen(false)}
        onCloseRegister={() => setRegisterModalOpen(false)}
        onSwitchToRegister={() => { setLoginModalOpen(false); setRegisterModalOpen(true); }}
        onSwitchToLogin={() => { setRegisterModalOpen(false); setLoginModalOpen(true); }}
      />

      {/* 6. USER PROFILE MODAL */}
      {profileModalOpen && (
        <UserProfileModal onClose={() => setProfileModalOpen(false)} />
      )}

      {/* 7. EVALUATION TEST ACCOUNTS DRAWER */}
      <DemoAccountsBar />

      {/* 8. FOOTER */}
      <footer className="mt-auto bg-white border-t border-slate-200/80 py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <span className="text-xl">🍲</span>
            <div>
              <span className="font-black text-slate-900 block">PlateShare Pakistan</span>
              <span className="text-[10px] text-slate-400 block -mt-0.5">National Food Redistribution Network</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-medium">
            <button onClick={() => setActiveNavTab('home')} className="hover:text-slate-900">Home</button>
            <button onClick={() => setActiveNavTab('explore')} className="hover:text-slate-900">Explore Cities</button>
            <button onClick={() => setActiveNavTab('organizations')} className="hover:text-slate-900">Organizations</button>
            <button onClick={() => setActiveNavTab('impact')} className="hover:text-slate-900">Impact</button>
            <span className="text-slate-300">|</span>
            <span className="text-slate-600">Pakistan Helpline: <b>1129</b> / Citizen Portal Integration</span>
          </div>

          <div className="text-[10px] text-slate-400">
            © 2026 PlateShare Pakistan. Secure Role-Based Redistribution Platform.
          </div>
        </div>
      </footer>

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <PlateShareMainApp />
    </AuthProvider>
  );
}
