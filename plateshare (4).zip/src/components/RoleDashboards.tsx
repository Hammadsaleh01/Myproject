import React, { useState, useEffect } from 'react';
import { 
  PlusCircle, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Users, 
  Utensils, 
  DollarSign, 
  Sliders, 
  AlertTriangle, 
  CheckCircle2, 
  RefreshCw,
  Search,
  Check,
  ChevronRight,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { useAuth, FoodListing, User } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { PAKISTAN_PROVINCES, ALL_PAKISTAN_CITIES, getCityDetails } from '../data/pakistanLocations.ts';

// ----------------------------------------------------------------------
// RESTAURANT DASHBOARD
// ----------------------------------------------------------------------
export const RestaurantDashboard: React.FC<{ onRefresh: () => void }> = ({ onRefresh }) => {
  const { user, selectedCity } = useAuth();
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [myListings, setMyListings] = useState<FoodListing[]>([]);
  const [loading, setLoading] = useState(false);
  const [verifyOtpListing, setVerifyOtpListing] = useState<FoodListing | null>(null);
  const [otpInput, setOtpInput] = useState('');
  const [verifying, setVerifying] = useState(false);

  // Form states
  const [foodName, setFoodName] = useState('');
  const [foodCategory, setFoodCategory] = useState('Biryani & Rice');
  const [quantity, setQuantity] = useState('30');
  const [unit, setUnit] = useState<'meals' | 'kg' | 'packs'>('meals');
  const [description, setDescription] = useState('');
  const [pickupDeadline, setPickupDeadline] = useState('9:00 PM Today');
  const [storageCondition, setStorageCondition] = useState<'Hot/Insulated' | 'Refrigerated' | 'Ambient'>('Hot/Insulated');
  const [formCity, setFormCity] = useState(user?.city || 'Lahore');
  const [formArea, setFormArea] = useState(user?.area || 'Gulberg');
  const [pickupAddress, setPickupAddress] = useState(user?.address || 'Main Commercial Area');
  const [submitting, setSubmitting] = useState(false);

  const loadListings = async () => {
    setLoading(true);
    try {
      const res = await api.listings.getMyListings();
      setMyListings(res.listings || []);
    } catch (err) {
      console.warn('Load my listings error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadListings();
  }, [user]);

  const handleCreateDonation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodName || !quantity) return;
    setSubmitting(true);
    try {
      const res = await api.listings.create({
        foodName,
        foodCategory,
        quantity: Number(quantity),
        unit,
        description,
        preparationTime: 'Prepared recently today',
        availableTime: 'Immediately',
        pickupDeadline,
        storageCondition,
        city: formCity,
        area: formArea,
        pickupAddress
      });
      alert(`Donation listed! Matched with ${res.matchedNgos?.length || 0} verified NGOs in ${formCity}.`);
      setShowCreateModal(false);
      setFoodName('');
      setDescription('');
      loadListings();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyOtpListing || !otpInput) return;
    setVerifying(true);
    try {
      await api.listings.verifyPickupOtp(verifyOtpListing.id, otpInput);
      alert('Pickup verified successfully! Food marked as Picked_Up.');
      setVerifyOtpListing(null);
      setOtpInput('');
      loadListings();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setVerifying(false);
    }
  };

  const isVerified = user?.verificationStatus === 'Verified' || user?.verificationStatus === 'Approved';

  return (
    <div className="flex flex-col gap-6">
      
      {/* Top Banner & Stats */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-slate-900 tracking-tight">{user?.name}</h2>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
              isVerified ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200'
            }`}>
              {user?.verificationStatus}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            📍 Operating in <b>{user?.city}</b> • Food Categories: {user?.foodCategories?.join(', ') || 'Hot Cooked Meals'}
          </p>
        </div>

        <button
          onClick={() => {
            if (!isVerified) {
              alert('Your restaurant account is pending PlateShare verification. Only verified restaurants can create donations.');
              return;
            }
            setShowCreateModal(true);
          }}
          className="px-5 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition flex items-center justify-center gap-2"
        >
          <PlusCircle className="w-4 h-4" /> Post Surplus Food Donation
        </button>
      </div>

      {!isVerified && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-800 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <b>Verification in Progress:</b> PlateShare administrators verify every restaurant's hygiene standards and physical address before authorizing surplus listings. You will receive an alert once approved.
          </div>
        </div>
      )}

      {/* Donations List */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-extrabold text-slate-900">My Restaurant Food Donations</h3>
            <span className="text-xs text-slate-400">Manage pickup schedules and verify handover OTP codes</span>
          </div>
          <button onClick={loadListings} className="text-xs font-bold text-indigo-600 flex items-center gap-1 hover:underline">
            <RefreshCw className="w-3.5 h-3.5" /> Refresh
          </button>
        </div>

        {loading ? (
          <div className="py-12 text-center text-xs text-slate-400">Loading listings...</div>
        ) : myListings.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            No donations posted yet. Click "Post Surplus Food Donation" above.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {myListings.map(item => (
              <div key={item.id} className="p-4 rounded-2xl border border-slate-200 hover:border-slate-300 transition flex flex-col justify-between gap-3">
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-indigo-600 uppercase">{item.foodCategory}</span>
                      <h4 className="font-extrabold text-sm text-slate-900 mt-0.5">{item.foodName}</h4>
                      <p className="text-xs text-slate-500 mt-1">{item.quantity} {item.unit} • {item.area}, {item.city}</p>
                    </div>
                    <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase ${
                      item.status === 'Available' ? 'bg-emerald-50 text-emerald-700' :
                      item.status === 'Accepted' ? 'bg-indigo-50 text-indigo-700' :
                      item.status === 'Pickup_Scheduled' ? 'bg-amber-50 text-amber-700' :
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {item.status}
                    </span>
                  </div>

                  {item.claimedByNgoName && (
                    <div className="mt-2.5 p-2.5 bg-indigo-50/60 rounded-xl text-xs text-slate-700">
                      <b>Claimed by:</b> {item.claimedByNgoName}
                      {item.pickupScheduledTime && (
                        <div className="text-[11px] text-indigo-700 font-semibold mt-0.5">
                          Pickup Time: {new Date(item.pickupScheduledTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Handover OTP Verification Button */}
                {item.status === 'Pickup_Scheduled' && (
                  <button
                    onClick={() => setVerifyOtpListing(item)}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-xl text-xs transition"
                  >
                    Verify NGO Pickup OTP Handover
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* CREATE DONATION MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl p-6 border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-extrabold text-base text-slate-900">Post Surplus Food Donation</h3>
              <button onClick={() => setShowCreateModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handleCreateDonation} className="flex flex-col gap-3 text-xs">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Food Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Chicken Biryani & Roghani Naan"
                  value={foodName}
                  onChange={e => setFoodName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Category</label>
                  <select
                    value={foodCategory}
                    onChange={e => setFoodCategory(e.target.value)}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    <option value="Biryani & Rice">Biryani &amp; Rice</option>
                    <option value="Cooked Meals">Cooked Meals</option>
                    <option value="Bakery">Bakery</option>
                    <option value="Fresh Bread">Fresh Bread</option>
                    <option value="Dry Ration">Dry Ration</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Quantity</label>
                  <div className="flex gap-1">
                    <input
                      type="number"
                      required
                      value={quantity}
                      onChange={e => setQuantity(e.target.value)}
                      className="w-2/3 px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                    />
                    <select
                      value={unit}
                      onChange={e => setUnit(e.target.value as any)}
                      className="w-1/3 px-1 py-2 bg-slate-50 border border-slate-200 rounded-xl text-[10px]"
                    >
                      <option value="meals">meals</option>
                      <option value="kg">kg</option>
                      <option value="packs">packs</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">City in Pakistan</label>
                  <select
                    value={formCity}
                    onChange={e => setFormCity(e.target.value)}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {ALL_PAKISTAN_CITIES.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Pickup Deadline</label>
                  <input
                    type="text"
                    required
                    value={pickupDeadline}
                    onChange={e => setPickupDeadline(e.target.value)}
                    placeholder="9:00 PM Today"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-rose-600"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Description / Safety Notes</label>
                <textarea
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Sealed containers, stored hot, untouched buffet surplus."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl h-16 resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-2xl text-xs transition shadow-xs mt-2"
              >
                {submitting ? 'Publishing...' : 'Publish Surplus Food & Notify Local NGOs'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* VERIFY OTP MODAL */}
      {verifyOtpListing && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl p-6 border border-slate-200">
            <h4 className="font-extrabold text-sm text-slate-900 mb-1">Verify Handover OTP</h4>
            <p className="text-xs text-slate-500 mb-4">
              Ask NGO driver for their 6-digit verification OTP to confirm food handover for {verifyOtpListing.foodName}.
            </p>
            <form onSubmit={handleVerifyOtp} className="flex flex-col gap-3">
              <input
                type="text"
                required
                maxLength={6}
                value={otpInput}
                onChange={e => setOtpInput(e.target.value)}
                placeholder="e.g. 849201"
                className="w-full text-center text-xl font-mono font-black px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
              <button
                type="submit"
                disabled={verifying}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl text-xs transition"
              >
                {verifying ? 'Verifying...' : 'Confirm Handover (Mark Picked_Up)'}
              </button>
              <button type="button" onClick={() => setVerifyOtpListing(null)} className="text-xs text-slate-400 font-bold">
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

// ----------------------------------------------------------------------
// NGO DASHBOARD
// ----------------------------------------------------------------------
export const NgoDashboard: React.FC<{ onRefresh: () => void }> = ({ onRefresh }) => {
  const { user, selectedCity } = useAuth();
  const [activeTab, setActiveTab] = useState<'available' | 'pickups' | 'needy' | 'allocate'>('available');
  const [availableListings, setAvailableListings] = useState<FoodListing[]>([]);
  const [myPickups, setMyPickups] = useState<FoodListing[]>([]);
  const [needyPeople, setNeedyPeople] = useState<any[]>([]);
  const [distributions, setDistributions] = useState<any[]>([]);

  // Offline beneficiary form
  const [needyName, setNeedyName] = useState('');
  const [needyCnic, setNeedyCnic] = useState('');
  const [needyPhone, setNeedyPhone] = useState('');
  const [needyArea, setNeedyArea] = useState('Central');
  const [needySize, setNeedySize] = useState('6');

  // Allocation form state
  const [allocDonationId, setAllocDonationId] = useState('');
  const [allocBeneficiaryCnic, setAllocBeneficiaryCnic] = useState('');
  const [allocQty, setAllocQty] = useState('5');
  const [allocError, setAllocError] = useState('');

  const loadNgoData = async () => {
    try {
      const [listingsRes, needyRes, distRes] = await Promise.all([
        api.listings.getAll({ city: selectedCity !== 'All Cities' ? selectedCity : undefined }),
        api.assistance.getAll(selectedCity !== 'All Cities' ? selectedCity : undefined),
        api.needy.getDistributions(selectedCity !== 'All Cities' ? selectedCity : undefined)
      ]);
      const all = listingsRes.listings || [];
      setAvailableListings(all.filter((l: FoodListing) => l.status === 'Available' || l.status === 'Matched'));
      setMyPickups(all.filter((l: FoodListing) => l.claimedByNgoId === user?.id));
      setNeedyPeople(needyRes.assistanceCases || needyRes.needyPeople || []);
      setDistributions(distRes.distributions || []);
    } catch (err) {
      console.warn('Load NGO data error:', err);
    }
  };

  useEffect(() => {
    loadNgoData();
  }, [user, selectedCity]);

  const handleClaim = async (id: string) => {
    try {
      await api.listings.acceptListing(id);
      alert('Donation claimed! Now schedule pickup.');
      loadNgoData();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleSchedulePickup = async (id: string) => {
    const time = prompt('Enter Pickup Time (e.g. 5:30 PM Today):', '5:30 PM Today');
    if (!time) return;
    try {
      const res = await api.listings.schedulePickup(id, time);
      alert(`Pickup scheduled! Your secure handover OTP is: ${res.otp}. Present this to the restaurant.`);
      loadNgoData();
      onRefresh();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleRegisterNeedy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!needyName || !needyCnic) return;
    try {
      await api.assistance.register({
        name: needyName,
        cnic: needyCnic,
        phone: needyPhone,
        city: user?.city,
        area: needyArea,
        householdSize: Number(needySize),
        urgency: 'High'
      });
      alert(`Assistance case for ${needyName} registered successfully!`);
      setNeedyName('');
      setNeedyCnic('');
      setNeedyPhone('');
      loadNgoData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleAllocate = async (e: React.FormEvent) => {
    e.preventDefault();
    setAllocError('');
    if (!allocDonationId || !allocBeneficiaryCnic) {
      setAllocError('Please select both a donation and a beneficiary.');
      return;
    }
    const ben = needyPeople.find(p => p.cnic === allocBeneficiaryCnic);
    try {
      const res = await api.allocations.create({
        donationId: allocDonationId,
        beneficiaryId: ben?.id || `ben-${Date.now()}`,
        beneficiaryName: ben?.name || 'Registered Beneficiary',
        beneficiaryCnic: allocBeneficiaryCnic,
        quantity: Number(allocQty),
        city: user?.city
      });
      alert(`Food allocated successfully! OTP code: ${res.allocation.otpCode}. Rate limit verified.`);
      loadNgoData();
    } catch (err: any) {
      setAllocError(err.message);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* NGO Hub Navigation */}
      <div className="flex border-b border-slate-200 gap-4 text-xs font-bold text-slate-500 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('available')}
          className={`py-2.5 border-b-2 transition shrink-0 ${activeTab === 'available' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-800'}`}
        >
          Available Surplus Food ({availableListings.length})
        </button>
        <button
          onClick={() => setActiveTab('pickups')}
          className={`py-2.5 border-b-2 transition shrink-0 ${activeTab === 'pickups' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-800'}`}
        >
          My Scheduled Pickups ({myPickups.length})
        </button>
        <button
          onClick={() => setActiveTab('needy')}
          className={`py-2.5 border-b-2 transition shrink-0 ${activeTab === 'needy' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-800'}`}
        >
          Beneficiary Registry ({needyPeople.length})
        </button>
        <button
          onClick={() => setActiveTab('allocate')}
          className={`py-2.5 border-b-2 transition shrink-0 ${activeTab === 'allocate' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-800'}`}
        >
          Allocate Food (Rate-Limited)
        </button>
      </div>

      {/* TAB 1: Available Surplus Food */}
      {activeTab === 'available' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {availableListings.length === 0 ? (
            <div className="col-span-full py-12 text-center text-slate-400 text-xs bg-white rounded-3xl border border-dashed border-slate-200">
              No surplus food listings available in {selectedCity} currently.
            </div>
          ) : (
            availableListings.map(item => (
              <div key={item.id} className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs flex flex-col justify-between">
                <div className="p-4">
                  <span className="text-[10px] font-bold text-indigo-600 uppercase">{item.donorName} • {item.city}</span>
                  <h4 className="font-extrabold text-base text-slate-900 mt-0.5">{item.foodName}</h4>
                  <p className="text-xs text-slate-500 mt-1">{item.description}</p>
                  <div className="mt-3 flex items-center justify-between text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-150">
                    <span><b>Qty:</b> {item.quantity} {item.unit}</span>
                    <span className="text-rose-600 font-bold">Expires: {item.pickupDeadline}</span>
                  </div>
                </div>
                <div className="p-4 pt-0">
                  <button
                    onClick={() => handleClaim(item.id)}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 rounded-xl text-xs transition"
                  >
                    Accept &amp; Claim Donation
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 2: Scheduled Pickups */}
      {activeTab === 'pickups' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {myPickups.map(item => (
            <div key={item.id} className="bg-white p-4 rounded-3xl border border-slate-200 flex flex-col justify-between gap-3 shadow-xs">
              <div>
                <span className="text-[10px] font-bold text-indigo-600 uppercase">{item.status}</span>
                <h4 className="font-extrabold text-base text-slate-900">{item.foodName}</h4>
                <p className="text-xs text-slate-500">{item.pickupAddress}, {item.city}</p>
                {item.pickupOtp && (
                  <div className="mt-2 p-2 bg-amber-50 rounded-xl border border-amber-200 text-xs">
                    <b>Handover OTP:</b> <span className="font-mono text-base font-black text-amber-900">{item.pickupOtp}</span>
                  </div>
                )}
              </div>
              {item.status === 'Accepted' && (
                <button
                  onClick={() => handleSchedulePickup(item.id)}
                  className="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-2 rounded-xl text-xs transition"
                >
                  Schedule Pickup Time &amp; Generate OTP
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: Beneficiary Registry */}
      {activeTab === 'needy' && (
        <div className="flex flex-col gap-4">
          <form onSubmit={handleRegisterNeedy} className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-3">
            <span className="text-xs font-bold text-indigo-700 uppercase">Register Beneficiary (No Smartphone Needed)</span>
            <div className="grid grid-cols-3 gap-3 text-xs">
              <input type="text" required placeholder="Full Name" value={needyName} onChange={e => setNeedyName(e.target.value)} className="px-3 py-2 bg-slate-50 border rounded-xl" />
              <input type="text" required placeholder="CNIC: 13101-xxxxxxx-x" value={needyCnic} onChange={e => setNeedyCnic(e.target.value)} className="px-3 py-2 bg-slate-50 border rounded-xl font-mono" />
              <input type="tel" placeholder="Phone (Optional)" value={needyPhone} onChange={e => setNeedyPhone(e.target.value)} className="px-3 py-2 bg-slate-50 border rounded-xl" />
            </div>
            <button type="submit" className="w-full bg-indigo-600 text-white font-bold py-2.5 rounded-xl text-xs hover:bg-indigo-700 transition">
              Add Beneficiary to Registry
            </button>
          </form>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {needyPeople.map(p => (
              <div key={p.id} className="p-3 bg-white border border-slate-200 rounded-2xl flex justify-between items-center text-xs">
                <div>
                  <h5 className="font-bold text-slate-800">{p.name}</h5>
                  <span className="text-[10px] text-slate-400 font-mono block">CNIC: {p.cnic} • {p.city}</span>
                </div>
                <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700">Verified</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: Allocation with Rate Limit Check */}
      {activeTab === 'allocate' && (
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs max-w-lg">
          <h4 className="font-extrabold text-sm text-slate-900 mb-1">Allocate Food to Beneficiary</h4>
          <p className="text-xs text-slate-500 mb-4">
            System enforces the strict anti-duplicate rule: A beneficiary cannot receive food twice during the active distribution period.
          </p>

          {allocError && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs mb-3 font-semibold">
              ⚠️ {allocError}
            </div>
          )}

          <form onSubmit={handleAllocate} className="flex flex-col gap-3 text-xs">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase">Available Donation</label>
              <select value={allocDonationId} onChange={e => setAllocDonationId(e.target.value)} className="w-full px-3 py-2 bg-slate-50 border rounded-xl">
                <option value="">-- Choose Collected Food --</option>
                {myPickups.map(p => (
                  <option key={p.id} value={p.id}>{p.foodName} ({p.remainingQuantity || p.quantity} meals available)</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase">Beneficiary (CNIC)</label>
              <select value={allocBeneficiaryCnic} onChange={e => setAllocBeneficiaryCnic(e.target.value)} className="w-full px-3 py-2 bg-slate-50 border rounded-xl">
                <option value="">-- Choose Beneficiary --</option>
                {needyPeople.map(p => (
                  <option key={p.id} value={p.cnic}>{p.name} ({p.cnic})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase">Meals Allocated</label>
              <input type="number" min={1} value={allocQty} onChange={e => setAllocQty(e.target.value)} className="w-full px-3 py-2 bg-slate-50 border rounded-xl font-bold" />
            </div>

            <button type="submit" className="w-full bg-indigo-600 text-white font-bold py-2.5 rounded-xl text-xs hover:bg-indigo-700 transition">
              Allocate Food &amp; Enforce Rate-Limit
            </button>
          </form>
        </div>
      )}

    </div>
  );
};

// ----------------------------------------------------------------------
// DONOR DASHBOARD
// ----------------------------------------------------------------------
export const DonorDashboard: React.FC = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<any>(null);
  const [amount, setAmount] = useState('5000');
  const [submitting, setSubmitting] = useState(false);

  const loadDonorData = async () => {
    try {
      const res = await api.sponsorships.getMyStats();
      setStats(res);
    } catch (err) {
      console.warn('Load donor data error:', err);
    }
  };

  useEffect(() => {
    loadDonorData();
  }, []);

  const handleSponsor = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.sponsorships.create({ amountPkr: Number(amount) });
      alert(`Thank you for your generous contribution of PKR ${Number(amount).toLocaleString()}! Real meal distributions sponsored.`);
      loadDonorData();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">Donor Impact Hub</h2>
          <p className="text-xs text-slate-500 mt-1">Track actual verified meals funded across Pakistani communities.</p>
        </div>
        <div className="flex gap-4 text-center">
          <div className="p-3 bg-indigo-50 rounded-2xl border border-indigo-100 min-w-[110px]">
            <span className="text-[10px] font-bold text-slate-400 uppercase block">Total Contributed</span>
            <span className="text-base font-black text-indigo-700">PKR {stats?.totalDonatedPkr?.toLocaleString() || '0'}</span>
          </div>
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-100 min-w-[110px]">
            <span className="text-[10px] font-bold text-slate-400 uppercase block">Meals Sponsored</span>
            <span className="text-base font-black text-emerald-600">{stats?.totalMealsSponsored || 0} Meals</span>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs max-w-md">
        <h4 className="font-extrabold text-sm text-slate-900 mb-2">Sponsor Fresh Community Meals</h4>
        <p className="text-xs text-slate-500 mb-4">PKR 100 sponsors 1 complete nutritious meal package for an eligible family.</p>
        <form onSubmit={handleSponsor} className="flex flex-col gap-3 text-xs">
          <input type="number" required value={amount} onChange={e => setAmount(e.target.value)} className="w-full px-3 py-2 bg-slate-50 border rounded-xl font-bold font-mono text-base" />
          <button type="submit" disabled={submitting} className="w-full bg-indigo-600 text-white font-bold py-2.5 rounded-xl text-xs hover:bg-indigo-700 transition">
            {submitting ? 'Processing...' : `Sponsor ${Math.floor(Number(amount || 0) / 100)} Meals`}
          </button>
        </form>
      </div>
    </div>
  );
};

// ----------------------------------------------------------------------
// BENEFICIARY DASHBOARD
// ----------------------------------------------------------------------
export const BeneficiaryDashboard: React.FC = () => {
  const { user } = useAuth();
  const [allocations, setAllocations] = useState<any[]>([]);

  const loadAllocations = async () => {
    try {
      const res = await api.allocations.getMyAllocations();
      setAllocations(res.allocations || []);
    } catch (err) {
      console.warn('Load allocations error:', err);
    }
  };

  useEffect(() => {
    loadAllocations();
  }, []);

  const handleConfirm = async (id: string) => {
    const otp = prompt('Enter your 4-digit confirmation OTP:');
    if (!otp) return;
    try {
      await api.allocations.confirm({ allocationId: id, verificationMethod: 'OTP', otp });
      alert('Food receipt confirmed!');
      loadAllocations();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <h2 className="text-xl font-black text-slate-900 tracking-tight">Food Assistance Status</h2>
        <p className="text-xs text-slate-500 mt-1">Beneficiary Account: <b>{user?.name}</b> • {user?.city}</p>
      </div>

      <div className="flex flex-col gap-3">
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Food Packages</h4>
        {allocations.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs bg-white rounded-3xl border border-dashed border-slate-200">
            No active allocations currently. When your local NGO prepares a package, your collection OTP will appear here.
          </div>
        ) : (
          allocations.map(a => (
            <div key={a.id} className="p-4 bg-white rounded-3xl border border-slate-200 shadow-xs flex justify-between items-center text-xs">
              <div>
                <span className="text-[10px] font-bold text-indigo-600 uppercase">{a.status}</span>
                <h4 className="font-extrabold text-sm text-slate-900">{a.foodName}</h4>
                <p className="text-slate-500">{a.quantity} meals from {a.ngoName}</p>
                <span className="font-mono font-black text-indigo-700 block mt-1">OTP: {a.otpCode}</span>
              </div>
              {a.status === 'Active' && (
                <button onClick={() => handleConfirm(a.id)} className="bg-indigo-600 text-white font-bold px-4 py-2 rounded-xl">
                  Confirm Receipt
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

// ----------------------------------------------------------------------
// ADMIN CONSOLE
// ----------------------------------------------------------------------
export const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [filterCity, setFilterCity] = useState('All Cities');
  const [periodMode, setPeriodMode] = useState<'Daily' | 'Weekly' | 'Custom'>('Daily');

  const loadAdmin = async () => {
    try {
      const [statsRes, usersRes] = await Promise.all([
        api.admin.getStats({ city: filterCity !== 'All Cities' ? filterCity : undefined }),
        api.auth.getAllUsers({ city: filterCity !== 'All Cities' ? filterCity : undefined })
      ]);
      setStats(statsRes.stats);
      setPeriodMode(statsRes.settings?.distributionPeriodMode || 'Daily');
      setUsers(usersRes.users || []);
    } catch (err) {
      console.warn('Load admin error:', err);
    }
  };

  useEffect(() => {
    loadAdmin();
  }, [filterCity]);

  const handleVerify = async (userId: string, role: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'Verified' ? 'Suspended' : 'Verified';
    try {
      if (role === 'Restaurant') await api.auth.verifyRestaurant(userId, nextStatus);
      if (role === 'NGO') await api.auth.verifyNgo(userId, nextStatus);
      if (role === 'Beneficiary') await api.auth.verifyBeneficiary(userId, nextStatus);
      loadAdmin();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleUpdatePeriod = async (mode: 'Daily' | 'Weekly' | 'Custom') => {
    try {
      await api.admin.updateSettings({ distributionPeriodMode: mode });
      setPeriodMode(mode);
      alert(`Platform distribution period rule set to ${mode}. Rate limiting updated.`);
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* City Scope Filter */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">National Operations Console</h2>
          <span className="text-xs text-slate-500">Filter platform surveillance by Pakistani city</span>
        </div>
        <select
          value={filterCity}
          onChange={e => setFilterCity(e.target.value)}
          className="px-3 py-2 bg-slate-50 border rounded-xl text-xs font-bold"
        >
          <option value="All Cities">🇵🇰 All Pakistan</option>
          {ALL_PAKISTAN_CITIES.map(c => <option key={c.name} value={c.name}>{c.name} ({c.province})</option>)}
        </select>
      </div>

      {/* KPI Cards */}
      {stats && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Restaurants</span>
            <span className="text-xl font-black text-slate-900 block mt-1">{stats.verifiedRestaurantsCount} / {stats.restaurantsCount}</span>
          </div>
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Verified NGOs</span>
            <span className="text-xl font-black text-indigo-700 block mt-1">{stats.verifiedNgosCount} / {stats.ngosCount}</span>
          </div>
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Meals Distributed</span>
            <span className="text-xl font-black text-emerald-600 block mt-1">{stats.totalMealsDistributed}</span>
          </div>
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Total Beneficiaries</span>
            <span className="text-xl font-black text-slate-900 block mt-1">{stats.totalBeneficiariesCount}</span>
          </div>
        </div>
      )}

      {/* Rule Configurator */}
      <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-3xl flex items-center justify-between gap-4 text-xs">
        <div>
          <b className="text-indigo-900">Distribution Period Rule:</b>
          <p className="text-slate-600 text-[11px]">Enforce anti-duplicate food allocation restriction per period.</p>
        </div>
        <div className="flex gap-1">
          {(['Daily', 'Weekly', 'Custom'] as const).map(m => (
            <button
              key={m}
              onClick={() => handleUpdatePeriod(m)}
              className={`px-3 py-1.5 rounded-lg font-bold text-xs ${periodMode === m ? 'bg-indigo-600 text-white' : 'bg-white text-slate-700 border'}`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      {/* Verification Approvals */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col gap-3">
        <h4 className="font-extrabold text-sm text-slate-900">Account Verifications</h4>
        <div className="flex flex-col gap-2">
          {users.map(u => (
            <div key={u.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center text-xs">
              <div>
                <span className="font-bold text-slate-800">{u.name}</span>
                <span className="text-slate-400 block text-[10px] font-mono">{u.email} • {u.city} • {u.role}</span>
              </div>
              {(u.role === 'Restaurant' || u.role === 'NGO') && (
                <button
                  onClick={() => handleVerify(u.id, u.role, u.verificationStatus)}
                  className={`px-3 py-1 rounded-lg font-bold text-xs ${u.verificationStatus === 'Verified' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}
                >
                  {u.verificationStatus === 'Verified' ? 'Verified ✓' : 'Approve'}
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
