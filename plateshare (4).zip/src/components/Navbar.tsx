import React, { useState } from 'react';
import { 
  MapPin, 
  Bell, 
  User as UserIcon, 
  LogOut, 
  ChevronDown, 
  ShieldCheck, 
  Sliders, 
  FileText, 
  Heart,
  Globe,
  Compass,
  Search
} from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { ALL_PAKISTAN_CITIES } from '../data/pakistanLocations.ts';

interface NavbarProps {
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onOpenProfile: () => void;
  activeNavTab: string;
  setActiveNavTab: (tab: string) => void;
  onOpenExplore: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenLogin,
  onOpenRegister,
  onOpenProfile,
  activeNavTab,
  setActiveNavTab,
  onOpenExplore
}) => {
  const { user, selectedCity, setSelectedCity, unreadCount, logout } = useAuth();
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [cityDropdownOpen, setCityDropdownOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        
        {/* Brand & City Selector */}
        <div className="flex items-center gap-3 md:gap-5">
          <button 
            onClick={() => setActiveNavTab('home')} 
            className="flex items-center gap-2.5 focus:outline-none group text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black text-xl shadow-xs group-hover:scale-105 transition">
              🍲
            </div>
            <div>
              <span className="text-base font-black text-slate-900 tracking-tight block">PlateShare</span>
              <span className="text-[10px] font-semibold text-slate-400 block -mt-1">Pakistan Food Network</span>
            </div>
          </button>

          {/* Location Selector Pill */}
          <div className="relative">
            <button
              onClick={() => setCityDropdownOpen(!cityDropdownOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200/80 text-xs font-semibold text-slate-700 transition border border-slate-200"
            >
              <MapPin className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span className="max-w-[110px] sm:max-w-none truncate">{selectedCity}</span>
              <ChevronDown className="w-3 h-3 text-slate-400 ml-0.5" />
            </button>

            {cityDropdownOpen && (
              <div className="absolute left-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 max-h-72 overflow-y-auto">
                <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                  Select Focus City
                </div>
                <button
                  onClick={() => { setSelectedCity('All Cities'); setCityDropdownOpen(false); }}
                  className={`w-full text-left px-3.5 py-2 text-xs font-bold transition flex items-center justify-between ${selectedCity === 'All Cities' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-700 hover:bg-slate-50'}`}
                >
                  <span>🇵🇰 All Pakistan</span>
                  {selectedCity === 'All Cities' && <span className="text-[10px]">✓</span>}
                </button>
                {ALL_PAKISTAN_CITIES.map(c => (
                  <button
                    key={c.name}
                    onClick={() => { setSelectedCity(c.name); setCityDropdownOpen(false); }}
                    className={`w-full text-left px-3.5 py-1.5 text-xs transition flex items-center justify-between ${selectedCity === c.name ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-600 hover:bg-slate-50'}`}
                  >
                    <span>{c.name}</span>
                    <span className="text-[10px] text-slate-400">{c.province}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Center Public Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 text-xs font-bold text-slate-600">
          <button
            onClick={() => setActiveNavTab('home')}
            className={`px-3 py-1.5 rounded-lg transition ${activeNavTab === 'home' ? 'text-indigo-600 bg-indigo-50' : 'hover:text-slate-900'}`}
          >
            Home
          </button>
          <button
            onClick={onOpenExplore}
            className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1 ${activeNavTab === 'explore' ? 'text-indigo-600 bg-indigo-50' : 'hover:text-slate-900'}`}
          >
            <Compass className="w-3.5 h-3.5 text-indigo-500" /> Explore Cities
          </button>
          <button
            onClick={() => setActiveNavTab('food')}
            className={`px-3 py-1.5 rounded-lg transition ${activeNavTab === 'food' ? 'text-indigo-600 bg-indigo-50' : 'hover:text-slate-900'}`}
          >
            Surplus Food
          </button>
          <button
            onClick={() => setActiveNavTab('impact')}
            className={`px-3 py-1.5 rounded-lg transition ${activeNavTab === 'impact' ? 'text-indigo-600 bg-indigo-50' : 'hover:text-slate-900'}`}
          >
            National Impact
          </button>
          <button
            onClick={() => setActiveNavTab('organizations')}
            className={`px-3 py-1.5 rounded-lg transition ${activeNavTab === 'organizations' ? 'text-indigo-600 bg-indigo-50' : 'hover:text-slate-900'}`}
          >
            NGOs &amp; Partners
          </button>
          <button
            onClick={() => setActiveNavTab('how-it-works')}
            className={`px-3 py-1.5 rounded-lg transition ${activeNavTab === 'how-it-works' ? 'text-indigo-600 bg-indigo-50' : 'hover:text-slate-900'}`}
          >
            How It Works
          </button>
          <button
            onClick={() => setActiveNavTab('trust')}
            className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1 ${activeNavTab === 'trust' ? 'text-emerald-700 bg-emerald-50' : 'hover:text-slate-900'}`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Trust &amp; Safety
          </button>
        </nav>

        {/* Right Section: Auth & Profile */}
        <div className="flex items-center gap-2.5">
          {user ? (
            <>
              {/* Notifications Icon */}
              <button
                onClick={() => setActiveNavTab('notifications')}
                className="relative p-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition"
                title="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-rose-600 text-white text-[9px] font-black flex items-center justify-center border-2 border-white">
                    {unreadCount}
                  </span>
                )}
              </button>

              {/* User Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 pr-2.5 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition"
                >
                  <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs uppercase shadow-xs">
                    {user.name.charAt(0)}
                  </div>
                  <div className="text-left hidden sm:block">
                    <span className="text-xs font-bold text-slate-800 leading-tight block truncate max-w-[120px]">
                      {user.name}
                    </span>
                    <span className="text-[10px] font-semibold text-indigo-600 uppercase block -mt-0.5">
                      {user.role}
                    </span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {profileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-60 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 text-xs">
                    <div className="px-3.5 py-2 border-b border-slate-100">
                      <span className="font-extrabold text-slate-900 block truncate">{user.name}</span>
                      <span className="text-[11px] text-slate-400 font-mono block truncate">{user.email}</span>
                      <div className="mt-1 flex items-center gap-1.5">
                        <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 uppercase">
                          {user.role}
                        </span>
                        <span className="text-[9px] text-slate-500 font-medium">📍 {user.city}</span>
                      </div>
                    </div>

                    <div className="py-1">
                      <button
                        onClick={() => { onOpenProfile(); setProfileDropdownOpen(false); }}
                        className="w-full text-left px-3.5 py-2 hover:bg-slate-50 text-slate-700 font-semibold flex items-center gap-2"
                      >
                        <UserIcon className="w-4 h-4 text-slate-400" /> My Profile &amp; Settings
                      </button>

                      <button
                        onClick={() => { setActiveNavTab('dashboard'); setProfileDropdownOpen(false); }}
                        className="w-full text-left px-3.5 py-2 hover:bg-slate-50 text-slate-700 font-semibold flex items-center gap-2"
                      >
                        <Sliders className="w-4 h-4 text-indigo-600" /> {user.role} Dashboard
                      </button>
                    </div>

                    <div className="border-t border-slate-100 pt-1">
                      <button
                        onClick={() => { logout(); setProfileDropdownOpen(false); }}
                        className="w-full text-left px-3.5 py-2 hover:bg-rose-50 text-rose-600 font-bold flex items-center gap-2"
                      >
                        <LogOut className="w-4 h-4" /> End Session (Logout)
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={onOpenLogin}
                className="px-3.5 py-2 text-xs font-bold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition"
              >
                Log In
              </button>
              <button
                onClick={onOpenRegister}
                className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition"
              >
                Create Account
              </button>
            </div>
          )}
        </div>

      </div>
    </header>
  );
};
