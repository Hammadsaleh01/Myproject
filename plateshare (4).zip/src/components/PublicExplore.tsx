import React, { useState, useEffect } from 'react';
import { 
  Utensils, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Search, 
  Filter, 
  Building, 
  Heart, 
  AlertCircle,
  Sparkles,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { useAuth, FoodListing, User } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { ALL_PAKISTAN_CITIES } from '../data/pakistanLocations.ts';

interface PublicExploreProps {
  onOpenLogin: () => void;
  onOpenRegister: () => void;
  onNavigateToTab: (tab: string) => void;
}

export const PublicExplore: React.FC<PublicExploreProps> = ({
  onOpenLogin,
  onOpenRegister,
  onNavigateToTab
}) => {
  const { user, selectedCity, setSelectedCity } = useAuth();
  const [listings, setListings] = useState<FoodListing[]>([]);
  const [loading, setLoading] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [claimLoading, setClaimLoading] = useState<string | null>(null);

  const loadListings = async () => {
    setLoading(true);
    try {
      const res = await api.listings.getAll();
      setListings(res.listings || []);
    } catch (err) {
      console.warn('Load listings error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadListings();
  }, []);

  const handleClaim = async (listingId: string) => {
    if (!user) {
      onOpenLogin();
      return;
    }
    if (user.role !== 'NGO') {
      alert('Only registered and verified NGOs can claim surplus food for distribution.');
      return;
    }
    if (user.verificationStatus !== 'Verified' && user.verificationStatus !== 'Approved') {
      alert('Your NGO is still Pending Admin Verification. Only verified NGOs can claim donations.');
      return;
    }

    setClaimLoading(listingId);
    try {
      await api.listings.acceptListing(listingId);
      alert('Donation successfully claimed! Please schedule pickup time in your NGO dashboard.');
      loadListings();
      onNavigateToTab('dashboard');
    } catch (err: any) {
      alert(err.message || 'Failed to claim donation');
    } finally {
      setClaimLoading(null);
    }
  };

  const filteredListings = listings.filter(item => {
    const matchesCity = selectedCity === 'All Cities' || 
      (item.city && item.city.toLowerCase() === selectedCity.toLowerCase());
    const matchesCategory = categoryFilter === 'All' || item.foodCategory === categoryFilter;
    const matchesSearch = !searchQuery || 
      item.foodName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.area.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCity && matchesCategory && matchesSearch;
  });

  const availableCount = listings.filter(l => l.status === 'Available').length;
  const totalMeals = listings.reduce((sum, l) => sum + (l.quantity || 0), 0);

  return (
    <div className="flex flex-col gap-8 pb-12">
      
      {/* Hero Section */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-indigo-900 via-slate-900 to-emerald-950 text-white p-6 sm:p-10 shadow-lg">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-emerald-300 text-xs font-semibold mb-4">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Active Food Redistribution Across Pakistan
          </div>
          <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white leading-tight">
            Rescue Surplus Food. <br />
            <span className="text-emerald-400">Nourish Communities.</span>
          </h1>
          <p className="mt-3 text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
            Connecting quality restaurants, donors, and verified NGOs across Islamabad, Lahore, Karachi, Abbottabad, Peshawar, and beyond to ensure no meal goes to waste.
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            {!user ? (
              <>
                <button
                  onClick={onOpenRegister}
                  className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold px-5 py-2.5 rounded-2xl text-xs transition shadow-md flex items-center gap-2 cursor-pointer"
                >
                  Join as Restaurant or NGO
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={onOpenLogin}
                  className="bg-white/10 hover:bg-white/20 text-white font-bold px-5 py-2.5 rounded-2xl text-xs transition border border-white/20 cursor-pointer"
                >
                  Log In
                </button>
              </>
            ) : (
              <div className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/20 text-xs">
                Logged in as <b className="text-emerald-300">{user.name}</b> ({user.role} • {user.city})
              </div>
            )}
          </div>
        </div>

        {/* Live Counters */}
        <div className="relative z-10 grid grid-cols-2 sm:grid-cols-3 gap-3 mt-8 pt-6 border-t border-white/10 text-xs">
          <div className="p-3 bg-white/5 rounded-2xl backdrop-blur-xs border border-white/10">
            <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider block">Available Donations</span>
            <span className="text-xl sm:text-2xl font-black text-white block mt-0.5">{availableCount} active</span>
          </div>
          <div className="p-3 bg-white/5 rounded-2xl backdrop-blur-xs border border-white/10">
            <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider block">Meals Saved to Date</span>
            <span className="text-xl sm:text-2xl font-black text-emerald-400 block mt-0.5">{totalMeals + 1240} meals</span>
          </div>
          <div className="p-3 bg-white/5 rounded-2xl backdrop-blur-xs border border-white/10 col-span-2 sm:col-span-1">
            <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider block">Filtered City</span>
            <span className="text-xl sm:text-2xl font-black text-amber-300 block mt-0.5">{selectedCity}</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="relative flex-1 md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search food, city, area..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-indigo-600 font-medium"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700"
          >
            <option value="All">All Categories</option>
            <option value="Biryani & Rice">Biryani &amp; Rice</option>
            <option value="Curry & Gravy">Curry &amp; Gravy</option>
            <option value="Bread & Naan">Bread &amp; Naan</option>
            <option value="BBQ & Grilled">BBQ &amp; Grilled</option>
            <option value="Snacks & Bakery">Snacks &amp; Bakery</option>
            <option value="Vegetable Dishes">Vegetable Dishes</option>
          </select>
        </div>

        {/* City Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-1 text-xs">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mr-1">City:</span>
          {['All Cities', 'Islamabad', 'Lahore', 'Karachi', 'Abbottabad', 'Peshawar'].map(city => (
            <button
              key={city}
              onClick={() => setSelectedCity(city)}
              className={`px-3 py-1.5 rounded-xl font-bold transition text-xs whitespace-nowrap cursor-pointer ${
                selectedCity === city
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              {city === 'All Cities' ? '🇵🇰 All Pakistan' : city}
            </button>
          ))}
        </div>
      </div>

      {/* Listings Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-black text-slate-900 tracking-tight">Available Surplus Food Donations</h3>
            <p className="text-xs text-slate-500">
              Showing food posted in <b>{selectedCity}</b> ready for NGO pickup &amp; delivery
            </p>
          </div>
          <span className="text-xs font-bold text-slate-500">{filteredListings.length} listing(s)</span>
        </div>

        {loading ? (
          <div className="p-12 text-center text-slate-400 text-xs">Loading live donations...</div>
        ) : filteredListings.length === 0 ? (
          <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center flex flex-col items-center justify-center gap-2">
            <span className="text-3xl">🍲</span>
            <h4 className="font-extrabold text-sm text-slate-800">No surplus food currently available in this filter</h4>
            <p className="text-xs text-slate-500 max-w-md">
              Switch city filter to <b>All Pakistan</b> or check back soon when restaurants finish lunch/dinner service.
            </p>
            <button
              onClick={() => setSelectedCity('All Cities')}
              className="mt-2 text-xs font-bold text-indigo-600 hover:underline"
            >
              Show all Pakistani cities
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredListings.map(item => (
              <div 
                key={item.id} 
                className="bg-white rounded-3xl border border-slate-200/90 shadow-xs hover:shadow-md transition-all duration-200 p-5 flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 uppercase">
                      {item.foodCategory}
                    </span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      item.status === 'Available' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                      item.status === 'Accepted' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' :
                      item.status === 'Pickup_Scheduled' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                      'bg-slate-100 text-slate-600'
                    }`}>
                      {item.status}
                    </span>
                  </div>

                  <h4 className="font-extrabold text-base text-slate-900 leading-snug">{item.foodName}</h4>
                  
                  <div className="mt-2.5 flex flex-col gap-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-1.5 font-bold text-slate-800">
                      <Utensils className="w-3.5 h-3.5 text-indigo-600" />
                      <span>{item.quantity} {item.unit}</span>
                      <span className="text-slate-300">•</span>
                      <span className="text-[11px] font-medium text-slate-500">{item.storageCondition}</span>
                    </div>

                    <div className="flex items-center gap-1.5 text-slate-500">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{item.area}, {item.city}</span>
                    </div>

                    <div className="flex items-center gap-1.5 text-rose-600 font-semibold text-[11px]">
                      <Clock className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                      <span>Pickup Deadline: {item.pickupDeadline}</span>
                    </div>
                  </div>

                  {item.description && (
                    <p className="mt-3 text-xs text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100 line-clamp-2">
                      {item.description}
                    </p>
                  )}

                  {item.claimedByNgoName && (
                    <div className="mt-3 p-2 bg-indigo-50/70 rounded-xl text-xs text-indigo-900 border border-indigo-100">
                      <b>Claimed by:</b> {item.claimedByNgoName}
                    </div>
                  )}
                </div>

                {/* Claim CTA for NGOs */}
                {item.status === 'Available' && (
                  <button
                    onClick={() => handleClaim(item.id)}
                    disabled={claimLoading === item.id}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 rounded-2xl text-xs transition shadow-xs flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {claimLoading === item.id ? 'Claiming...' : (
                      user?.role === 'NGO' ? 'Claim Food Donation for Distribution' : 'Claim Donation (NGO Verification Required)'
                    )}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
