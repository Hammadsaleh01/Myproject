import React, { useState } from 'react';
import { 
  User as UserIcon, 
  MapPin, 
  Phone, 
  Mail, 
  ShieldCheck, 
  Lock, 
  Building, 
  Utensils, 
  Heart, 
  Save, 
  X,
  Bell,
  CheckCircle2
} from 'lucide-react';
import { useAuth, User } from '../context/AuthContext.tsx';
import { PAKISTAN_PROVINCES, ALL_PAKISTAN_CITIES, getCityDetails } from '../data/pakistanLocations.ts';

export const UserProfileModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { user, updateProfile, changePassword } = useAuth();
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'role_info'>('profile');

  // Edit states
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [province, setProvince] = useState(user?.province || 'Punjab');
  const [city, setCity] = useState(user?.city || 'Lahore');
  const [area, setArea] = useState(user?.area || 'Gulberg');
  const [address, setAddress] = useState(user?.address || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [operatingHours, setOperatingHours] = useState(user?.operatingHours || '11:00 AM - 11:30 PM');
  const [contactPerson, setContactPerson] = useState(user?.contactPerson || '');
  const [emailNotifs, setEmailNotifs] = useState(user?.notificationPrefs?.email ?? true);
  const [smsNotifs, setSmsNotifs] = useState(user?.notificationPrefs?.sms ?? true);
  
  // Password change states
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!user) return null;

  const currentCityObj = getCityDetails(city);
  const availableAreas = currentCityObj?.areas || [area];

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaveSuccess(false);
    try {
      await updateProfile({
        name,
        phone,
        province,
        city,
        area,
        address,
        bio,
        operatingHours,
        contactPerson,
        notificationPrefs: { email: emailNotifs, sms: smsNotifs, push: true }
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2500);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordMsg('');
    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match');
      return;
    }
    if (newPassword.length < 6) {
      setPasswordError('New password must be at least 6 characters');
      return;
    }

    try {
      await changePassword({ currentPassword, newPassword });
      setPasswordMsg('Password changed successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      setPasswordError(err.message);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col border border-slate-200 max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-lg uppercase shadow-xs">
              {user.name.charAt(0)}
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 leading-tight">{user.name}</h3>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-indigo-50 text-indigo-700 uppercase">
                  {user.role}
                </span>
                <span className="text-xs text-slate-400">📍 {user.city}, {user.province || 'Pakistan'}</span>
              </div>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center text-sm"
          >
            ✕
          </button>
        </div>

        {/* Tab navigation */}
        <div className="flex border-b border-slate-100 px-5 gap-4 text-xs font-bold text-slate-500">
          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3 border-b-2 transition ${activeTab === 'profile' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-800'}`}
          >
            Profile Information
          </button>
          <button
            onClick={() => setActiveTab('role_info')}
            className={`py-3 border-b-2 transition ${activeTab === 'role_info' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-800'}`}
          >
            {user.role} Verification Details
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`py-3 border-b-2 transition ${activeTab === 'security' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-800'}`}
          >
            Security &amp; Password
          </button>
        </div>

        {/* Tab contents */}
        <div className="p-5 overflow-y-auto flex-1">
          
          {/* TAB 1: Edit Profile */}
          {activeTab === 'profile' && (
            <form onSubmit={handleProfileSubmit} className="flex flex-col gap-3.5 text-xs">
              {saveSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Profile updated successfully!
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-600 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Province</label>
                  <select
                    value={province}
                    onChange={e => setProvince(e.target.value)}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {PAKISTAN_PROVINCES.map(p => (
                      <option key={p.name} value={p.name}>{p.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">City</label>
                  <select
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {ALL_PAKISTAN_CITIES.map(c => (
                      <option key={c.name} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Area / Sector</label>
                  <select
                    value={area}
                    onChange={e => setArea(e.target.value)}
                    className="w-full px-2 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {availableAreas.map(a => (
                      <option key={a} value={a}>{a}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Physical Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>

              {user.role === 'Restaurant' && (
                <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Operating Hours</label>
                    <input
                      type="text"
                      value={operatingHours}
                      onChange={e => setOperatingHours(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Manager / Contact Person</label>
                    <input
                      type="text"
                      value={contactPerson}
                      onChange={e => setContactPerson(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                    />
                  </div>
                </div>
              )}

              {/* Notification Preferences */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-800 block">Notification Preferences</span>
                  <span className="text-[10px] text-slate-400">Receive email and push alerts for surplus food</span>
                </div>
                <div className="flex gap-2">
                  <label className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
                    <input type="checkbox" checked={emailNotifs} onChange={e => setEmailNotifs(e.target.checked)} /> Email
                  </label>
                  <label className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
                    <input type="checkbox" checked={smsNotifs} onChange={e => setSmsNotifs(e.target.checked)} /> SMS
                  </label>
                </div>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 rounded-xl transition shadow-xs flex items-center justify-center gap-1.5 mt-2"
              >
                <Save className="w-4 h-4" /> {saving ? 'Saving Changes...' : 'Save Profile Changes'}
              </button>
            </form>
          )}

          {/* TAB 2: Role Specific Details */}
          {activeTab === 'role_info' && (
            <div className="flex flex-col gap-3.5 text-xs">
              <div className="p-3.5 bg-indigo-50/60 rounded-2xl border border-indigo-100 flex items-center justify-between">
                <div>
                  <span className="text-[9px] font-bold text-indigo-700 uppercase">Official Role Status</span>
                  <h4 className="font-black text-sm text-slate-900 mt-0.5">{user.role}</h4>
                </div>
                <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase ${
                  user.verificationStatus === 'Verified' ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' :
                  user.verificationStatus === 'Pending' ? 'bg-amber-100 text-amber-800 border border-amber-300' :
                  'bg-slate-100 text-slate-700'
                }`}>
                  {user.verificationStatus}
                </span>
              </div>

              {user.role === 'Restaurant' && (
                <div className="flex flex-col gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="font-bold text-slate-700 uppercase text-[10px]">Restaurant Information</span>
                  <div><b>Business:</b> {user.name}</div>
                  <div><b>City:</b> {user.city}, {user.province}</div>
                  <div><b>Operating Hours:</b> {user.operatingHours || '11:00 AM - 11:30 PM'}</div>
                  <div><b>Manager:</b> {user.contactPerson || user.name}</div>
                </div>
              )}

              {user.role === 'NGO' && (
                <div className="flex flex-col gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="font-bold text-slate-700 uppercase text-[10px]">NGO Credentials</span>
                  <div><b>Organization:</b> {user.organizationName || user.name}</div>
                  <div><b>Government License:</b> <code className="bg-white px-1.5 py-0.5 border rounded font-mono font-bold">{user.registrationNumber || 'N/A'}</code></div>
                  <div><b>Dispatch Capacity:</b> {user.capacity || 100} meals per batch</div>
                  <div><b>Service Areas:</b> {user.serviceAreas?.join(', ') || user.area}</div>
                </div>
              )}

              {user.role === 'Beneficiary' && (
                <div className="flex flex-col gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="font-bold text-slate-700 uppercase text-[10px]">Beneficiary Registry Record</span>
                  <div><b>National ID:</b> <code className="bg-white px-1.5 py-0.5 border rounded font-mono font-bold">13101-*******-1</code> (Protected for Privacy)</div>
                  <div><b>Eligibility:</b> <span className="text-emerald-700 font-bold">{user.eligibilityStatus || 'Verified'}</span></div>
                  <div><b>Family Size:</b> {user.householdSize || 5} members</div>
                </div>
              )}

              <div className="text-[11px] text-slate-400 bg-slate-50 p-3 rounded-xl border border-slate-200">
                🔒 <b>Security Note:</b> Official verification status and governmental registration licenses are reviewed and validated directly by PlateShare Platform Administrators. Users cannot self-elevate verification.
              </div>
            </div>
          )}

          {/* TAB 3: Security & Password */}
          {activeTab === 'security' && (
            <form onSubmit={handlePasswordSubmit} className="flex flex-col gap-3 text-xs">
              {passwordMsg && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl font-bold">
                  ✓ {passwordMsg}
                </div>
              )}
              {passwordError && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl font-medium">
                  ⚠️ {passwordError}
                </div>
              )}

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Current Password</label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={e => setCurrentPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">New Password</label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase">Confirm New Password</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="Repeat new password"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 rounded-xl transition shadow-xs mt-2"
              >
                Update Password
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
