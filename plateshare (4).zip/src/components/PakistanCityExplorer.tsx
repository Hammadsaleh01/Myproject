import React, { useState, useEffect } from 'react';
import { MapPin, Building, Utensils, Users, Heart, Sparkles, Check, ArrowRight } from 'lucide-react';
import { PAKISTAN_PROVINCES, ALL_PAKISTAN_CITIES, CityData } from '../data/pakistanLocations.ts';
import { api } from '../services/api.ts';
import { useAuth } from '../context/AuthContext.tsx';

export const PakistanCityExplorer: React.FC<{ onClose?: () => void }> = ({ onClose }) => {
  const { selectedCity, setSelectedCity } = useAuth();
  const [selectedProvince, setSelectedProvince] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [statsData, setStatsData] = useState<any>(null);
  const [hoveredCity, setHoveredCity] = useState<string | null>(null);

  useEffect(() => {
    const loadStats = async () => {
      try {
        const res = await api.locations.getCityStats();
        setStatsData(res.stats);
      } catch (err) {
        console.warn('Failed to load city statistics:', err);
      }
    };
    loadStats();
  }, []);

  const filteredCities = ALL_PAKISTAN_CITIES.filter(c => {
    const matchesProv = selectedProvince === 'All' || c.province === selectedProvince;
    const matchesSearch = !searchQuery || 
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.province.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesProv && matchesSearch;
  });

  const getCityMetrics = (cityName: string) => {
    if (!statsData?.cityBreakdowns) return null;
    return statsData.cityBreakdowns.find((b: any) => b.cityName.toLowerCase() === cityName.toLowerCase());
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-4 sm:p-6 flex flex-col gap-6">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xl">🇵🇰</span>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">Explore PlateShare Across Pakistan</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Discover verified restaurants, authorized NGOs, and food rescue operations across all 7 provinces &amp; administrative regions.
          </p>
        </div>

        {/* Search Input */}
        <div className="w-full md:w-64">
          <input
            type="text"
            placeholder="Search Pakistani city..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-indigo-600 font-medium"
          />
        </div>
      </div>

      {/* Province Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs font-bold">
        <button
          onClick={() => setSelectedProvince('All')}
          className={`px-3 py-1.5 rounded-full shrink-0 transition ${selectedProvince === 'All' ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          All Pakistan ({ALL_PAKISTAN_CITIES.length})
        </button>
        {PAKISTAN_PROVINCES.map(p => (
          <button
            key={p.name}
            onClick={() => setSelectedProvince(p.name)}
            className={`px-3 py-1.5 rounded-full shrink-0 transition ${selectedProvince === p.name ? 'bg-indigo-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
          >
            {p.name}
          </button>
        ))}
      </div>

      {/* Cities Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {filteredCities.map(city => {
          const metrics = getCityMetrics(city.name);
          const isSelected = selectedCity.toLowerCase() === city.name.toLowerCase();

          return (
            <div
              key={city.name}
              onMouseEnter={() => setHoveredCity(city.name)}
              onMouseLeave={() => setHoveredCity(null)}
              onClick={() => {
                setSelectedCity(city.name);
                if (onClose) onClose();
              }}
              className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between gap-3 ${
                isSelected 
                  ? 'border-indigo-600 bg-indigo-50/50 shadow-sm ring-2 ring-indigo-600/20' 
                  : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50/60 shadow-3xs'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="font-black text-sm text-slate-900 tracking-tight flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                      {city.name}
                    </h4>
                    <span className="text-[10px] font-semibold text-slate-400 block mt-0.5">
                      {city.district} District • {city.province}
                    </span>
                  </div>

                  {isSelected && (
                    <span className="text-[9px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-600 text-white flex items-center gap-1 shadow-xs">
                      <Check className="w-2.5 h-2.5" /> Active
                    </span>
                  )}
                </div>

                {/* City Areas tags */}
                <div className="flex flex-wrap gap-1 mt-2.5">
                  {city.areas.slice(0, 3).map(area => (
                    <span key={area} className="text-[9px] font-medium bg-white px-2 py-0.5 rounded-md border border-slate-150 text-slate-600">
                      {area}
                    </span>
                  ))}
                  {city.areas.length > 3 && (
                    <span className="text-[9px] text-slate-400 self-center">+{city.areas.length - 3}</span>
                  )}
                </div>
              </div>

              {/* Real Database Metrics Card */}
              <div className="bg-white/80 backdrop-blur-xs p-2.5 rounded-xl border border-slate-150 grid grid-cols-3 gap-1 text-center text-[10px]">
                <div>
                  <span className="text-[8px] font-bold text-slate-400 uppercase block">Restaurants</span>
                  <span className="font-extrabold text-slate-800 font-display">
                    {metrics ? metrics.availableRestaurants : '—'}
                  </span>
                </div>
                <div>
                  <span className="text-[8px] font-bold text-slate-400 uppercase block">NGOs</span>
                  <span className="font-extrabold text-indigo-700 font-display">
                    {metrics ? metrics.verifiedNgos : '—'}
                  </span>
                </div>
                <div>
                  <span className="text-[8px] font-bold text-slate-400 uppercase block">Donations</span>
                  <span className="font-extrabold text-emerald-600 font-display">
                    {metrics ? metrics.activeDonations : '—'}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] text-slate-500 font-bold pt-1 border-t border-slate-100">
                <span>{isSelected ? 'Currently Focused' : 'Tap to Focus City'}</span>
                <ArrowRight className="w-3.5 h-3.5 text-indigo-600" />
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-[11px] text-slate-400 text-center font-medium">
        🛡️ Note: All statistics shown are verified directly from active database records. Cities without active nodes show authentic counts.
      </div>
    </div>
  );
};
