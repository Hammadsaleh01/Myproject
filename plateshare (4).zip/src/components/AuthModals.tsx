import React, { useState } from 'react';
import { X, AlertCircle, ShieldAlert, CheckCircle2, ArrowRight } from 'lucide-react';
import { useAuth, UserRole } from '../context/AuthContext.tsx';
import { PAKISTAN_PROVINCES, ALL_PAKISTAN_CITIES, getCityDetails } from '../data/pakistanLocations.ts';

interface AuthModalsProps {
  loginOpen: boolean;
  registerOpen: boolean;
  onCloseLogin: () => void;
  onCloseRegister: () => void;
  onSwitchToRegister: () => void;
  onSwitchToLogin: () => void;
}

export const AuthModals: React.FC<AuthModalsProps> = ({
  loginOpen,
  registerOpen,
  onCloseLogin,
  onCloseRegister,
  onSwitchToRegister,
  onSwitchToLogin
}) => {
  const { login, register } = useAuth();

  // Login States
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState('');

  // Register States
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('Restaurant');
  const [regProvince, setRegProvince] = useState('Punjab');
  const [regCity, setRegCity] = useState('Lahore');
  const [regArea, setRegArea] = useState('Gulberg');
  const [regAddress, setRegAddress] = useState('');
  
  // Role specific fields
  const [regOrgName, setRegOrgName] = useState('');
  const [regNo, setRegNo] = useState('');
  const [regCapacity, setRegCapacity] = useState('100');
  const [regHours, setRegHours] = useState('11:00 AM - 11:30 PM');
  const [regContactPerson, setRegContactPerson] = useState('');
  const [regCnic, setRegCnic] = useState('');
  const [regHouseholdSize, setRegHouseholdSize] = useState('5');
  const [hasSmartphone, setHasSmartphone] = useState(true);

  const [regLoading, setRegLoading] = useState(false);
  const [regError, setRegError] = useState('');

  // Province cities
  const provinceCities = PAKISTAN_PROVINCES.find(p => p.name === regProvince)?.cities || [];
  const currentCityObj = getCityDetails(regCity);
  const currentAreas = currentCityObj?.areas || [regArea];

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoginLoading(true);
    try {
      await login(loginEmail, loginPassword);
      onCloseLogin();
    } catch (err: any) {
      setLoginError(err.message || 'Login failed. Please verify credentials.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (regPassword !== regConfirmPassword) {
      setRegError('Passwords do not match.');
      return;
    }

    if (regPassword.length < 6) {
      setRegError('Password must be at least 6 characters.');
      return;
    }

    setRegLoading(true);
    try {
      await register({
        name: regName,
        email: regEmail,
        phone: regPhone,
        password: regPassword,
        role: regRole,
        province: regProvince,
        city: regCity,
        area: regArea,
        address: regAddress,
        organizationName: regOrgName || regName,
        registrationNumber: regNo,
        capacity: Number(regCapacity) || 50,
        operatingHours: regHours,
        contactPerson: regContactPerson,
        cnic: regCnic,
        householdSize: Number(regHouseholdSize) || 4,
        hasSmartphone
      });
      onCloseRegister();
    } catch (err: any) {
      setRegError(err.message || 'Registration failed.');
    } finally {
      setRegLoading(false);
    }
  };

  return (
    <>
      {/* LOGIN MODAL */}
      {loginOpen && (
        <div className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl p-6 sm:p-8 border border-slate-200 relative animate-in fade-in zoom-in-95 duration-150">
            <button
              onClick={onCloseLogin}
              className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-6">
              <div className="w-11 h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-2xl shadow-xs">
                🍲
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-900 tracking-tight">Log In to PlateShare</h3>
                <p className="text-xs text-slate-500">Access your verified Pakistan food redistribution account</p>
              </div>
            </div>

            {loginError && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-2xl text-xs text-red-700 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                <span className="leading-tight">{loginError}</span>
              </div>
            )}

            <form onSubmit={handleLoginSubmit} className="flex flex-col gap-3.5">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="e.g. name@organization.pk"
                  value={loginEmail}
                  onChange={e => setLoginEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-indigo-600 focus:bg-white transition"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={loginPassword}
                  onChange={e => setLoginPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-indigo-600 focus:bg-white transition"
                />
              </div>

              <button
                type="submit"
                disabled={loginLoading}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-2xl text-xs transition shadow-xs mt-2 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {loginLoading ? 'Signing In...' : 'Sign In to PlateShare'}
              </button>
            </form>

            <div className="mt-6 pt-5 border-t border-slate-100 text-center text-xs text-slate-500">
              Don&apos;t have an account yet?{' '}
              <button
                onClick={onSwitchToRegister}
                className="font-bold text-indigo-600 hover:text-indigo-800 hover:underline"
              >
                Create Account
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REGISTER MODAL */}
      {registerOpen && (
        <div className="fixed inset-0 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl p-6 sm:p-8 border border-slate-200 relative my-8 max-h-[92vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
            <button
              onClick={onCloseRegister}
              className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-5">
              <div className="w-11 h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-2xl shadow-xs">
                🇵🇰
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-900 tracking-tight">Join PlateShare Pakistan</h3>
                <p className="text-xs text-slate-500">Connecting surplus food to verified assistance across all cities</p>
              </div>
            </div>

            {regError && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-2xl text-xs text-red-700 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
                <span className="leading-tight">{regError}</span>
              </div>
            )}

            <form onSubmit={handleRegisterSubmit} className="flex flex-col gap-4 text-xs">
              
              {/* Role Selection */}
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                  How will you participate on PlateShare?
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { role: 'Restaurant' as UserRole, label: 'Restaurant', icon: '🍽️', desc: 'Donate food' },
                    { role: 'NGO' as UserRole, label: 'NGO', icon: '🏢', desc: 'Collect & distribute' },
                    { role: 'Donor' as UserRole, label: 'Donor', icon: '💚', desc: 'Sponsor meals' },
                    { role: 'Beneficiary' as UserRole, label: 'Beneficiary', icon: '🤝', desc: 'Assistance' }
                  ].map(item => (
                    <button
                      key={item.role}
                      type="button"
                      onClick={() => setRegRole(item.role)}
                      className={`p-3 rounded-2xl border text-left transition flex flex-col justify-between ${
                        regRole === item.role
                          ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 ring-2 ring-indigo-600/20 shadow-xs'
                          : 'border-slate-200 hover:border-slate-300 bg-slate-50/60 text-slate-700'
                      }`}
                    >
                      <span className="text-lg">{item.icon}</span>
                      <span className="font-extrabold text-xs block mt-1">{item.label}</span>
                      <span className="text-[10px] text-slate-400 leading-tight block">{item.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Security Banner for Restaurant & NGO */}
              {(regRole === 'Restaurant' || regRole === 'NGO') && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-amber-900 text-[11px] flex items-start gap-2.5 leading-relaxed">
                  <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>
                    <b>Security Policy:</b> Accounts registered as <b>{regRole}</b> begin with <b>Pending Verification</b>. You will be able to log in, but food donation and claiming permissions require review by a PlateShare Administrator.
                  </span>
                </div>
              )}

              {/* Basic Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    {regRole === 'Restaurant' ? 'Restaurant Name' : regRole === 'NGO' ? 'NGO / Organization Name' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Al-Shiraz or Tariq Khan"
                    value={regName}
                    onChange={e => setRegName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="user@example.pk"
                    value={regEmail}
                    onChange={e => setRegEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Phone Number (03xx-xxxxxxx)</label>
                  <input
                    type="tel"
                    required
                    placeholder="03001234567"
                    value={regPhone}
                    onChange={e => setRegPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Password</label>
                  <input
                    type="password"
                    required
                    placeholder="Min 6 characters"
                    value={regPassword}
                    onChange={e => setRegPassword(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Confirm Password</label>
                  <input
                    type="password"
                    required
                    placeholder="Re-enter password"
                    value={regConfirmPassword}
                    onChange={e => setRegConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              {/* Location Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Province / Region</label>
                  <select
                    value={regProvince}
                    onChange={e => {
                      const p = e.target.value;
                      setRegProvince(p);
                      const cities = PAKISTAN_PROVINCES.find(prov => prov.name === p)?.cities || [];
                      if (cities.length > 0) {
                        setRegCity(cities[0].name);
                        setRegArea(cities[0].areas[0] || 'Center');
                      }
                    }}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {PAKISTAN_PROVINCES.map(p => (
                      <option key={p.name} value={p.name}>{p.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">City</label>
                  <select
                    value={regCity}
                    onChange={e => {
                      const c = e.target.value;
                      setRegCity(c);
                      const cityObj = getCityDetails(c);
                      if (cityObj?.areas.length) {
                        setRegArea(cityObj.areas[0]);
                      }
                    }}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {provinceCities.map(c => (
                      <option key={c.name} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Area / Sector</label>
                  <select
                    value={regArea}
                    onChange={e => setRegArea(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                  >
                    {currentAreas.map(a => (
                      <option key={a} value={a}>{a}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Physical Address / Street Location</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Shop 4, Main Commercial Market, Near Chowk"
                  value={regAddress}
                  onChange={e => setRegAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                />
              </div>

              {/* Role Specific Dynamic Fields */}
              {regRole === 'Restaurant' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Contact Person / Manager</label>
                    <input
                      type="text"
                      placeholder="e.g. Manager Imran"
                      value={regContactPerson}
                      onChange={e => setRegContactPerson(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Operating Hours</label>
                    <input
                      type="text"
                      placeholder="e.g. 11:00 AM - 11:00 PM"
                      value={regHours}
                      onChange={e => setRegHours(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>
              )}

              {regRole === 'NGO' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Govt Registration / Trust No.</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. SWD/ICT-2024-981"
                      value={regNo}
                      onChange={e => setRegNo(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Daily Meal Capacity</label>
                    <input
                      type="number"
                      required
                      placeholder="150"
                      value={regCapacity}
                      onChange={e => setRegCapacity(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>
              )}

              {regRole === 'Beneficiary' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">CNIC (xxxxx-xxxxxxx-x)</label>
                    <input
                      type="text"
                      required
                      placeholder="13101-1234567-1"
                      value={regCnic}
                      onChange={e => setRegCnic(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Household Members</label>
                    <input
                      type="number"
                      required
                      value={regHouseholdSize}
                      onChange={e => setRegHouseholdSize(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={regLoading}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3.5 rounded-2xl text-xs transition shadow-xs mt-2 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {regLoading ? 'Creating Account...' : 'Complete Registration & Enter PlateShare'}
              </button>
            </form>

            <div className="mt-5 pt-4 border-t border-slate-100 text-center text-xs text-slate-500">
              Already registered?{' '}
              <button
                onClick={onSwitchToLogin}
                className="font-bold text-indigo-600 hover:text-indigo-800 hover:underline"
              >
                Sign In
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
