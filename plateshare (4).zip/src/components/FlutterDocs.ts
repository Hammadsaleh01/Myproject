export interface FlutterFile {
  path: string;
  description: string;
  code: string;
}

export const FLUTTER_FILES: FlutterFile[] = [
  {
    path: 'lib/models/user_model.dart',
    description: 'Data model representing a PlateShare user with role-based attributes and JSON serialization helpers.',
    code: `// lib/models/user_model.dart

enum UserRole { Donor, NGO, Volunteer, Admin }
enum VerificationStatus { Pending, Approved, NA }

class UserModel {
  final String id;
  final String name;
  final String email;
  final String phone;
  final UserRole role;
  final String address;
  final VerificationStatus verificationStatus;
  final String? organizationName;
  final String? registrationNumber;
  final DateTime createdAt;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.role,
    required this.address,
    required this.verificationStatus,
    this.organizationName,
    this.registrationNumber,
    required this.createdAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      phone: json['phone'] ?? '',
      role: _parseRole(json['role']),
      address: json['address'] ?? '',
      verificationStatus: _parseVerificationStatus(json['verificationStatus']),
      organizationName: json['organizationName'],
      registrationNumber: json['registrationNumber'],
      createdAt: json['createdAt'] != null 
          ? DateTime.parse(json['createdAt']) 
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'role': role.toString().split('.').last,
      'address': address,
      'verificationStatus': verificationStatus.toString().split('.').last == 'NA' ? 'N/A' : verificationStatus.toString().split('.').last,
      'organizationName': organizationName,
      'registrationNumber': registrationNumber,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  static UserRole _parseRole(String? roleStr) {
    switch (roleStr) {
      case 'Donor': return UserRole.Donor;
      case 'NGO': return UserRole.NGO;
      case 'Volunteer': return UserRole.Volunteer;
      case 'Admin': return UserRole.Admin;
      default: return UserRole.Donor;
    }
  }

  static VerificationStatus _parseVerificationStatus(String? statusStr) {
    switch (statusStr) {
      case 'Pending': return VerificationStatus.Pending;
      case 'Approved': return VerificationStatus.Approved;
      case 'N/A': return VerificationStatus.NA;
      default: return VerificationStatus.NA;
    }
  }
}`
  },
  {
    path: 'lib/models/food_listing_model.dart',
    description: 'Data model representing a food donation listing with status, donor details, and expiry thresholds.',
    code: `// lib/models/food_listing_model.dart

enum ListingStatus { Available, Completed, Expired }

class FoodListingModel {
  final String id;
  final String donorId;
  final String donorName;
  final String foodName;
  final String foodType; // e.g., Veg, Non-Veg, Bakery, Groceries
  final double quantity; // in kg
  final String description;
  final String pickupAddress;
  final DateTime pickupTime;
  final DateTime expiryTime;
  final String image;
  final ListingStatus status;
  final DateTime createdAt;

  FoodListingModel({
    required this.id,
    required this.donorId,
    required this.donorName,
    required this.foodName,
    required this.foodType,
    required this.quantity,
    required this.description,
    required this.pickupAddress,
    required this.pickupTime,
    required this.expiryTime,
    required this.image,
    required this.status,
    required this.createdAt,
  });

  factory FoodListingModel.fromJson(Map<String, dynamic> json) {
    return FoodListingModel(
      id: json['id'] ?? '',
      donorId: json['donorId'] ?? '',
      donorName: json['donorName'] ?? '',
      foodName: json['foodName'] ?? '',
      foodType: json['foodType'] ?? 'Veg',
      quantity: (json['quantity'] as num?)?.toDouble() ?? 0.0,
      description: json['description'] ?? '',
      pickupAddress: json['pickupAddress'] ?? '',
      pickupTime: json['pickupTime'] != null ? DateTime.parse(json['pickupTime']) : DateTime.now(),
      expiryTime: json['expiryTime'] != null ? DateTime.parse(json['expiryTime']) : DateTime.now(),
      image: json['image'] ?? '',
      status: _parseStatus(json['status']),
      createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'donorId': donorId,
      'donorName': donorName,
      'foodName': foodName,
      'foodType': foodType,
      'quantity': quantity,
      'description': description,
      'pickupAddress': pickupAddress,
      'pickupTime': pickupTime.toIso8601String(),
      'expiryTime': expiryTime.toIso8601String(),
      'image': image,
      'status': status.toString().split('.').last,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  static ListingStatus _parseStatus(String? statusStr) {
    switch (statusStr) {
      case 'Available': return ListingStatus.Available;
      case 'Completed': return ListingStatus.Completed;
      case 'Expired': return ListingStatus.Expired;
      default: return ListingStatus.Available;
    }
  }
}`
  },
  {
    path: 'lib/services/api_service.dart',
    description: 'Central REST API client using shared_preferences for JWT bearer token injection.',
    code: `// lib/services/api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String baseUrl = 'https://your-plateshare-server.com/api';

  static Future<Map<String, String>> _getHeaders() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('plateshare_token');
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer \$token',
    };
  }

  static Future<http.Response> register(Map<String, dynamic> userData) async {
    final url = Uri.parse('\$baseUrl/auth/register');
    return await http.post(url, headers: {'Content-Type': 'application/json'}, body: jsonEncode(userData));
  }

  static Future<http.Response> login(String email, String password) async {
    final url = Uri.parse('\$baseUrl/auth/login');
    return await http.post(url, headers: {'Content-Type': 'application/json'}, body: jsonEncode({'email': email, 'password': password}));
  }

  static Future<http.Response> getMe() async {
    return await http.get(Uri.parse('\$baseUrl/auth/me'), headers: await _getHeaders());
  }

  static Future<http.Response> getAllListings() async {
    return await http.get(Uri.parse('\$baseUrl/listings'), headers: await _getHeaders());
  }

  static Future<http.Response> createListing(Map<String, dynamic> data) async {
    return await http.post(Uri.parse('\$baseUrl/listings'), headers: await _getHeaders(), body: jsonEncode(data));
  }

  static Future<http.Response> deleteListing(String id) async {
    return await http.delete(Uri.parse('\$baseUrl/listings/\$id'), headers: await _getHeaders());
  }
}`
  },
  {
    path: 'lib/providers/auth_provider.dart',
    description: 'Flutter state management class implementing ChangeNotifier to synchronize app state and notifications.',
    code: `// lib/providers/auth_provider.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../services/api_service.dart';

class AuthProvider with ChangeNotifier {
  UserModel? _user;
  String? _token;
  bool _isLoading = false;
  String? _error;

  UserModel? get user => _user;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _token != null;

  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final res = await ApiService.login(email, password);
      final data = jsonDecode(res.body);
      if (res.statusCode == 200) {
        _token = data['token'];
        _user = UserModel.fromJson(data['user']);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('plateshare_token', _token!);
        notifyListeners();
        return true;
      } else {
        _error = data['error'];
        return false;
      }
    } catch(e) {
      _error = 'Connection failed';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}`
  }
];
