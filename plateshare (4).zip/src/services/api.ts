// PlateShare Frontend API Service Client
// Connects React components to the Express backend with full role-based support across Pakistan.

const API_BASE = '/api';

function getHeaders() {
  const token = localStorage.getItem('plateshare_token');
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

async function handleResponse(response: Response) {
  const contentType = response.headers.get('content-type');
  let data = null;
  if (contentType && contentType.includes('application/json')) {
    data = await response.json();
  } else {
    data = { error: await response.text() };
  }

  if (!response.ok) {
    throw new Error(data.error || `HTTP error! Status: ${response.status}`);
  }
  return data;
}

export const api = {
  // Auth API
  auth: {
    register: async (userData: any) => {
      const response = await fetch(`${API_BASE}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
      });
      return handleResponse(response);
    },

    login: async (credentials: any) => {
      const response = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials),
      });
      return handleResponse(response);
    },

    getMe: async () => {
      const response = await fetch(`${API_BASE}/auth/me`, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    forgotPassword: async (email: string) => {
      const response = await fetch(`${API_BASE}/auth/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      return handleResponse(response);
    },

    resetPassword: async (resetData: { resetToken: string; newPassword: string; confirmPassword: string }) => {
      const response = await fetch(`${API_BASE}/auth/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(resetData),
      });
      return handleResponse(response);
    },

    updateProfile: async (profileData: any) => {
      const response = await fetch(`${API_BASE}/auth/profile`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(profileData),
      });
      return handleResponse(response);
    },

    changePassword: async (passData: any) => {
      const response = await fetch(`${API_BASE}/auth/change-password`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(passData),
      });
      return handleResponse(response);
    },

    verifyNgo: async (ngoId: string, status: string) => {
      const response = await fetch(`${API_BASE}/auth/verify-ngo`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ ngoId, status }),
      });
      return handleResponse(response);
    },

    verifyRestaurant: async (restaurantId: string, status: string) => {
      const response = await fetch(`${API_BASE}/auth/verify-restaurant`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ restaurantId, status }),
      });
      return handleResponse(response);
    },

    verifyBeneficiary: async (beneficiaryId: string, status: string) => {
      const response = await fetch(`${API_BASE}/auth/verify-beneficiary`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ beneficiaryId, status }),
      });
      return handleResponse(response);
    },

    getAllUsers: async (filters?: { city?: string; province?: string; role?: string }) => {
      const params = new URLSearchParams();
      if (filters?.city) params.append('city', filters.city);
      if (filters?.province) params.append('province', filters.province);
      if (filters?.role) params.append('role', filters.role);

      const url = `${API_BASE}/users${params.toString() ? `?${params.toString()}` : ''}`;
      const response = await fetch(url, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    deleteUser: async (id: string) => {
      const response = await fetch(`${API_BASE}/users/${id}`, {
        method: 'DELETE',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },
  },

  // Locations & Real Stats API
  locations: {
    getLocations: async () => {
      const response = await fetch(`${API_BASE}/locations`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      return handleResponse(response);
    },

    getCityStats: async (cityName?: string) => {
      const url = cityName && cityName !== 'Pakistan' && cityName !== 'All Cities'
        ? `${API_BASE}/locations/stats?city=${encodeURIComponent(cityName)}`
        : `${API_BASE}/locations/stats`;
      const response = await fetch(url, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      return handleResponse(response);
    },
  },

  // Listings API
  listings: {
    getAll: async (filters?: { city?: string; province?: string }) => {
      const params = new URLSearchParams();
      if (filters?.city && filters.city !== 'Pakistan' && filters.city !== 'All Cities') {
        params.append('city', filters.city);
      }
      if (filters?.province && filters.province !== 'All Provinces') {
        params.append('province', filters.province);
      }
      const url = `${API_BASE}/listings${params.toString() ? `?${params.toString()}` : ''}`;
      const response = await fetch(url, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    getMyListings: async () => {
      const response = await fetch(`${API_BASE}/listings/my`, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    getById: async (id: string) => {
      const response = await fetch(`${API_BASE}/listings/${id}`, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    create: async (listingData: any) => {
      const response = await fetch(`${API_BASE}/listings`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(listingData),
      });
      return handleResponse(response);
    },

    acceptListing: async (id: string) => {
      const response = await fetch(`${API_BASE}/listings/${id}/accept`, {
        method: 'POST',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    claim: async (id: string) => {
      const response = await fetch(`${API_BASE}/listings/${id}/accept`, {
        method: 'POST',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    schedulePickup: async (id: string, scheduledTime?: string) => {
      const response = await fetch(`${API_BASE}/listings/${id}/schedule-pickup`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ scheduledTime }),
      });
      return handleResponse(response);
    },

    verifyPickupOtp: async (id: string, otp: string) => {
      const response = await fetch(`${API_BASE}/listings/${id}/verify-pickup`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ otp }),
      });
      return handleResponse(response);
    },

    update: async (id: string, listingData: any) => {
      const response = await fetch(`${API_BASE}/listings/${id}`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(listingData),
      });
      return handleResponse(response);
    },

    delete: async (id: string) => {
      const response = await fetch(`${API_BASE}/listings/${id}`, {
        method: 'DELETE',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    updateStatus: async (id: string, status: string) => {
      const response = await fetch(`${API_BASE}/listings/${id}/status`, {
        method: 'PATCH',
        headers: getHeaders(),
        body: JSON.stringify({ status }),
      });
      return handleResponse(response);
    },
  },

  // Allocations & Anti-duplicate Distribution Period Management
  allocations: {
    getAll: async (city?: string) => {
      const url = city && city !== 'All Cities' && city !== 'Pakistan'
        ? `${API_BASE}/allocations?city=${encodeURIComponent(city)}`
        : `${API_BASE}/allocations`;
      const response = await fetch(url, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    getMyAllocations: async () => {
      const response = await fetch(`${API_BASE}/allocations/my`, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    create: async (allocationData: {
      donationId: string;
      beneficiaryId?: string;
      beneficiaryName: string;
      beneficiaryCnic: string;
      beneficiaryPhone?: string;
      quantity: number;
      city?: string;
    }) => {
      const response = await fetch(`${API_BASE}/allocations`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(allocationData),
      });
      return handleResponse(response);
    },

    confirm: async (confirmData: {
      allocationId: string;
      verificationMethod?: 'OTP' | 'QR' | 'Manual_NGO';
      otp?: string;
      notes?: string;
    }) => {
      const response = await fetch(`${API_BASE}/allocations/confirm`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(confirmData),
      });
      return handleResponse(response);
    },
  },

  // Needy Tracking API (Offline Beneficiaries Without Smartphone)
  needy: {
    getAll: async (city?: string) => {
      const url = city && city !== 'All Cities' && city !== 'Pakistan'
        ? `${API_BASE}/needy?city=${encodeURIComponent(city)}`
        : `${API_BASE}/needy`;
      const response = await fetch(url, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    register: async (needyData: { 
      name: string; 
      phone?: string; 
      cnic: string; 
      province?: string;
      city?: string; 
      area?: string; 
      address?: string;
      householdSize?: number;
      urgency?: string;
    }) => {
      const response = await fetch(`${API_BASE}/needy`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(needyData),
      });
      return handleResponse(response);
    },

    delete: async (id: string) => {
      const response = await fetch(`${API_BASE}/needy/${id}`, {
        method: 'DELETE',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    getDistributions: async (city?: string) => {
      const url = city && city !== 'All Cities' && city !== 'Pakistan'
        ? `${API_BASE}/distributions?city=${encodeURIComponent(city)}`
        : `${API_BASE}/distributions`;
      const response = await fetch(url, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    distributeFood: async (distributionData: { cnic: string; notes?: string; donationId?: string; quantity?: number; city?: string }) => {
      const response = await fetch(`${API_BASE}/distributions`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(distributionData),
      });
      return handleResponse(response);
    },
  },

  // Assistance Cases API (Respectful Beneficiary Services)
  assistance: {
    getAll: async (city?: string) => {
      const url = city && city !== 'All Cities' && city !== 'Pakistan'
        ? `${API_BASE}/assistance?city=${encodeURIComponent(city)}`
        : `${API_BASE}/assistance`;
      const response = await fetch(url, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    register: async (caseData: { 
      name: string; 
      phone?: string; 
      cnic: string; 
      province?: string;
      city?: string; 
      area?: string; 
      address?: string;
      householdSize?: number;
      urgency?: string;
    }) => {
      const response = await fetch(`${API_BASE}/assistance`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(caseData),
      });
      return handleResponse(response);
    },

    delete: async (id: string) => {
      const response = await fetch(`${API_BASE}/assistance/${id}`, {
        method: 'DELETE',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },
  },

  // Donor Sponsorships API
  sponsorships: {
    getMyStats: async () => {
      const response = await fetch(`${API_BASE}/sponsorships/my`, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    create: async (data: { amountPkr: number; campaign?: string; city?: string }) => {
      const response = await fetch(`${API_BASE}/sponsorships`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(data),
      });
      return handleResponse(response);
    },
  },

  // Admin Operational Console API
  admin: {
    getStats: async (filters?: { city?: string; province?: string }) => {
      const params = new URLSearchParams();
      if (filters?.city && filters.city !== 'All Cities' && filters.city !== 'Pakistan') {
        params.append('city', filters.city);
      }
      if (filters?.province && filters.province !== 'All Provinces') {
        params.append('province', filters.province);
      }
      const url = `${API_BASE}/admin/stats${params.toString() ? `?${params.toString()}` : ''}`;
      const response = await fetch(url, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    getSettings: async () => {
      const response = await fetch(`${API_BASE}/admin/settings`, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    updateSettings: async (settingsData: any) => {
      const response = await fetch(`${API_BASE}/admin/settings`, {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify(settingsData),
      });
      return handleResponse(response);
    },

    getAuditLogs: async () => {
      const response = await fetch(`${API_BASE}/admin/audit-logs`, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    getComplaints: async (city?: string) => {
      const url = city && city !== 'All Cities' && city !== 'Pakistan'
        ? `${API_BASE}/admin/complaints?city=${encodeURIComponent(city)}`
        : `${API_BASE}/admin/complaints`;
      const response = await fetch(url, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    updateComplaint: async (id: string, data: { status: string; adminNotes?: string }) => {
      const response = await fetch(`${API_BASE}/admin/complaints/${id}`, {
        method: 'PATCH',
        headers: getHeaders(),
        body: JSON.stringify(data),
      });
      return handleResponse(response);
    },
  },

  // Notifications API
  notifications: {
    getMyNotifications: async () => {
      const response = await fetch(`${API_BASE}/notifications`, {
        method: 'GET',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    markAsRead: async (id: string) => {
      const response = await fetch(`${API_BASE}/notifications/${id}/read`, {
        method: 'PATCH',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },

    markAllAsRead: async () => {
      const response = await fetch(`${API_BASE}/notifications/read-all`, {
        method: 'POST',
        headers: getHeaders(),
      });
      return handleResponse(response);
    },
  },
};
