import express from 'express';
import { authController } from '../controllers/authController.ts';
import { listingController } from '../controllers/listingController.ts';
import { notificationController } from '../controllers/notificationController.ts';
import { assistanceController } from '../controllers/assistanceController.ts';
import { adminController } from '../controllers/adminController.ts';
import { sponsorController } from '../controllers/sponsorController.ts';
import { 
  authenticateJWT, 
  requireRole, 
  requireAdmin, 
  requireVerifiedRestaurant, 
  requireVerifiedNGO 
} from '../middleware/auth.ts';

const apiRouter = express.Router();

// --- Auth & User Profile Routes ---
apiRouter.post('/auth/register', authController.register);
apiRouter.post('/auth/login', authController.login);
apiRouter.post('/auth/forgot-password', authController.forgotPassword);
apiRouter.post('/auth/reset-password', authController.resetPassword);
apiRouter.get('/auth/me', authenticateJWT, authController.getMe);
apiRouter.put('/auth/profile', authenticateJWT, authController.updateProfile);
apiRouter.post('/auth/change-password', authenticateJWT, authController.changePassword);

// --- Admin Verification & User Management Routes ---
apiRouter.post('/auth/verify-ngo', authenticateJWT, requireAdmin(), authController.verifyNgo);
apiRouter.post('/auth/verify-restaurant', authenticateJWT, requireAdmin(), authController.verifyRestaurant);
apiRouter.post('/auth/verify-beneficiary', authenticateJWT, requireRole(['Admin', 'NGO']), authController.verifyBeneficiary);
apiRouter.get('/users', authenticateJWT, requireAdmin(), authController.getAllUsers);
apiRouter.delete('/users/:id', authenticateJWT, requireAdmin(), authController.deleteUser);

// --- Pakistan Structured Locations & Real Stats ---
apiRouter.get('/locations', authController.getLocations);
apiRouter.get('/locations/stats', authController.getCityStats);

// --- Food Listing Routes ---
apiRouter.get('/listings', listingController.getAllListings);
apiRouter.get('/listings/my', authenticateJWT, requireRole(['Donor', 'Restaurant', 'NGO', 'Admin']), listingController.getMyListings);
apiRouter.get('/listings/:id', listingController.getListingById);

// Create donation (Strict verification required for restaurants)
apiRouter.post('/listings', authenticateJWT, requireVerifiedRestaurant, listingController.createListing);

// NGO Accepts donation (Strict verification required for NGOs)
apiRouter.post('/listings/:id/accept', authenticateJWT, requireVerifiedNGO, listingController.acceptListing);

// Schedule Pickup with OTP generation (NGO IDOR protected)
apiRouter.post('/listings/:id/schedule-pickup', authenticateJWT, requireVerifiedNGO, listingController.schedulePickup);

// Verify Pickup OTP at handover (Restaurant or NGO driver)
apiRouter.post('/listings/:id/verify-pickup', authenticateJWT, requireRole(['Restaurant', 'NGO', 'Admin']), listingController.verifyPickupOtp);

// Edit / Delete / Status updates (IDOR ownership protected)
apiRouter.put('/listings/:id', authenticateJWT, requireRole(['Donor', 'Restaurant', 'Admin']), listingController.editListing);
apiRouter.delete('/listings/:id', authenticateJWT, requireRole(['Donor', 'Restaurant', 'Admin']), listingController.deleteListing);
apiRouter.patch('/listings/:id/status', authenticateJWT, requireRole(['Donor', 'Restaurant', 'NGO', 'Admin']), listingController.updateStatus);

// --- Assistance Registry (Respectful Terminology for Beneficiaries) ---
apiRouter.get('/assistance', authenticateJWT, requireRole(['NGO', 'Admin']), assistanceController.getAssistanceCases);
apiRouter.post('/assistance', authenticateJWT, requireVerifiedNGO, assistanceController.createAssistanceCase);
apiRouter.delete('/assistance/:id', authenticateJWT, requireRole(['NGO', 'Admin']), assistanceController.deleteAssistanceCase);

// Backwards compatibility alias for /needy
apiRouter.get('/needy', authenticateJWT, requireRole(['NGO', 'Admin']), assistanceController.getAssistanceCases);
apiRouter.post('/needy', authenticateJWT, requireVerifiedNGO, assistanceController.createAssistanceCase);
apiRouter.delete('/needy/:id', authenticateJWT, requireRole(['NGO', 'Admin']), assistanceController.deleteAssistanceCase);

// --- Allocations (With Strict Anti-Duplicate Period Protection & Concurrency Mutex) ---
apiRouter.get('/allocations', authenticateJWT, requireRole(['NGO', 'Admin']), assistanceController.getAllocations);
apiRouter.get('/allocations/my', authenticateJWT, requireRole(['Beneficiary', 'Admin']), assistanceController.getMyAllocations);
apiRouter.post('/allocations', authenticateJWT, requireVerifiedNGO, assistanceController.createAllocation);
apiRouter.post('/allocations/confirm', authenticateJWT, requireRole(['Beneficiary', 'NGO', 'Admin']), assistanceController.confirmAllocationReceipt);

// --- Distributions (Permanent Audit History with Privacy Scoping) ---
apiRouter.get('/distributions', authenticateJWT, assistanceController.getDistributions);

// --- Donor Financial Sponsorships ---
apiRouter.get('/sponsorships/my', authenticateJWT, requireRole(['Donor', 'Admin']), sponsorController.getDonorStats);
apiRouter.post('/sponsorships', authenticateJWT, requireRole(['Donor', 'Admin']), sponsorController.createSponsorship);

// --- Admin Console & Operational Settings ---
apiRouter.get('/admin/stats', authenticateJWT, requireAdmin(), adminController.getStats);
apiRouter.get('/admin/settings', adminController.getSettings);
apiRouter.put('/admin/settings', authenticateJWT, requireAdmin(), adminController.updateSettings);
apiRouter.get('/admin/audit-logs', authenticateJWT, requireAdmin(), adminController.getAuditLogs);
apiRouter.get('/admin/complaints', authenticateJWT, requireRole(['Admin', 'NGO']), adminController.getComplaints);
apiRouter.patch('/admin/complaints/:id', authenticateJWT, requireAdmin(), adminController.updateComplaint);

// --- Notifications ---
apiRouter.get('/notifications', authenticateJWT, notificationController.getMyNotifications);
apiRouter.patch('/notifications/:id/read', authenticateJWT, notificationController.markAsRead);
apiRouter.post('/notifications/read-all', authenticateJWT, notificationController.markAllAsRead);

export default apiRouter;
