import { Response } from 'express';
import { dbOps, AssistanceCase, FoodDistribution, FoodAllocation, maskCnic } from '../database/db.ts';

export const assistanceController = {
  // --- OFFLINE BENEFICIARIES (ASSISTANCE CASES REGISTERED BY NGOS) ---
  getAssistanceCases: async (req: any, res: Response) => {
    try {
      const user = req.user;
      
      // Privacy Scope: NGO can only see their own assisted cases; Admin can see all
      const filters = user.role === 'Admin' ? {} : { ngoId: user.id };
      const cases = await dbOps.getAssistanceCases(filters);

      // Mask CNIC for privacy protection
      const sanitized = cases.map(c => ({
        ...c,
        cnic: maskCnic(c.cnic)
      }));

      res.status(200).json({ assistanceCases: sanitized });
    } catch (error: any) {
      console.error('Get assistance cases error:', error);
      res.status(500).json({ error: 'An internal server error occurred while retrieving assistance cases' });
    }
  },

  createAssistanceCase: async (req: any, res: Response) => {
    try {
      const { name, phone, cnic, city, area, address, householdSize, urgency } = req.body;
      const ngoId = req.user.id;
      const ngoUser = await dbOps.getUserById(ngoId);

      if (!name || !cnic) {
        return res.status(400).json({ error: 'Full name and National CNIC are required' });
      }

      // Validate CNIC format (13 digits or formatted XXXXX-XXXXXXX-X)
      const cleanCnic = cnic.trim().replace(/[-\s]/g, '');
      if (cleanCnic.length !== 13 || !/^\d{13}$/.test(cleanCnic)) {
        return res.status(400).json({
          error: 'Invalid CNIC. Must be a valid 13-digit Pakistani National Identity Card number (e.g. 13101-1234567-1).'
        });
      }

      const existing = await dbOps.getAssistanceCaseByCnic(cnic);
      if (existing) {
        return res.status(400).json({ 
          error: `An assistance applicant with National CNIC ${maskCnic(cnic)} is already registered in the system.` 
        });
      }

      const targetCity = city || ngoUser?.city || 'Lahore';
      const targetArea = area || ngoUser?.area || 'Local Area';

      const newCase: AssistanceCase = {
        id: `case-${Date.now()}`,
        name: name.trim(),
        phone: phone ? phone.trim() : 'N/A (No Phone)',
        cnic: cnic.trim(),
        city: targetCity,
        area: targetArea,
        address: address ? address.trim() : `${targetArea}, ${targetCity}`,
        householdSize: Number(householdSize || 4),
        urgency: urgency || 'Medium',
        eligibilityStatus: 'Verified',
        hasSmartphone: false, // Explicitly marked as offline non-digital beneficiary
        registeredByNgoId: ngoId,
        registeredByNgoName: ngoUser?.organizationName || ngoUser?.name || 'Authorized NGO',
        createdAt: new Date().toISOString()
      };

      const created = await dbOps.createAssistanceCase(newCase);

      await dbOps.createAuditLog({
        actorId: req.user.id,
        actorName: req.user.name,
        actorRole: req.user.role,
        action: 'REGISTER_ASSISTANCE_CASE',
        details: `Assistance case created for ${created.name} (${maskCnic(created.cnic)}) in ${created.city} by NGO ${newCase.registeredByNgoName}.`,
        timestamp: new Date().toISOString()
      });

      res.status(201).json({
        message: 'Assistance case successfully registered for community food allocation.',
        assistanceCase: {
          ...created,
          cnic: maskCnic(created.cnic)
        }
      });

    } catch (error: any) {
      console.error('Create assistance case error:', error);
      res.status(500).json({ error: 'An internal server error occurred while creating assistance case' });
    }
  },

  deleteAssistanceCase: async (req: any, res: Response) => {
    try {
      const { id } = req.params;
      const caseItem = await dbOps.getAssistanceCaseById(id);
      if (!caseItem) {
        return res.status(404).json({ error: 'Assistance record not found' });
      }

      // Ownership check: Only registering NGO or Admin can delete
      if (caseItem.registeredByNgoId !== req.user.id && req.user.role !== 'Admin') {
        return res.status(403).json({ error: 'Forbidden: You do not have permission to manage this assistance record' });
      }

      await dbOps.deleteAssistanceCase(id);

      await dbOps.createAuditLog({
        actorId: req.user.id,
        actorName: req.user.name,
        actorRole: req.user.role,
        action: 'DELETE_ASSISTANCE_CASE',
        details: `Removed assistance case ${caseItem.name} (${maskCnic(caseItem.cnic)}) in ${caseItem.city}.`,
        timestamp: new Date().toISOString()
      });

      res.status(200).json({ message: 'Assistance case removed successfully' });
    } catch (error: any) {
      console.error('Delete assistance case error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  // --- FOOD ALLOCATIONS (ATOMIC CONCURRENCY & RATE-LIMIT INTEGRITY) ---
  getAllocations: async (req: any, res: Response) => {
    try {
      const user = req.user;
      const filters = user.role === 'Admin' ? {} : { ngoId: user.id };
      const allocations = await dbOps.getAllocations(filters);
      res.status(200).json({ allocations });
    } catch (error: any) {
      console.error('Get allocations error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  getMyAllocations: async (req: any, res: Response) => {
    try {
      const beneficiaryId = req.user.id;
      const allocations = await dbOps.getAllocations({ beneficiaryId });
      res.status(200).json({ allocations });
    } catch (error: any) {
      console.error('Get my allocations error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  createAllocation: async (req: any, res: Response) => {
    try {
      const { donationId, beneficiaryId, quantity } = req.body;
      const ngoId = req.user.id;
      const ngoUser = await dbOps.getUserById(ngoId);

      if (!donationId || !beneficiaryId || !quantity) {
        return res.status(400).json({ error: 'Donation ID, beneficiary reference, and meal quantity are required' });
      }

      const numQuantity = Number(quantity);
      if (isNaN(numQuantity) || numQuantity <= 0) {
        return res.status(400).json({ error: 'Meal quantity must be a positive integer greater than 0' });
      }

      // Check listing
      const listing = await dbOps.getListingById(donationId);
      if (!listing) {
        return res.status(404).json({ error: 'Food donation listing not found' });
      }

      if (listing.claimedByNgoId !== ngoId && req.user.role !== 'Admin') {
        return res.status(403).json({ error: 'Forbidden: You can only allocate food from donations accepted by your NGO' });
      }

      // Lookup beneficiary (either Digital User or Offline Assistance Case)
      let beneficiaryName = '';
      let beneficiaryCity = listing.city;

      const digitalUser = await dbOps.getUserById(beneficiaryId);
      if (digitalUser && digitalUser.role === 'Beneficiary') {
        beneficiaryName = digitalUser.name;
        beneficiaryCity = digitalUser.city || listing.city;
      } else {
        const offlineCase = await dbOps.getAssistanceCaseById(beneficiaryId);
        if (offlineCase) {
          beneficiaryName = offlineCase.name;
          beneficiaryCity = offlineCase.city || listing.city;
        } else {
          return res.status(404).json({ error: 'Beneficiary or assistance case not found' });
        }
      }

      // Determine active distribution period key (Daily / Weekly / Custom)
      const settings = await dbOps.getSettings();
      const periodMode = settings.distributionPeriodMode || 'Daily';
      
      const now = new Date();
      let periodKey = now.toISOString().split('T')[0]; // "2026-10-05" (Daily)
      if (periodMode === 'Weekly') {
        const weekNum = Math.ceil(now.getDate() / 7);
        periodKey = `${now.getFullYear()}-M${now.getMonth() + 1}-W${weekNum}`;
      }

      // ATOMIC TRANSACTION: Check rate-limit, check remaining quantity, decrement atomically
      const result = await dbOps.createAtomicAllocation({
        donationId,
        ngoId,
        ngoName: ngoUser?.organizationName || ngoUser?.name || 'PlateShare NGO Partner',
        beneficiaryId,
        beneficiaryName,
        quantity: numQuantity,
        city: beneficiaryCity,
        periodKey,
        platformPeriodMode: periodMode
      });

      if (!result.success) {
        // Record blocked duplicate attempt in audit log
        await dbOps.createAuditLog({
          actorId: req.user.id,
          actorName: req.user.name,
          actorRole: 'NGO',
          action: 'DUPLICATE_ALLOCATION_BLOCKED',
          details: `Blocked duplicate allocation attempt for beneficiary ${beneficiaryName} in period ${periodKey}. Reason: ${result.error}`,
          timestamp: new Date().toISOString()
        });

        return res.status(400).json({ error: result.error });
      }

      await dbOps.createAuditLog({
        actorId: req.user.id,
        actorName: req.user.name,
        actorRole: 'NGO',
        action: 'ALLOCATE_FOOD',
        details: `Allocated ${numQuantity} meals of "${listing.foodName}" to ${beneficiaryName} for period ${periodKey}. OTP generated.`,
        timestamp: new Date().toISOString()
      });

      res.status(201).json({
        message: 'Food allocated successfully! Confirmation OTP generated for handover verification.',
        allocation: result.allocation
      });

    } catch (error: any) {
      console.error('Create allocation error:', error);
      res.status(500).json({ error: 'An internal server error occurred while processing food allocation' });
    }
  },

  confirmAllocationReceipt: async (req: any, res: Response) => {
    try {
      const { allocationId, verificationMethod, otp } = req.body;
      const user = req.user;

      if (!allocationId) {
        return res.status(400).json({ error: 'Allocation ID is required' });
      }

      const db = await dbOps.getAllocations();
      const allocation = db.find(a => a.id === allocationId);
      if (!allocation) {
        return res.status(404).json({ error: 'Allocation record not found' });
      }

      // Verification checks
      const method = verificationMethod || 'Manual_NGO';
      if (method === 'OTP') {
        if (!otp || otp.trim() !== allocation.otpCode) {
          return res.status(400).json({ error: 'Invalid 4-digit confirmation voucher OTP' });
        }
      }

      const result = await dbOps.confirmAllocationReceipt(
        allocationId, 
        method, 
        user.name
      );

      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      await dbOps.createAuditLog({
        actorId: user.id,
        actorName: user.name,
        actorRole: user.role,
        action: 'DELIVERY_CONFIRMED',
        details: `Confirmed delivery of ${allocation.quantity} meals to ${allocation.beneficiaryName} via ${method}.`,
        timestamp: new Date().toISOString()
      });

      res.status(200).json({
        message: 'Food delivery and receipt confirmed successfully! Permanent distribution record saved.',
        allocation: result.allocation,
        distribution: result.distribution
      });

    } catch (error: any) {
      console.error('Confirm allocation error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  // --- DISTRIBUTIONS (RESTRICTED PRIVACY ACCESS) ---
  getDistributions: async (req: any, res: Response) => {
    try {
      const user = req.user;
      
      // Privacy Enforcement: Donors and Restaurants get anonymized totals; only Admin & NGOs get operational view
      if (user.role === 'Donor' || user.role === 'Restaurant') {
        const allDist = await dbOps.getDistributions();
        // Return strictly sanitized summary metrics without any beneficiary personal data
        return res.status(200).json({
          totalDistributionsCount: allDist.length,
          totalMealsDistributed: allDist.reduce((acc, d) => acc + d.quantity, 0),
          anonymizedRecent: allDist.slice(0, 10).map(d => ({
            id: d.id,
            foodName: d.foodName,
            quantity: d.quantity,
            city: d.city,
            timestamp: d.timestamp
          }))
        });
      }

      const filters = user.role === 'Admin' ? {} : { ngoId: user.id };
      const distributions = await dbOps.getDistributions(filters);

      res.status(200).json({ distributions });
    } catch (error: any) {
      console.error('Get distributions error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  }
};
