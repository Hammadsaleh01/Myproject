import { Response } from 'express';
import { dbOps } from '../database/db.ts';

export const adminController = {
  getStats: async (req: any, res: Response) => {
    try {
      const { city, province } = req.query;

      let users = await dbOps.getUsers();
      let listings = await dbOps.getListings();
      let needyPeople = await dbOps.getNeedyPeople();
      let distributions = await dbOps.getDistributions();
      let allocations = await dbOps.getAllocations();
      let complaints = await dbOps.getComplaints();
      let sponsorships = await dbOps.getSponsorships();
      const settings = await dbOps.getPlatformSettings();

      // Apply city or province filter if requested by Admin
      if (city && city !== 'All Cities' && city !== 'Pakistan') {
        const cleanCity = (city as string).toLowerCase().trim();
        users = users.filter(u => u.city?.toLowerCase() === cleanCity);
        listings = listings.filter(l => l.city?.toLowerCase() === cleanCity);
        needyPeople = needyPeople.filter(n => n.city?.toLowerCase() === cleanCity);
        distributions = distributions.filter(d => d.city?.toLowerCase() === cleanCity);
        allocations = allocations.filter(a => a.city?.toLowerCase() === cleanCity);
        complaints = complaints.filter(c => c.city?.toLowerCase() === cleanCity);
      } else if (province && province !== 'All Provinces') {
        const cleanProv = (province as string).toLowerCase().trim();
        users = users.filter(u => u.province?.toLowerCase() === cleanProv);
        listings = listings.filter(l => l.province?.toLowerCase() === cleanProv);
        needyPeople = needyPeople.filter(n => n.province?.toLowerCase() === cleanProv);
      }

      const restaurants = users.filter(u => u.role === 'Restaurant');
      const verifiedRestaurants = restaurants.filter(u => u.verificationStatus === 'Verified' || u.verificationStatus === 'Approved');
      const pendingRestaurants = restaurants.filter(u => u.verificationStatus === 'Pending');

      const ngos = users.filter(u => u.role === 'NGO');
      const verifiedNgos = ngos.filter(u => u.verificationStatus === 'Verified' || u.verificationStatus === 'Approved');
      const pendingNgos = ngos.filter(u => u.verificationStatus === 'Pending');

      const donors = users.filter(u => u.role === 'Donor');
      const digitalBeneficiaries = users.filter(u => u.role === 'Beneficiary');
      const totalBeneficiaries = digitalBeneficiaries.length + needyPeople.length;

      const activeDonations = listings.filter(l => l.status === 'Available' || l.status === 'Matched');
      const acceptedDonations = listings.filter(l => l.status === 'Accepted' || l.status === 'Pickup_Scheduled');
      const completedDonations = listings.filter(l => l.status === 'Completed' || l.status === 'Distributed');
      const expiredDonations = listings.filter(l => l.status === 'Expired');

      const activeAllocations = allocations.filter(a => a.status === 'Active');
      const deliveredAllocations = allocations.filter(a => a.status === 'Delivered');

      const totalMealsDistributed = distributions.reduce((acc, d) => acc + (d.quantity || 1), 0);
      const totalSponsoredPkr = sponsorships.reduce((acc, s) => acc + (s.amountPkr || 0), 0);
      const totalMealsSponsored = sponsorships.reduce((acc, s) => acc + (s.mealsSponsored || 0), 0);

      const pendingComplaints = complaints.filter(c => c.status === 'Pending' || c.status === 'Under_Investigation');

      res.status(200).json({
        stats: {
          filterScope: city || province || 'Pakistan National',
          totalUsers: users.length,
          restaurantsCount: restaurants.length,
          verifiedRestaurantsCount: verifiedRestaurants.length,
          pendingRestaurantsCount: pendingRestaurants.length,
          ngosCount: ngos.length,
          verifiedNgosCount: verifiedNgos.length,
          pendingNgosCount: pendingNgos.length,
          donorsCount: donors.length,
          digitalBeneficiariesCount: digitalBeneficiaries.length,
          offlineBeneficiariesCount: needyPeople.length,
          totalBeneficiariesCount: totalBeneficiaries,
          activeDonationsCount: activeDonations.length,
          acceptedDonationsCount: acceptedDonations.length,
          completedDonationsCount: completedDonations.length,
          expiredDonationsCount: expiredDonations.length,
          totalDonationsCount: listings.length,
          activeAllocationsCount: activeAllocations.length,
          deliveredAllocationsCount: deliveredAllocations.length,
          totalDistributionsCount: distributions.length,
          totalMealsDistributed,
          totalSponsoredPkr,
          totalMealsSponsored,
          pendingComplaintsCount: pendingComplaints.length,
          totalComplaintsCount: complaints.length,
          distributionPeriodMode: settings.distributionPeriodMode,
          defaultCountry: settings.defaultCountry
        },
        settings
      });

    } catch (error: any) {
      console.error('Get admin stats error:', error);
      res.status(500).json({ error: 'An internal server error occurred while retrieving platform statistics' });
    }
  },

  getSettings: async (req: any, res: Response) => {
    try {
      const settings = await dbOps.getPlatformSettings();
      res.status(200).json({ settings });
    } catch (error: any) {
      console.error('Get settings error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  updateSettings: async (req: any, res: Response) => {
    try {
      const { distributionPeriodMode, maxMealsPerPeriodPerBeneficiary, maxMatchingRadiusKm } = req.body;
      const updates: any = {};

      if (distributionPeriodMode) {
        if (!['Daily', 'Weekly', 'Custom'].includes(distributionPeriodMode)) {
          return res.status(400).json({ error: 'Distribution period must be Daily, Weekly, or Custom' });
        }
        updates.distributionPeriodMode = distributionPeriodMode;
      }

      if (maxMealsPerPeriodPerBeneficiary !== undefined) {
        updates.maxMealsPerPeriodPerBeneficiary = Number(maxMealsPerPeriodPerBeneficiary);
      }

      if (maxMatchingRadiusKm !== undefined) {
        updates.maxMatchingRadiusKm = Number(maxMatchingRadiusKm);
      }

      const updated = await dbOps.updatePlatformSettings(updates);

      await dbOps.createAuditLog({
        actorId: req.user.id,
        actorName: req.user.name,
        actorRole: 'Admin',
        action: 'UPDATE_SETTINGS',
        details: `Platform distribution period rule set to ${updated.distributionPeriodMode}.`
      });

      res.status(200).json({
        message: 'Platform settings updated successfully!',
        settings: updated
      });

    } catch (error: any) {
      console.error('Update settings error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  getAuditLogs: async (req: any, res: Response) => {
    try {
      const logs = await dbOps.getAuditLogs();
      res.status(200).json({ auditLogs: logs });
    } catch (error: any) {
      console.error('Get audit logs error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  getComplaints: async (req: any, res: Response) => {
    try {
      const { city } = req.query;
      let complaints = await dbOps.getComplaints();
      if (city && city !== 'All Cities' && city !== 'Pakistan') {
        complaints = complaints.filter(c => (c.city || '').toLowerCase() === (city as string).toLowerCase().trim());
      }
      res.status(200).json({ complaints });
    } catch (error: any) {
      console.error('Get complaints error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  updateComplaint: async (req: any, res: Response) => {
    try {
      const { id } = req.params;
      const { status, adminNotes } = req.body;

      if (!status) {
        return res.status(400).json({ error: 'Status is required' });
      }

      const updated = await dbOps.updateComplaintStatus(id, status, adminNotes);
      if (!updated) {
        return res.status(404).json({ error: 'Complaint not found' });
      }

      res.status(200).json({
        message: `Complaint status updated to ${status}`,
        complaint: updated
      });
    } catch (error: any) {
      console.error('Update complaint error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  }
};
