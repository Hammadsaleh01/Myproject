import { Response } from 'express';
import { dbOps } from '../database/db.ts';

export const notificationController = {
  getMyNotifications: async (req: any, res: Response) => {
    try {
      const userId = req.user.id;
      const notifications = await dbOps.getNotifications(userId);
      const unreadCount = notifications.filter(n => !n.isRead).length;

      res.status(200).json({ 
        notifications,
        unreadCount
      });
    } catch (error: any) {
      console.error('Fetch notifications error:', error);
      res.status(500).json({ error: 'An internal server error occurred while fetching notifications' });
    }
  },

  markAsRead: async (req: any, res: Response) => {
    try {
      const { id } = req.params;
      const userId = req.user.id;

      const success = await dbOps.markNotificationAsRead(id);
      if (!success) {
        return res.status(404).json({ error: 'Notification not found' });
      }

      const notifications = await dbOps.getNotifications(userId);
      const unreadCount = notifications.filter(n => !n.isRead).length;

      res.status(200).json({ 
        message: 'Notification marked as read',
        unreadCount
      });
    } catch (error: any) {
      console.error('Mark notification read error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  markAllAsRead: async (req: any, res: Response) => {
    try {
      const userId = req.user.id;
      await dbOps.markAllNotificationsAsRead(userId);

      res.status(200).json({ 
        message: 'All notifications marked as read',
        unreadCount: 0
      });
    } catch (error: any) {
      console.error('Mark all read error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  }
};
