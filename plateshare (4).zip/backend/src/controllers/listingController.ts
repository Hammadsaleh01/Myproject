import { Request, Response } from 'express';
import { 
  dbOps, 
  FoodListing, 
  matchSuitableNgos, 
  DonationStatus 
} from '../database/db.ts';
import { getCoordinatesForCity, getCityDetails } from '../database/pakistanLocations.ts';

export const listingController = {
  // --- CREATE DONATION (VERIFIED RESTAURANT OR DONOR) ---
  createListing: async (req: any, res: Response) => {
    try {
      const { 
        foodName, 
        foodCategory, 
        quantity, 
        unit, 
        description, 
        preparationTime, 
        availableTime, 
        pickupDeadline, 
        storageCondition, 
        province, 
        city, 
        area, 
        pickupAddress, 
        image 
      } = req.body;

      const donorId = req.user.id;
      const donorUser = await dbOps.getUserById(donorId);

      if (!donorUser) {
        return res.status(404).json({ error: 'User account not found' });
      }

      // STRICT BUSINESS RULE: Unverified restaurants cannot create donations
      if (donorUser.role === 'Restaurant' && donorUser.verificationStatus !== 'Verified' && donorUser.verificationStatus !== 'Approved') {
        return res.status(403).json({ 
          error: `Permission Denied: Only verified restaurants can create food donation listings. Your account status is currently "${donorUser.verificationStatus}". Please wait for Admin approval.` 
        });
      }

      // Validate required fields
      if (!foodName || !foodCategory || quantity === undefined || !pickupAddress || !pickupDeadline) {
        return res.status(400).json({ 
          error: 'Food Name, Category, Quantity, Pickup Address, and Pickup Deadline are required fields' 
        });
      }

      const numQuantity = Number(quantity);
      if (isNaN(numQuantity) || numQuantity <= 0) {
        return res.status(400).json({ error: 'Quantity must be a positive number greater than 0' });
      }

      const selectedCity = city || donorUser.city || 'Lahore';
      const cityDetails = getCityDetails(selectedCity);
      const selectedProvince = province || donorUser.province || cityDetails?.province || 'Punjab';
      const selectedArea = area || donorUser.area || cityDetails?.areas[0] || 'Central Area';
      const coordinates = getCoordinatesForCity(selectedCity);

      const listingId = `listing-${Date.now()}`;

      // Intelligent Multi-criteria matching with verified NGOs across Pakistan
      const allUsers = await dbOps.getUsers();
      const matchedNgos = matchSuitableNgos(
        {
          coordinates,
          city: selectedCity,
          area: selectedArea,
          quantity: numQuantity
        },
        allUsers,
        25 // 25 km standard radius
      );

      const newListing: FoodListing = {
        id: listingId,
        donorId,
        donorName: donorUser.name,
        donorRole: donorUser.role,
        foodName: foodName.trim(),
        foodCategory,
        quantity: numQuantity,
        remainingQuantity: numQuantity,
        allocatedQuantity: 0,
        unit: unit || 'meals',
        description: description ? description.trim() : '',
        preparationTime: preparationTime || 'Just prepared',
        availableTime: availableTime || 'Ready for collection',
        pickupDeadline: pickupDeadline.trim(),
        storageCondition: storageCondition || 'Hot/Insulated',
        province: selectedProvince,
        city: selectedCity,
        area: selectedArea,
        pickupAddress: pickupAddress.trim(),
        coordinates,
        image: image || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=500&auto=format&fit=crop&q=60',
        status: 'Available',
        matchedNgos,
        createdAt: new Date().toISOString()
      };

      await dbOps.createListing(newListing);

      // Audit log entry
      await dbOps.createAuditLog({
        actorId: donorUser.id,
        actorName: donorUser.name,
        actorRole: donorUser.role,
        action: 'CREATE_DONATION',
        details: `Created surplus food donation "${newListing.foodName}" (${newListing.quantity} ${newListing.unit}) in ${newListing.city}, ${newListing.area}. Matched with ${matchedNgos.length} NGOs.`,
        timestamp: new Date().toISOString()
      });

      // Dispatch notifications to top matched NGOs
      for (const ngo of matchedNgos.slice(0, 3)) {
        await dbOps.createNotification({
          id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          userId: ngo.ngoId,
          title: `Surplus Food Alert: ${newListing.city}`,
          message: `${donorUser.name} posted ${newListing.quantity} ${newListing.unit} of "${newListing.foodName}" near you (${ngo.distanceKm} km away). Available until ${newListing.pickupDeadline}.`,
          type: 'DONATION_MATCH',
          metadata: { listingId: newListing.id, city: newListing.city },
          isRead: false,
          createdAt: new Date().toISOString()
        });
      }

      res.status(201).json({
        message: 'Food donation posted successfully! Suitable local NGOs have been notified.',
        listing: newListing,
        matchedCount: matchedNgos.length
      });

    } catch (error: any) {
      console.error('Create listing error:', error);
      res.status(500).json({ error: 'An internal server error occurred while creating food listing' });
    }
  },

  // --- GET ALL LISTINGS ---
  getAllListings: async (req: Request, res: Response) => {
    try {
      const { city, province, status } = req.query;
      const listings = await dbOps.getListings({
        city: city as string,
        province: province as string,
        status: status as DonationStatus
      });

      res.status(200).json({
        total: listings.length,
        listings
      });
    } catch (error: any) {
      console.error('Fetch listings error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  // --- GET MY LISTINGS ---
  getMyListings: async (req: any, res: Response) => {
    try {
      const userId = req.user.id;
      const user = await dbOps.getUserById(userId);
      
      let listings: FoodListing[] = [];
      if (user?.role === 'NGO') {
        listings = await dbOps.getListingsClaimedByNgo(userId);
      } else {
        listings = await dbOps.getListingsByDonor(userId);
      }

      res.status(200).json({ listings });
    } catch (error: any) {
      console.error('Fetch my listings error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  // --- GET SINGLE LISTING ---
  getListingById: async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const listing = await dbOps.getListingById(id);
      
      if (!listing) {
        return res.status(404).json({ error: 'Food donation listing not found' });
      }

      res.status(200).json({ listing });
    } catch (error: any) {
      console.error('Fetch listing by id error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  },

  // --- ACCEPT / CLAIM DONATION (VERIFIED NGO) ---
  acceptListing: async (req: any, res: Response) => {
    try {
      const { id } = req.params;
      const ngoId = req.user.id;
      const ngoUser = await dbOps.getUserById(ngoId);

      if (!ngoUser || ngoUser.role !== 'NGO') {
        return res.status(403).json({ error: 'Forbidden: Only registered NGOs can accept food donations' });
      }

      if (ngoUser.verificationStatus !== 'Verified' && ngoUser.verificationStatus !== 'Approved') {
        return res.status(403).json({ 
          error: `Verification Required: Your NGO status is currently "${ngoUser.verificationStatus}". Only verified NGOs can claim donations.` 
        });
      }

      const listing = await dbOps.getListingById(id);
      if (!listing) {
        return res.status(404).json({ error: 'Food donation listing not found' });
      }

      // Check valid lifecycle transitions
      if (listing.status !== 'Available') {
        return res.status(400).json({ 
          error: `Cannot claim donation: It has already reached status "${listing.status}" by another party.` 
        });
      }

      const result = await dbOps.claimListingByNgo(
        id, 
        ngoId, 
        ngoUser.organizationName || ngoUser.name
      );

      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      await dbOps.createAuditLog({
        actorId: ngoUser.id,
        actorName: ngoUser.name,
        actorRole: 'NGO',
        action: 'ACCEPT_DONATION',
        details: `NGO ${ngoUser.organizationName || ngoUser.name} accepted donation "${result.listing?.foodName}" (${result.listing?.quantity} ${result.listing?.unit}) in ${result.listing?.city}.`,
        timestamp: new Date().toISOString()
      });

      res.status(200).json({
        message: 'Donation accepted successfully! You can now schedule pickup in your NGO console.',
        listing: result.listing
      });

    } catch (error: any) {
      console.error('Accept listing error:', error);
      res.status(500).json({ error: 'An internal server error occurred while accepting listing' });
    }
  },

  // --- SCHEDULE PICKUP (NGO IDOR PROTECTED) ---
  schedulePickup: async (req: any, res: Response) => {
    try {
      const { id } = req.params;
      const { scheduledTime } = req.body;
      const ngoId = req.user.id;

      const listing = await dbOps.getListingById(id);
      if (!listing) {
        return res.status(404).json({ error: 'Food listing not found' });
      }

      // IDOR ownership guard
      if (listing.claimedByNgoId !== ngoId && req.user.role !== 'Admin') {
        return res.status(403).json({ error: 'Forbidden: You can only schedule pickup for donations accepted by your NGO' });
      }

      const result = await dbOps.schedulePickup(id, ngoId, scheduledTime);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      res.status(200).json({
        message: `Pickup scheduled successfully! Present OTP ${result.otp} to restaurant during collection.`,
        listing: result.listing,
        otp: result.otp
      });
    } catch (error: any) {
      console.error('Schedule pickup error:', error);
      res.status(500).json({ error: 'An internal server error occurred while scheduling pickup' });
    }
  },

  // --- VERIFY PICKUP OTP AT HANDOVER ---
  verifyPickupOtp: async (req: any, res: Response) => {
    try {
      const { id } = req.params;
      const { otp } = req.body;

      if (!otp) {
        return res.status(400).json({ error: 'Pickup verification OTP code is required' });
      }

      const listing = await dbOps.getListingById(id);
      if (!listing) {
        return res.status(404).json({ error: 'Food listing not found' });
      }

      // IDOR ownership guard
      if (listing.donorId !== req.user.id && listing.claimedByNgoId !== req.user.id && req.user.role !== 'Admin') {
        return res.status(403).json({ error: 'Forbidden: You do not have permission to verify handover for this listing' });
      }

      const result = await dbOps.verifyPickupOtp(id, otp, req.user.id);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      await dbOps.createAuditLog({
        actorId: req.user.id,
        actorName: req.user.name,
        actorRole: req.user.role,
        action: 'VERIFY_PICKUP',
        details: `Pickup verified via OTP for donation "${result.listing?.foodName}" in ${result.listing?.city}. Status updated to Picked_Up.`,
        timestamp: new Date().toISOString()
      });

      res.status(200).json({
        message: 'Pickup OTP verified successfully! Food status is now Picked_Up and ready for distribution.',
        listing: result.listing
      });
    } catch (error: any) {
      console.error('Verify pickup OTP error:', error);
      res.status(500).json({ error: 'An internal server error occurred while verifying pickup' });
    }
  },

  // --- EDIT LISTING (IDOR PROTECTED) ---
  editListing: async (req: any, res: Response) => {
    try {
      const { id } = req.params;
      const { foodName, foodCategory, quantity, unit, description, pickupAddress, pickupDeadline, city, area } = req.body;
      const donorId = req.user.id;

      const listing = await dbOps.getListingById(id);
      if (!listing) {
        return res.status(404).json({ error: 'Food listing not found' });
      }

      // IDOR ownership check
      if (listing.donorId !== donorId && req.user.role !== 'Admin') {
        return res.status(403).json({ error: 'Forbidden: You do not have permission to edit this listing' });
      }

      if (listing.status === 'Accepted' || listing.status === 'Picked_Up' || listing.status === 'Completed' || listing.status === 'Distributed') {
        return res.status(400).json({ error: `Cannot edit listing after it has reached status: ${listing.status}` });
      }

      const updates: Partial<FoodListing> = {};
      if (foodName !== undefined) updates.foodName = foodName.trim();
      if (foodCategory !== undefined) updates.foodCategory = foodCategory;
      if (quantity !== undefined) {
        const q = Number(quantity);
        if (q <= 0) return res.status(400).json({ error: 'Quantity must be positive' });
        updates.quantity = q;
        updates.remainingQuantity = q;
      }
      if (unit !== undefined) updates.unit = unit;
      if (description !== undefined) updates.description = description;
      if (pickupAddress !== undefined) updates.pickupAddress = pickupAddress;
      if (pickupDeadline !== undefined) updates.pickupDeadline = pickupDeadline;
      if (city !== undefined) updates.city = city;
      if (area !== undefined) updates.area = area;

      const updated = await dbOps.updateListing(id, updates);

      res.status(200).json({
        message: 'Food listing updated successfully!',
        listing: updated
      });

    } catch (error: any) {
      console.error('Edit listing error:', error);
      res.status(500).json({ error: 'An internal server error occurred while updating listing' });
    }
  },

  // --- DELETE LISTING (IDOR PROTECTED) ---
  deleteListing: async (req: any, res: Response) => {
    try {
      const { id } = req.params;
      const donorId = req.user.id;

      const listing = await dbOps.getListingById(id);
      if (!listing) {
        return res.status(404).json({ error: 'Food listing not found' });
      }

      // IDOR ownership check
      if (listing.donorId !== donorId && req.user.role !== 'Admin') {
        return res.status(403).json({ error: 'Forbidden: You do not have permission to delete this listing' });
      }

      if (listing.status === 'Distributed' || listing.status === 'Completed') {
        return res.status(400).json({ error: 'Cannot delete a donation that has already been distributed or completed' });
      }

      await dbOps.deleteListing(id);

      await dbOps.createAuditLog({
        actorId: req.user.id,
        actorName: req.user.name,
        actorRole: req.user.role,
        action: 'DELETE_DONATION',
        details: `Deleted donation "${listing.foodName}" in ${listing.city}.`,
        timestamp: new Date().toISOString()
      });

      res.status(200).json({ message: 'Food listing deleted successfully!' });

    } catch (error: any) {
      console.error('Delete listing error:', error);
      res.status(500).json({ error: 'An internal server error occurred while deleting listing' });
    }
  },

  // --- UPDATE STATUS (IDOR PROTECTED) ---
  updateStatus: async (req: any, res: Response) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const user = req.user;

      const validStatuses: DonationStatus[] = [
        'Draft', 'Available', 'Matched', 'Accepted', 'Pickup_Scheduled', 
        'Picked_Up', 'Distributed', 'Completed', 'Cancelled', 'Expired', 'Failed'
      ];

      if (!status || !validStatuses.includes(status)) {
        return res.status(400).json({ error: `Valid status required (${validStatuses.join(', ')})` });
      }

      const listing = await dbOps.getListingById(id);
      if (!listing) {
        return res.status(404).json({ error: 'Food listing not found' });
      }

      // IDOR Ownership verification: Only owner, claimed NGO, or Admin can update status
      const isOwner = listing.donorId === user.id;
      const isClaimingNgo = listing.claimedByNgoId === user.id;
      const isAdmin = user.role === 'Admin';

      if (!isOwner && !isClaimingNgo && !isAdmin) {
        return res.status(403).json({ error: 'Forbidden: You do not have permission to modify this donation status' });
      }

      if (listing.status === 'Completed' && status !== 'Completed' && !isAdmin) {
        return res.status(400).json({ error: 'Completed donations cannot be reopened' });
      }

      const updated = await dbOps.updateListing(id, { status });

      await dbOps.createAuditLog({
        actorId: user.id,
        actorName: user.name,
        actorRole: user.role,
        action: 'UPDATE_DONATION_STATUS',
        details: `Donation "${listing.foodName}" status transitioned from "${listing.status}" to "${status}".`,
        timestamp: new Date().toISOString()
      });

      res.status(200).json({
        message: `Listing status updated to ${status} successfully!`,
        listing: updated
      });

    } catch (error: any) {
      console.error('Update status error:', error);
      res.status(500).json({ error: 'An internal server error occurred' });
    }
  }
};
