import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { UserRole, dbOps } from '../database/db.ts';

// Fail-safe JWT Secret Configuration
const getJwtSecret = (): string => {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === 'production') {
      console.error('FATAL: JWT_SECRET environment variable is missing in production mode.');
      throw new Error('Server configuration error: JWT_SECRET required.');
    }
    // Secure fallback for local evaluation and FYP demo testing
    return 'plateshare-pakistan-secure-fyp-secret-key-2026';
  }
  return secret;
};

export const JWT_SECRET = getJwtSecret();

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: UserRole;
    name: string;
  };
}

export const authenticateJWT = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({ error: 'Unauthorized: No authorization token provided' });
  }

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return res.status(401).json({ error: 'Unauthorized: Invalid token format. Use Bearer <token>' });
  }

  const token = parts[1];

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Forbidden: Invalid or expired session token. Please log in again.' });
    }
    
    req.user = decoded as AuthenticatedRequest['user'];
    next();
  });
};

export const requireRole = (roles: Array<UserRole>) => {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized: Authentication required' });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ 
        error: `Forbidden: Access denied. Required role: ${roles.join(' or ')}. Your active role is ${req.user.role}.` 
      });
    }

    next();
  };
};

export const requireAdmin = () => requireRole(['Admin']);

export const requireVerifiedRestaurant = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized: Authentication required' });
  }

  if (req.user.role !== 'Restaurant' && req.user.role !== 'Admin') {
    return res.status(403).json({ error: 'Forbidden: Only restaurants can perform this action' });
  }

  if (req.user.role === 'Restaurant') {
    const user = await dbOps.getUserById(req.user.id);
    if (!user || (user.verificationStatus !== 'Verified' && user.verificationStatus !== 'Approved')) {
      return res.status(403).json({ 
        error: `Account Verification Required: Your restaurant is currently in "${user?.verificationStatus || 'Pending'}" status. Publishing donations requires verification by a PlateShare Administrator.` 
      });
    }
  }

  next();
};

export const requireVerifiedNGO = async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Unauthorized: Authentication required' });
  }

  if (req.user.role !== 'NGO' && req.user.role !== 'Admin') {
    return res.status(403).json({ error: 'Forbidden: Only registered NGOs can perform this action' });
  }

  if (req.user.role === 'NGO') {
    const user = await dbOps.getUserById(req.user.id);
    if (!user || (user.verificationStatus !== 'Verified' && user.verificationStatus !== 'Approved')) {
      return res.status(403).json({ 
        error: `NGO Verification Required: Your organization is currently in "${user?.verificationStatus || 'Pending'}" status. Claiming surplus food and managing distributions requires PlateShare Admin verification.` 
      });
    }
  }

  next();
};
