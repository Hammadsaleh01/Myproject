import fs from 'fs';
import path from 'path';
import { 
  ALL_PAKISTAN_CITIES, 
  getCoordinatesForCity, 
  getCityDetails 
} from './pakistanLocations.ts';

// Define the DB file path
const DB_FILE = path.join(process.cwd(), 'plateshare_db.json');

export type UserRole = 'Donor' | 'NGO' | 'Restaurant' | 'Admin' | 'Beneficiary';
export type VerificationStatus = 'Pending' | 'Under_Review' | 'Approved' | 'Verified' | 'Suspended' | 'Rejected' | 'N/A';
export type DonationStatus = 
  | 'Draft' 
  | 'Available' 
  | 'Matched' 
  | 'Accepted' 
  | 'Pickup_Scheduled' 
  | 'Picked_Up' 
  | 'Distributed' 
  | 'Completed' 
  | 'Cancelled' 
  | 'Expired' 
  | 'Failed';

export type PickupStatus = 'Pending' | 'Scheduled' | 'In_Progress' | 'Picked_Up' | 'Failed' | 'Cancelled';

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  password?: string; // Secure bcrypt hash
  role: UserRole;
  country?: string; // Pakistan
  province?: string; // Punjab, Sindh, KPK, ICT, Balochistan, AJK, GB
  city: string; // Lahore, Karachi, Islamabad, Peshawar, Abbottabad, etc.
  area: string;
  address: string;
  coordinates?: Coordinates;
  verificationStatus: VerificationStatus;
  profileImage?: string;
  bio?: string;
  notificationPrefs?: {
    email?: boolean;
    sms?: boolean;
    push?: boolean;
  };
  
  // Restaurant specific fields
  operatingHours?: string;
  contactPerson?: string;
  foodCategories?: string[];
  
  // NGO specific fields
  organizationName?: string;
  registrationNumber?: string;
  capacity?: number; // max meals capable of handling per dispatch
  available?: boolean;
  serviceAreas?: string[];
  
  // Beneficiary specific fields
  cnic?: string; // Securely stored, never exposed publicly
  householdSize?: number;
  urgency?: 'Low' | 'Medium' | 'High' | 'Emergency';
  eligibilityStatus?: 'Pending' | 'Under_Review' | 'Verified' | 'Temporarily_Eligible' | 'Emergency' | 'Expired' | 'Suspended' | 'Rejected';
  hasSmartphone?: boolean;
  
  // Password reset tokens
  resetPasswordToken?: string;
  resetPasswordExpires?: string;

  createdAt: string;
}

export interface MatchedNgoInfo {
  ngoId: string;
  ngoName: string;
  phone: string;
  city: string;
  area: string;
  distanceKm: number;
  capacity: number;
  score: number;
}

export interface FoodListing {
  id: string;
  donorId: string;
  donorName: string;
  donorRole: UserRole;
  foodName: string;
  foodCategory: string;
  quantity: number;
  remainingQuantity: number;
  allocatedQuantity: number;
  unit: 'meals' | 'kg' | 'packs';
  description: string;
  preparationTime: string;
  availableTime: string;
  pickupDeadline: string;
  storageCondition: 'Hot/Insulated' | 'Refrigerated' | 'Ambient';
  province: string;
  city: string;
  area: string;
  pickupAddress: string;
  coordinates: Coordinates;
  image: string;
  status: DonationStatus;
  claimedByNgoId?: string;
  claimedByNgoName?: string;
  pickupStatus?: PickupStatus;
  pickupScheduledTime?: string;
  pickupOtp?: string;
  matchedNgos?: MatchedNgoInfo[];
  createdAt: string;
  updatedAt?: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type?: string;
  metadata?: Record<string, any>;
  isRead: boolean;
  createdAt: string;
}

// Respectful Assistance Case model (replaces NeedyPerson)
export interface AssistanceCase {
  id: string;
  name: string;
  phone: string;
  cnic: string; // Secure on backend; masked for authorized views
  province?: string;
  city: string;
  area: string;
  address: string;
  householdSize: number;
  urgency: 'Low' | 'Medium' | 'High' | 'Emergency';
  eligibilityStatus: 'Verified' | 'Under_Review' | 'Suspended' | 'Temporarily_Eligible';
  hasSmartphone: boolean; // false for NGO-assisted cases
  registeredByNgoId: string;
  registeredByNgoName: string;
  createdAt: string;
}

export interface FoodDistribution {
  id: string;
  allocationId?: string;
  donationId: string;
  foodName?: string;
  beneficiaryId: string; // Reference to AssistanceCase or User id
  beneficiaryName: string;
  volunteerId: string;
  volunteerName: string;
  quantity: number;
  city?: string;
  distributionPeriod: string; // e.g. "2026-10-05"
  verificationMethod: 'OTP' | 'QR' | 'Manual_NGO';
  timestamp: string;
  notes: string;
}

export interface FoodAllocation {
  id: string;
  donationId: string;
  foodName: string;
  ngoId: string;
  ngoName: string;
  beneficiaryId: string; // Reference ID, NOT raw CNIC
  beneficiaryName: string;
  quantity: number;
  city: string;
  distributionPeriod: string; // e.g. "2026-10-05"
  status: 'Active' | 'Delivered' | 'Cancelled';
  otpCode: string;
  createdAt: string;
  deliveredAt?: string;
  verificationMethod?: 'OTP' | 'QR' | 'Manual_NGO';
  staffMember?: string;
}

export interface DonorSponsorship {
  id: string;
  donorId: string;
  donorName: string;
  donorEmail: string;
  amountPkr: number;
  mealsSponsored: number;
  campaign: string;
  city?: string;
  status: 'Received' | 'Allocated_To_Meals' | 'Fully_Distributed';
  allocatedDonationIds: string[];
  createdAt: string;
}

export interface Complaint {
  id: string;
  reporterId: string;
  reporterName: string;
  reporterRole: UserRole;
  targetId?: string;
  targetName?: string;
  category: 'Food Quality' | 'No Show Pickup' | 'Misbehavior' | 'Hygiene' | 'Other';
  description: string;
  city?: string;
  status: 'Pending' | 'Under_Investigation' | 'Resolved';
  adminNotes?: string;
  createdAt: string;
}

export interface PlatformSettings {
  distributionPeriodMode: 'Daily' | 'Weekly' | 'Custom';
  maxMealsPerPeriodPerBeneficiary: number;
  defaultCountry: string;
  maxMatchingRadiusKm: number;
  availableProvinces: string[];
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  details: string;
  timestamp: string;
}

export interface DatabaseSchema {
  users: User[];
  listings: FoodListing[];
  notifications: Notification[];
  assistanceCases: AssistanceCase[];
  distributions: FoodDistribution[];
  allocations: FoodAllocation[];
  sponsorships: DonorSponsorship[];
  complaints: Complaint[];
  platformSettings: PlatformSettings;
  auditLogs: AuditLog[];
}

// Utility: Mask sensitive CNIC (shows only last 4 digits)
export function maskCnic(cnic?: string): string {
  if (!cnic) return 'Verified ID';
  const clean = cnic.replace(/[-\s]/g, '');
  if (clean.length < 4) return '****';
  return `****-****${clean.slice(-4)}`;
}

// Haversine formula to compute accurate distance in kilometers
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Number(d.toFixed(1));
}

// Multi-criteria matching logic across Pakistan (Distance + Verification + Capacity + Availability + Service Area / City)
export function matchSuitableNgos(
  listing: { coordinates: Coordinates; city: string; area: string; quantity: number },
  allUsers: User[],
  maxRadiusKm = 25
): MatchedNgoInfo[] {
  const verifiedNgos = allUsers.filter(u => 
    u.role === 'NGO' && 
    (u.verificationStatus === 'Verified' || u.verificationStatus === 'Approved') &&
    (u.available !== false)
  );

  const matched: MatchedNgoInfo[] = [];

  for (const ngo of verifiedNgos) {
    const defaultCoords = getCoordinatesForCity(ngo.city || listing.city);
    const ngoCoords = ngo.coordinates || defaultCoords;

    const distanceKm = calculateDistanceKm(
      listing.coordinates.lat,
      listing.coordinates.lng,
      ngoCoords.lat,
      ngoCoords.lng
    );

    const isSameCity = (ngo.city || '').toLowerCase() === (listing.city || '').toLowerCase();

    // Include if within radius or explicitly in the same city
    if (distanceKm <= maxRadiusKm || isSameCity) {
      const proximityScore = Math.max(0, 40 - (distanceKm * 1.5));
      const capacity = ngo.capacity || 50;
      const capacityScore = capacity >= listing.quantity ? 30 : Math.round((capacity / listing.quantity) * 30);
      const areaMatch = (ngo.serviceAreas?.includes(listing.area) || isSameCity) ? 30 : 15;
      const totalScore = Math.round(proximityScore + capacityScore + areaMatch);

      matched.push({
        ngoId: ngo.id,
        ngoName: ngo.organizationName || ngo.name,
        phone: ngo.phone,
        city: ngo.city,
        area: ngo.area || ngo.city,
        distanceKm,
        capacity,
        score: totalScore
      });
    }
  }

  // Sort by highest score first, then by distance
  return matched.sort((a, b) => b.score - a.score || a.distanceKm - b.distanceKm);
}

// Pre-computed verified bcrypt password hashes:
// admin123:       $2b$10$hJrWfrBsN1c4R1sGr7mVKePUBRebxWfLCBulvn/zy7XZVQr2s74au
// restaurant123:  $2b$10$WYDIQZ6ifzKXHY2I6KImtecNRGo.FKOMCOU04xrrJ5/2mAWhtemCq
// ngo123:         $2b$10$U3AOl4/6jxR3gXHvBPkOxeJYMhfR3BUX6KGOskxKX2qgxZznxk9vq
// donor123:       $2b$10$LQ7FA3XKvqIwzkkqe210s.g6eTyuHLI7tIjL1iMiQlEWVriZX/LR6
// needy123:       $2b$10$fNCtI/8N8Y0j3Yj7JOKwqu2APOkhTjX.Nt0omD/INC9/ADwMFf942
// password123:    $2b$10$.ZZtuCQwb47CAylT7pAJRe6B5VlH53VJhU/az5IXvaCc7o8dfo0GG

const initialData: DatabaseSchema = {
  platformSettings: {
    distributionPeriodMode: 'Daily',
    maxMealsPerPeriodPerBeneficiary: 1,
    defaultCountry: 'Pakistan',
    maxMatchingRadiusKm: 25,
    availableProvinces: [
      'Punjab', 
      'Sindh', 
      'Khyber Pakhtunkhwa', 
      'Islamabad Capital Territory', 
      'Balochistan', 
      'Azad Jammu & Kashmir', 
      'Gilgit-Baltistan'
    ]
  },
  users: [
    // 1. Central Admin (Islamabad)
    {
      id: 'admin-1',
      name: 'PlateShare National Administrator',
      email: 'admin@plateshare.org',
      phone: '03001234567',
      password: '$2b$10$hJrWfrBsN1c4R1sGr7mVKePUBRebxWfLCBulvn/zy7XZVQr2s74au', // admin123
      role: 'Admin',
      country: 'Pakistan',
      province: 'Islamabad Capital Territory',
      city: 'Islamabad',
      area: 'Blue Area',
      address: 'PlateShare National Operations, Evacuee Trust Complex, Blue Area, Islamabad',
      coordinates: { lat: 33.7180, lng: 73.0600 },
      verificationStatus: 'Verified',
      createdAt: '2026-06-01T10:00:00.000Z'
    },

    // 2. Abbottabad (KPK)
    {
      id: 'rest-1',
      name: 'Al-Shiraz Restaurant',
      email: 'alshiraz@abbottabad.pk',
      phone: '03129876543',
      password: '$2b$10$WYDIQZ6ifzKXHY2I6KImtecNRGo.FKOMCOU04xrrJ5/2mAWhtemCq', // restaurant123
      role: 'Restaurant',
      country: 'Pakistan',
      province: 'Khyber Pakhtunkhwa',
      city: 'Abbottabad',
      area: 'Supply',
      address: 'Main Karakoram Highway, Supply Bazar, Abbottabad',
      coordinates: { lat: 34.1780, lng: 73.2280 },
      verificationStatus: 'Verified',
      operatingHours: '11:00 AM - 11:30 PM',
      contactPerson: 'Sardar Shiraz Ahmed',
      foodCategories: ['Biryani & Rice', 'Cooked Meals', 'Bread & Naan'],
      createdAt: '2026-06-10T10:00:00.000Z'
    },
    {
      id: 'ngo-1',
      name: 'Ehsaas Foundation Abbottabad',
      email: 'ehsaas@ngo.org.pk',
      phone: '03451122334',
      password: '$2b$10$U3AOl4/6jxR3gXHvBPkOxeJYMhfR3BUX6KGOskxKX2qgxZznxk9vq', // ngo123
      role: 'NGO',
      country: 'Pakistan',
      province: 'Khyber Pakhtunkhwa',
      city: 'Abbottabad',
      area: 'Jadoon Plaza',
      address: 'Suite 402, Jadoon Plaza Phase 2, Mandian, Abbottabad',
      coordinates: { lat: 34.1950, lng: 73.2410 },
      verificationStatus: 'Verified',
      organizationName: 'Ehsaas Foundation Abbottabad',
      registrationNumber: 'KPK-SWD-ATD-2024-089',
      capacity: 120,
      available: true,
      serviceAreas: ['Supply', 'Mandian', 'Jadoon Plaza', 'Cantt', 'Nawanshehr'],
      contactPerson: 'Qazi Farooq',
      createdAt: '2026-06-08T09:00:00.000Z'
    },
    {
      id: 'donor-1',
      name: 'Tariq Mehmood Khan',
      email: 'tariq.donor@gmail.com',
      phone: '03335566778',
      password: '$2b$10$LQ7FA3XKvqIwzkkqe210s.g6eTyuHLI7tIjL1iMiQlEWVriZX/LR6', // donor123
      role: 'Donor',
      country: 'Pakistan',
      province: 'Khyber Pakhtunkhwa',
      city: 'Abbottabad',
      area: 'PMA Kakul Road',
      address: 'House 14, PMA Kakul Road, Abbottabad',
      coordinates: { lat: 34.1880, lng: 73.2550 },
      verificationStatus: 'Verified',
      createdAt: '2026-06-15T11:00:00.000Z'
    },
    {
      id: 'ben-digital-1',
      name: 'Rashid Mehmood',
      email: 'rashid.beneficiary@gmail.com',
      phone: '03159988776',
      password: '$2b$10$fNCtI/8N8Y0j3Yj7JOKwqu2APOkhTjX.Nt0omD/INC9/ADwMFf942', // needy123
      role: 'Beneficiary',
      country: 'Pakistan',
      province: 'Khyber Pakhtunkhwa',
      city: 'Abbottabad',
      area: 'Supply',
      address: 'Mohallah Supply, Near Govt High School, Abbottabad',
      coordinates: { lat: 34.1750, lng: 73.2250 },
      verificationStatus: 'Verified',
      cnic: '13101-9876543-1',
      householdSize: 6,
      urgency: 'High',
      eligibilityStatus: 'Verified',
      hasSmartphone: true,
      createdAt: '2026-06-20T12:00:00.000Z'
    },

    // 3. Lahore (Punjab)
    {
      id: 'rest-lahore',
      name: 'Savour Foods Lahore',
      email: 'savour@lahore.pk',
      phone: '03211122334',
      password: '$2b$10$WYDIQZ6ifzKXHY2I6KImtecNRGo.FKOMCOU04xrrJ5/2mAWhtemCq', // restaurant123
      role: 'Restaurant',
      country: 'Pakistan',
      province: 'Punjab',
      city: 'Lahore',
      area: 'Gulberg',
      address: 'Main Boulevard, Gulberg III, Lahore',
      coordinates: { lat: 31.5204, lng: 74.3587 },
      verificationStatus: 'Verified',
      operatingHours: '12:00 PM - 1:00 AM',
      contactPerson: 'Mian Tariq',
      foodCategories: ['Biryani & Rice', 'Cooked Meals'],
      createdAt: '2026-06-12T10:00:00.000Z'
    },
    {
      id: 'ngo-lahore',
      name: 'Al-Khidmat Foundation Lahore',
      email: 'alkhidmat@lahore.ngo.pk',
      phone: '03214455667',
      password: '$2b$10$U3AOl4/6jxR3gXHvBPkOxeJYMhfR3BUX6KGOskxKX2qgxZznxk9vq', // ngo123
      role: 'NGO',
      country: 'Pakistan',
      province: 'Punjab',
      city: 'Lahore',
      area: 'Model Town',
      address: 'Al-Khidmat Complex, Block H, Model Town, Lahore',
      coordinates: { lat: 31.4850, lng: 74.3200 },
      verificationStatus: 'Verified',
      organizationName: 'Al-Khidmat Foundation Lahore',
      registrationNumber: 'PB-SW-LHR-2031',
      capacity: 350,
      available: true,
      serviceAreas: ['Gulberg', 'Model Town', 'Johar Town', 'DHA Phase 5'],
      contactPerson: 'Dr. Zafar Iqbal',
      createdAt: '2026-06-11T09:00:00.000Z'
    },

    // 4. Karachi (Sindh)
    {
      id: 'rest-karachi',
      name: 'Lal Qila Restaurant Karachi',
      email: 'lalqila@karachi.pk',
      phone: '03219876543',
      password: '$2b$10$WYDIQZ6ifzKXHY2I6KImtecNRGo.FKOMCOU04xrrJ5/2mAWhtemCq', // restaurant123
      role: 'Restaurant',
      country: 'Pakistan',
      province: 'Sindh',
      city: 'Karachi',
      area: 'PECHS',
      address: 'Main Shahrah-e-Faisal, PECHS Block 6, Karachi',
      coordinates: { lat: 24.8607, lng: 67.0600 },
      verificationStatus: 'Verified',
      operatingHours: '12:30 PM - 11:30 PM',
      contactPerson: 'Farhan Siddiqui',
      foodCategories: ['Cooked Meals', 'Biryani & Rice', 'Bakery'],
      createdAt: '2026-06-15T14:00:00.000Z'
    },
    {
      id: 'ngo-karachi',
      name: 'Saylani Welfare International',
      email: 'saylani@karachi.ngo.pk',
      phone: '03111222333',
      password: '$2b$10$U3AOl4/6jxR3gXHvBPkOxeJYMhfR3BUX6KGOskxKX2qgxZznxk9vq', // ngo123
      role: 'NGO',
      country: 'Pakistan',
      province: 'Sindh',
      city: 'Karachi',
      area: 'Bahadurabad',
      address: 'Saylani Head Office, 4th Floor, A-25, Bahadurabad, Karachi',
      coordinates: { lat: 24.8820, lng: 67.0690 },
      verificationStatus: 'Verified',
      organizationName: 'Saylani Welfare International',
      registrationNumber: 'SD-SW-KHI-0044',
      capacity: 800,
      available: true,
      serviceAreas: ['PECHS', 'Clifton', 'Gulshan-e-Iqbal', 'Saddar'],
      contactPerson: 'Maulana Bashir Farooqi',
      createdAt: '2026-06-05T08:00:00.000Z'
    },

    // 5. Peshawar (KPK)
    {
      id: 'rest-peshawar',
      name: 'Habibi Restaurant Peshawar',
      email: 'habibi@peshawar.pk',
      phone: '03009988776',
      password: '$2b$10$WYDIQZ6ifzKXHY2I6KImtecNRGo.FKOMCOU04xrrJ5/2mAWhtemCq', // restaurant123
      role: 'Restaurant',
      country: 'Pakistan',
      province: 'Khyber Pakhtunkhwa',
      city: 'Peshawar',
      area: 'University Road',
      address: 'Opposite Islamia College, University Road, Peshawar',
      coordinates: { lat: 34.0080, lng: 71.5300 },
      verificationStatus: 'Verified',
      operatingHours: '11:30 AM - 12:00 AM',
      contactPerson: 'Inam-ul-Haq',
      createdAt: '2026-06-19T09:00:00.000Z'
    }
  ],
  listings: [
    {
      id: 'listing-1',
      donorId: 'rest-1',
      donorName: 'Al-Shiraz Restaurant',
      donorRole: 'Restaurant',
      foodName: 'Chicken Biryani & Roghani Naan',
      foodCategory: 'Biryani & Rice',
      quantity: 30,
      unit: 'meals',
      description: 'Hygienically packed noon buffet surplus. 30 complete warm lunch boxes with chicken biryani, salad, and fresh roghani naan.',
      preparationTime: '1:00 PM Today',
      availableTime: '3:00 PM Today',
      pickupDeadline: '8:00 PM Today',
      storageCondition: 'Hot/Insulated',
      province: 'Khyber Pakhtunkhwa',
      city: 'Abbottabad',
      area: 'Supply',
      pickupAddress: 'Main Karakoram Highway, Supply Bazar, Abbottabad',
      coordinates: { lat: 34.1780, lng: 73.2280 },
      image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500&auto=format&fit=crop&q=60',
      status: 'Available',
      remainingQuantity: 30,
      allocatedQuantity: 0,
      createdAt: '2026-10-05T12:00:00.000Z'
    },
    {
      id: 'listing-lhr-1',
      donorId: 'rest-lahore',
      donorName: 'Savour Foods Lahore',
      donorRole: 'Restaurant',
      foodName: 'Chicken Pulao with Shami Kababs',
      foodCategory: 'Biryani & Rice',
      quantity: 50,
      unit: 'meals',
      description: 'Hot boxed meals from luncheon banquet. Fully sealed containers with fresh raita cups.',
      preparationTime: '1:30 PM Today',
      availableTime: '3:30 PM Today',
      pickupDeadline: '9:00 PM Today',
      storageCondition: 'Hot/Insulated',
      province: 'Punjab',
      city: 'Lahore',
      area: 'Gulberg',
      pickupAddress: 'Main Boulevard, Gulberg III, Lahore',
      coordinates: { lat: 31.5204, lng: 74.3587 },
      image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=500&auto=format&fit=crop&q=60',
      status: 'Available',
      remainingQuantity: 50,
      allocatedQuantity: 0,
      createdAt: '2026-10-05T12:30:00.000Z'
    },
    {
      id: 'listing-khi-1',
      donorId: 'rest-karachi',
      donorName: 'Lal Qila Restaurant Karachi',
      donorRole: 'Restaurant',
      foodName: 'Chicken Karahi, Taftan & Kheer Pots',
      foodCategory: 'Cooked Meals',
      quantity: 45,
      unit: 'meals',
      description: 'Fresh dinner buffet surplus. Handled with top hygiene standards, packed in insulated warm carriers.',
      preparationTime: '2:00 PM Today',
      availableTime: '4:00 PM Today',
      pickupDeadline: '10:00 PM Today',
      storageCondition: 'Hot/Insulated',
      province: 'Sindh',
      city: 'Karachi',
      area: 'PECHS',
      pickupAddress: 'Main Shahrah-e-Faisal, PECHS Block 6, Karachi',
      coordinates: { lat: 24.8607, lng: 67.0600 },
      image: 'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?w=500&auto=format&fit=crop&q=60',
      status: 'Available',
      remainingQuantity: 45,
      allocatedQuantity: 0,
      createdAt: '2026-10-05T13:00:00.000Z'
    }
  ],
  notifications: [
    {
      id: 'notif-1',
      userId: 'ngo-1',
      title: 'Surplus Food Posted in Abbottabad',
      message: 'Al-Shiraz Restaurant posted 30 meals of Chicken Biryani & Roghani Naan in Supply Bazar.',
      type: 'DONATION_MATCH',
      isRead: false,
      createdAt: '2026-10-05T12:05:00.000Z'
    }
  ],
  assistanceCases: [
    // Non-digital offline beneficiaries assisted by authorized NGOs
    {
      id: 'case-atd-1',
      name: 'Mohammad Shafi',
      phone: '03429811223',
      cnic: '13101-7654321-3',
      city: 'Abbottabad',
      area: 'Mandian',
      address: 'House 88, Mohallah Bilal, Mandian, Abbottabad',
      householdSize: 5,
      urgency: 'High',
      eligibilityStatus: 'Verified',
      hasSmartphone: false,
      registeredByNgoId: 'ngo-1',
      registeredByNgoName: 'Ehsaas Foundation Abbottabad',
      createdAt: '2026-06-25T10:00:00.000Z'
    },
    {
      id: 'case-lhr-1',
      name: 'Abdul Rehman',
      phone: '03224455889',
      cnic: '35201-1122334-5',
      city: 'Lahore',
      area: 'Model Town',
      address: 'Basti Qureshian, Katchi Abadi, Model Town, Lahore',
      householdSize: 7,
      urgency: 'High',
      eligibilityStatus: 'Verified',
      hasSmartphone: false,
      registeredByNgoId: 'ngo-lahore',
      registeredByNgoName: 'Al-Khidmat Foundation Lahore',
      createdAt: '2026-07-01T11:00:00.000Z'
    }
  ],
  distributions: [
    {
      id: 'dist-1',
      donationId: 'listing-1',
      foodName: 'Chicken Biryani & Roghani Naan',
      beneficiaryId: 'case-atd-1',
      beneficiaryName: 'Mohammad Shafi',
      volunteerId: 'ngo-1',
      volunteerName: 'Ehsaas Foundation Abbottabad',
      quantity: 5,
      city: 'Abbottabad',
      distributionPeriod: '2026-10-04',
      verificationMethod: 'Manual_NGO',
      timestamp: '2026-10-04T18:00:00.000Z',
      notes: 'Delivered directly to residence. Verified family headcount.'
    }
  ],
  allocations: [],
  sponsorships: [
    {
      id: 'spons-1',
      donorId: 'donor-1',
      donorName: 'Tariq Mehmood Khan',
      donorEmail: 'tariq.donor@gmail.com',
      amountPkr: 15000,
      mealsSponsored: 150,
      campaign: 'Pakistan National Hunger Relief Fund',
      city: 'Abbottabad',
      status: 'Allocated_To_Meals',
      allocatedDonationIds: ['listing-1', 'listing-lhr-1'],
      createdAt: '2026-10-04T16:00:00.000Z'
    }
  ],
  complaints: [
    {
      id: 'comp-1',
      reporterId: 'ngo-1',
      reporterName: 'Ehsaas Foundation Abbottabad',
      reporterRole: 'NGO',
      targetName: 'Pine View Continental',
      category: 'Food Quality',
      description: 'Packaging container seal was slightly torn during inspection.',
      city: 'Abbottabad',
      status: 'Resolved',
      adminNotes: 'Contacted restaurant management. They agreed to use tamper-evident foil covers.',
      createdAt: '2026-09-28T12:00:00.000Z'
    }
  ],
  auditLogs: [
    {
      id: 'audit-1',
      actorId: 'admin-1',
      actorName: 'PlateShare National Administrator',
      actorRole: 'Admin',
      action: 'PLATFORM_CONSOLIDATION',
      details: 'PlateShare authoritative database initialized with bcrypt-hashed credentials and privacy-preserving AssistanceCase schema.',
      timestamp: '2026-10-05T08:00:00.000Z'
    }
  ]
};

// In-memory mutex locks to prevent race conditions during concurrent requests
const activeAllocationLocks = new Set<string>();
const listingQuantityLocks = new Set<string>();

export function initDB(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
      return initialData;
    }
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    
    // Ensure all arrays and settings exist
    if (!parsed.users) parsed.users = initialData.users;
    if (!parsed.listings) parsed.listings = initialData.listings;
    if (!parsed.notifications) parsed.notifications = initialData.notifications;
    if (!parsed.assistanceCases) {
      // Migrate from old needyPeople if exists
      if (parsed.needyPeople) {
        parsed.assistanceCases = parsed.needyPeople.map((p: any) => ({
          id: p.id || `case-${Date.now()}`,
          name: p.name,
          phone: p.phone || 'N/A',
          cnic: p.cnic,
          city: p.city || 'Abbottabad',
          area: p.area || 'Supply',
          address: p.address || 'Local Area',
          householdSize: p.householdSize || 4,
          urgency: p.urgency || 'Medium',
          eligibilityStatus: p.eligibilityStatus || 'Verified',
          hasSmartphone: false,
          registeredByNgoId: p.addedBy || 'ngo-1',
          registeredByNgoName: 'Ehsaas Foundation Abbottabad',
          createdAt: p.createdAt || new Date().toISOString()
        }));
      } else {
        parsed.assistanceCases = initialData.assistanceCases;
      }
    }
    if (!parsed.distributions) parsed.distributions = initialData.distributions;
    if (!parsed.allocations) parsed.allocations = [];
    if (!parsed.sponsorships) parsed.sponsorships = initialData.sponsorships;
    if (!parsed.complaints) parsed.complaints = initialData.complaints;
    if (!parsed.platformSettings) parsed.platformSettings = initialData.platformSettings;
    if (!parsed.auditLogs) parsed.auditLogs = initialData.auditLogs;

    // Migrate any plaintext seed passwords to bcrypt hashes
    parsed.users = parsed.users.map((u: User) => {
      const initial = initialData.users.find(iu => iu.id === u.id || iu.email.toLowerCase() === u.email.toLowerCase());
      if (initial && initial.password && (!u.password || !u.password.startsWith('$2'))) {
        u.password = initial.password;
      }
      return u;
    });

    saveDB(parsed);
    return parsed;
  } catch (error) {
    console.error('Failed to initialize or read Plateshare DB:', error);
    return initialData;
  }
}

export function saveDB(data: DatabaseSchema): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (error) {
    console.error('Failed to write to Plateshare DB:', error);
  }
}

// -------------------------------------------------------------
// Data Access Operations (dbOps)
// -------------------------------------------------------------
export const dbOps = {
  // --- USERS ---
  getUsers: async (filters?: { role?: UserRole; city?: string; verificationStatus?: VerificationStatus }): Promise<User[]> => {
    const db = initDB();
    let result = db.users;
    if (filters?.role) result = result.filter(u => u.role === filters.role);
    if (filters?.city && filters.city !== 'All Cities') {
      result = result.filter(u => u.city.toLowerCase() === filters.city!.toLowerCase());
    }
    if (filters?.verificationStatus) {
      result = result.filter(u => u.verificationStatus === filters.verificationStatus);
    }
    return result;
  },

  getUserById: async (id: string): Promise<User | null> => {
    const db = initDB();
    const user = db.users.find(u => u.id === id);
    return user || null;
  },

  getUserByEmail: async (email: string): Promise<User | null> => {
    const db = initDB();
    const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    return user || null;
  },

  getUserByResetToken: async (token: string): Promise<User | null> => {
    const db = initDB();
    const now = new Date().toISOString();
    const user = db.users.find(u => 
      u.resetPasswordToken === token && 
      u.resetPasswordExpires && 
      u.resetPasswordExpires > now
    );
    return user || null;
  },

  createUser: async (user: User): Promise<User> => {
    const db = initDB();
    db.users.push(user);
    saveDB(db);
    return user;
  },

  updateUser: async (id: string, updates: Partial<User>): Promise<User | null> => {
    const db = initDB();
    const index = db.users.findIndex(u => u.id === id);
    if (index === -1) return null;
    
    // Protect role and verificationStatus from self-edit unless explicitly permitted
    db.users[index] = { ...db.users[index], ...updates };
    saveDB(db);
    return db.users[index];
  },

  deleteUser: async (id: string): Promise<boolean> => {
    const db = initDB();
    const initialLen = db.users.length;
    db.users = db.users.filter(u => u.id !== id);
    if (db.users.length !== initialLen) {
      saveDB(db);
      return true;
    }
    return false;
  },

  // --- FOOD LISTINGS ---
  getListings: async (filters?: { city?: string; province?: string; status?: DonationStatus }): Promise<FoodListing[]> => {
    const db = initDB();
    let result = db.listings;
    if (filters?.city && filters.city !== 'All Cities') {
      result = result.filter(l => l.city.toLowerCase() === filters.city!.toLowerCase());
    }
    if (filters?.province && filters.province !== 'All Provinces') {
      result = result.filter(l => l.province.toLowerCase() === filters.province!.toLowerCase());
    }
    if (filters?.status) {
      result = result.filter(l => l.status === filters.status);
    }
    return result;
  },

  getListingById: async (id: string): Promise<FoodListing | null> => {
    const db = initDB();
    const listing = db.listings.find(l => l.id === id);
    return listing || null;
  },

  getListingsByDonor: async (donorId: string): Promise<FoodListing[]> => {
    const db = initDB();
    return db.listings.filter(l => l.donorId === donorId);
  },

  getListingsClaimedByNgo: async (ngoId: string): Promise<FoodListing[]> => {
    const db = initDB();
    return db.listings.filter(l => l.claimedByNgoId === ngoId);
  },

  createListing: async (listing: FoodListing): Promise<FoodListing> => {
    const db = initDB();
    db.listings.unshift(listing);
    saveDB(db);
    return listing;
  },

  updateListing: async (id: string, updates: Partial<FoodListing>): Promise<FoodListing | null> => {
    const db = initDB();
    const index = db.listings.findIndex(l => l.id === id);
    if (index === -1) return null;
    db.listings[index] = { ...db.listings[index], ...updates, updatedAt: new Date().toISOString() };
    saveDB(db);
    return db.listings[index];
  },

  deleteListing: async (id: string): Promise<boolean> => {
    const db = initDB();
    const initialLen = db.listings.length;
    db.listings = db.listings.filter(l => l.id !== id);
    if (db.listings.length !== initialLen) {
      saveDB(db);
      return true;
    }
    return false;
  },

  // Atomic listing claim by verified NGO
  claimListingByNgo: async (listingId: string, ngoId: string, ngoName: string): Promise<{ success: boolean; listing?: FoodListing; error?: string }> => {
    const db = initDB();
    const listing = db.listings.find(l => l.id === listingId);
    
    if (!listing) return { success: false, error: 'Listing not found' };
    if (listing.status !== 'Available') {
      return { success: false, error: `This food donation cannot be claimed (current status: ${listing.status}).` };
    }

    listing.status = 'Accepted';
    listing.claimedByNgoId = ngoId;
    listing.claimedByNgoName = ngoName;
    listing.pickupStatus = 'Pending';
    listing.updatedAt = new Date().toISOString();

    // Create notification for the restaurant
    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: listing.donorId,
      title: 'Donation Accepted!',
      message: `${ngoName} accepted your food donation "${listing.foodName}". They will schedule pickup shortly.`,
      type: 'DONATION_ACCEPTED',
      isRead: false,
      createdAt: new Date().toISOString()
    });

    saveDB(db);
    return { success: true, listing };
  },

  // Schedule pickup & generate handover OTP
  schedulePickup: async (listingId: string, ngoId: string, scheduledTime?: string): Promise<{ success: boolean; listing?: FoodListing; otp?: string; error?: string }> => {
    const db = initDB();
    const listing = db.listings.find(l => l.id === listingId);
    if (!listing) return { success: false, error: 'Listing not found' };
    if (listing.claimedByNgoId !== ngoId) {
      return { success: false, error: 'Forbidden: Only the claiming NGO can schedule pickup' };
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    listing.status = 'Pickup_Scheduled';
    listing.pickupStatus = 'Scheduled';
    listing.pickupOtp = otp;
    listing.pickupScheduledTime = scheduledTime || new Date(Date.now() + 2 * 3600 * 1000).toISOString();
    listing.updatedAt = new Date().toISOString();

    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: listing.donorId,
      title: 'Food Pickup Scheduled',
      message: `${listing.claimedByNgoName} scheduled pickup for ${new Date(listing.pickupScheduledTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. Verification OTP generated.`,
      type: 'PICKUP_SCHEDULED',
      isRead: false,
      createdAt: new Date().toISOString()
    });

    saveDB(db);
    return { success: true, listing, otp };
  },

  // Verify handover OTP
  verifyPickupOtp: async (listingId: string, otp: string, verifierId: string): Promise<{ success: boolean; listing?: FoodListing; error?: string }> => {
    const db = initDB();
    const listing = db.listings.find(l => l.id === listingId);
    if (!listing) return { success: false, error: 'Listing not found' };

    if (listing.donorId !== verifierId && listing.claimedByNgoId !== verifierId) {
      return { success: false, error: 'Forbidden: Only the donating restaurant or authorized NGO can verify handover' };
    }

    if (listing.pickupOtp !== otp.trim()) {
      return { success: false, error: 'Invalid verification OTP. Please verify with the NGO driver.' };
    }

    listing.status = 'Picked_Up';
    listing.pickupStatus = 'Picked_Up';
    listing.updatedAt = new Date().toISOString();

    db.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId: listing.claimedByNgoId || '',
      title: 'Food Handover Completed',
      message: `Pickup verified by ${listing.donorName}. Ready for distribution to verified beneficiaries.`,
      type: 'PICKUP_VERIFIED',
      isRead: false,
      createdAt: new Date().toISOString()
    });

    saveDB(db);
    return { success: true, listing };
  },

  // --- ASSISTANCE CASES (OFFLINE BENEFICIARIES) ---
  getAssistanceCases: async (filters?: { ngoId?: string; city?: string }): Promise<AssistanceCase[]> => {
    const db = initDB();
    let cases = db.assistanceCases || [];
    if (filters?.ngoId) cases = cases.filter(c => c.registeredByNgoId === filters.ngoId);
    if (filters?.city && filters.city !== 'All Cities') {
      cases = cases.filter(c => c.city.toLowerCase() === filters.city!.toLowerCase());
    }
    return cases;
  },

  getAssistanceCaseById: async (id: string): Promise<AssistanceCase | null> => {
    const db = initDB();
    return (db.assistanceCases || []).find(c => c.id === id) || null;
  },

  getAssistanceCaseByCnic: async (cnic: string): Promise<AssistanceCase | null> => {
    const db = initDB();
    const clean = cnic.replace(/[-\s]/g, '');
    return (db.assistanceCases || []).find(c => c.cnic.replace(/[-\s]/g, '') === clean) || null;
  },

  createAssistanceCase: async (c: AssistanceCase): Promise<AssistanceCase> => {
    const db = initDB();
    if (!db.assistanceCases) db.assistanceCases = [];
    db.assistanceCases.push(c);
    saveDB(db);
    return c;
  },

  deleteAssistanceCase: async (id: string): Promise<boolean> => {
    const db = initDB();
    if (!db.assistanceCases) return false;
    const initialLen = db.assistanceCases.length;
    db.assistanceCases = db.assistanceCases.filter(c => c.id !== id);
    if (db.assistanceCases.length !== initialLen) {
      saveDB(db);
      return true;
    }
    return false;
  },

  // --- ALLOCATIONS WITH ATOMIC CONCURRENCY & QUANTITY INTEGRITY ---
  getAllocations: async (filters?: { beneficiaryId?: string; ngoId?: string; distributionPeriod?: string }): Promise<FoodAllocation[]> => {
    const db = initDB();
    let result = db.allocations || [];
    if (filters?.beneficiaryId) result = result.filter(a => a.beneficiaryId === filters.beneficiaryId);
    if (filters?.ngoId) result = result.filter(a => a.ngoId === filters.ngoId);
    if (filters?.distributionPeriod) result = result.filter(a => a.distributionPeriod === filters.distributionPeriod);
    return result;
  },

  // Atomic allocation creation with race-condition check & quantity deduction
  createAtomicAllocation: async (params: {
    donationId: string;
    ngoId: string;
    ngoName: string;
    beneficiaryId: string;
    beneficiaryName: string;
    quantity: number;
    city: string;
    periodKey: string;
    platformPeriodMode: string;
  }): Promise<{ success: boolean; allocation?: FoodAllocation; error?: string }> => {
    const lockKey = `${params.beneficiaryId}_${params.periodKey}`;

    // Mutex check: prevent concurrent requests from simultaneous allocation
    if (activeAllocationLocks.has(lockKey)) {
      return {
        success: false,
        error: `Conflict: Another food allocation request for this beneficiary in period ${params.periodKey} is currently processing.`
      };
    }

    activeAllocationLocks.add(lockKey);

    try {
      const db = initDB();
      if (!db.allocations) db.allocations = [];

      // 1. Check existing active allocation in the current period
      const existing = db.allocations.find(a => 
        a.beneficiaryId === params.beneficiaryId &&
        a.distributionPeriod === params.periodKey &&
        a.status !== 'Cancelled'
      );

      if (existing) {
        return {
          success: false,
          error: `Anti-Duplicate Protection: This beneficiary already has an active food allocation for this ${params.platformPeriodMode.toLowerCase()} distribution period (${params.periodKey}).`
        };
      }

      // 2. Quantity integrity check on the food donation
      const listing = db.listings.find(l => l.id === params.donationId);
      if (!listing) {
        return { success: false, error: 'Food donation listing not found' };
      }

      const availableMeals = listing.remainingQuantity !== undefined ? listing.remainingQuantity : listing.quantity;
      if (params.quantity > availableMeals) {
        return {
          success: false,
          error: `Quantity Overflow: Requested ${params.quantity} meals, but only ${availableMeals} meals are remaining in this donation.`
        };
      }

      // 3. Atomically decrement remaining quantity
      listing.remainingQuantity = availableMeals - params.quantity;
      listing.allocatedQuantity = (listing.allocatedQuantity || 0) + params.quantity;

      // 4. Generate 4-digit confirmation voucher OTP
      const otpCode = Math.floor(1000 + Math.random() * 9000).toString();

      const newAllocation: FoodAllocation = {
        id: `alloc-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        donationId: params.donationId,
        foodName: listing.foodName,
        ngoId: params.ngoId,
        ngoName: params.ngoName,
        beneficiaryId: params.beneficiaryId,
        beneficiaryName: params.beneficiaryName,
        quantity: params.quantity,
        city: params.city,
        distributionPeriod: params.periodKey,
        status: 'Active',
        otpCode,
        createdAt: new Date().toISOString()
      };

      db.allocations.push(newAllocation);
      saveDB(db);

      return { success: true, allocation: newAllocation };
    } finally {
      activeAllocationLocks.delete(lockKey);
    }
  },

  // Confirm receipt of allocation
  confirmAllocationReceipt: async (allocationId: string, verificationMethod: 'OTP' | 'QR' | 'Manual_NGO', staffMember?: string): Promise<{ success: boolean; allocation?: FoodAllocation; distribution?: FoodDistribution; error?: string }> => {
    const db = initDB();
    const allocation = (db.allocations || []).find(a => a.id === allocationId);
    if (!allocation) return { success: false, error: 'Allocation record not found' };

    if (allocation.status === 'Delivered') {
      return { success: false, error: 'This food allocation has already been confirmed as delivered' };
    }

    allocation.status = 'Delivered';
    allocation.deliveredAt = new Date().toISOString();
    allocation.verificationMethod = verificationMethod;
    allocation.staffMember = staffMember;

    // Record permanent distribution audit
    const newDist: FoodDistribution = {
      id: `dist-${Date.now()}`,
      allocationId: allocation.id,
      donationId: allocation.donationId,
      foodName: allocation.foodName,
      beneficiaryId: allocation.beneficiaryId,
      beneficiaryName: allocation.beneficiaryName,
      volunteerId: allocation.ngoId,
      volunteerName: allocation.ngoName,
      quantity: allocation.quantity,
      city: allocation.city,
      distributionPeriod: allocation.distributionPeriod,
      verificationMethod,
      timestamp: new Date().toISOString(),
      notes: `Verified receipt via ${verificationMethod} by ${staffMember || allocation.ngoName}`
    };

    if (!db.distributions) db.distributions = [];
    db.distributions.push(newDist);

    // If remaining quantity on listing reached 0, mark donation as Distributed / Completed
    const listing = db.listings.find(l => l.id === allocation.donationId);
    if (listing && listing.remainingQuantity === 0) {
      listing.status = 'Distributed';
      listing.updatedAt = new Date().toISOString();
    }

    saveDB(db);
    return { success: true, allocation, distribution: newDist };
  },

  // --- DISTRIBUTIONS ---
  getDistributions: async (filters?: { city?: string; ngoId?: string; beneficiaryId?: string }): Promise<FoodDistribution[]> => {
    const db = initDB();
    let result = db.distributions || [];
    if (filters?.city && filters.city !== 'All Cities') {
      result = result.filter(d => (d.city || '').toLowerCase() === filters.city!.toLowerCase());
    }
    if (filters?.ngoId) result = result.filter(d => d.volunteerId === filters.ngoId);
    if (filters?.beneficiaryId) result = result.filter(d => d.beneficiaryId === filters.beneficiaryId);
    return result;
  },

  createDistribution: async (dist: FoodDistribution): Promise<FoodDistribution> => {
    const db = initDB();
    if (!db.distributions) db.distributions = [];
    db.distributions.push(dist);
    saveDB(db);
    return dist;
  },

  // --- NOTIFICATIONS ---
  getNotifications: async (userId: string): Promise<Notification[]> => {
    const db = initDB();
    return (db.notifications || []).filter(n => n.userId === userId);
  },

  createNotification: async (n: Notification): Promise<Notification> => {
    const db = initDB();
    if (!db.notifications) db.notifications = [];
    db.notifications.unshift(n);
    saveDB(db);
    return n;
  },

  markNotificationAsRead: async (id: string): Promise<boolean> => {
    const db = initDB();
    const notif = (db.notifications || []).find(n => n.id === id);
    if (notif) {
      notif.isRead = true;
      saveDB(db);
      return true;
    }
    return false;
  },

  markAllNotificationsAsRead: async (userId: string): Promise<boolean> => {
    const db = initDB();
    let count = 0;
    (db.notifications || []).forEach(n => {
      if (n.userId === userId && !n.isRead) {
        n.isRead = true;
        count++;
      }
    });
    if (count > 0) saveDB(db);
    return true;
  },

  // --- DONOR SPONSORSHIPS ---
  getSponsorships: async (donorId?: string): Promise<DonorSponsorship[]> => {
    const db = initDB();
    let result = db.sponsorships || [];
    if (donorId) result = result.filter(s => s.donorId === donorId);
    return result;
  },

  createSponsorship: async (s: DonorSponsorship): Promise<DonorSponsorship> => {
    const db = initDB();
    if (!db.sponsorships) db.sponsorships = [];
    db.sponsorships.unshift(s);
    saveDB(db);
    return s;
  },

  // --- COMPLAINTS ---
  getComplaints: async (): Promise<Complaint[]> => {
    const db = initDB();
    return db.complaints || [];
  },

  createComplaint: async (c: Complaint): Promise<Complaint> => {
    const db = initDB();
    if (!db.complaints) db.complaints = [];
    db.complaints.unshift(c);
    saveDB(db);
    return c;
  },

  updateComplaint: async (id: string, updates: Partial<Complaint>): Promise<Complaint | null> => {
    const db = initDB();
    const c = (db.complaints || []).find(comp => comp.id === id);
    if (!c) return null;
    Object.assign(c, updates);
    saveDB(db);
    return c;
  },

  // --- PLATFORM SETTINGS ---
  getSettings: async (): Promise<PlatformSettings> => {
    const db = initDB();
    return db.platformSettings || initialData.platformSettings;
  },

  updateSettings: async (updates: Partial<PlatformSettings>): Promise<PlatformSettings> => {
    const db = initDB();
    db.platformSettings = { ...db.platformSettings, ...updates };
    saveDB(db);
    return db.platformSettings;
  },

  // --- AUDIT LOGS ---
  getAuditLogs: async (limit = 100): Promise<AuditLog[]> => {
    const db = initDB();
    return (db.auditLogs || []).slice(0, limit);
  },

  createAuditLog: async (log: { actorId: string; actorName: string; actorRole: UserRole; action: string; details: string; timestamp?: string }): Promise<AuditLog> => {
    const db = initDB();
    if (!db.auditLogs) db.auditLogs = [];
    const entry: AuditLog = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      actorId: log.actorId,
      actorName: log.actorName,
      actorRole: log.actorRole,
      action: log.action,
      details: log.details,
      timestamp: log.timestamp || new Date().toISOString()
    };
    db.auditLogs.unshift(entry);
    saveDB(db);
    return entry;
  },

  // Compatibility aliases
  getNeedyPeople: async (filters?: { ngoId?: string; city?: string }) => dbOps.getAssistanceCases(filters),
  getPlatformSettings: async () => dbOps.getSettings(),
  updatePlatformSettings: async (updates: Partial<PlatformSettings>) => dbOps.updateSettings(updates),
  updateComplaintStatus: async (id: string, status: string, adminNotes?: string) => dbOps.updateComplaint(id, { status: status as any, adminNotes }),
  getNotificationsByUserId: async (userId: string) => dbOps.getNotifications(userId),
  getSponsorshipsByDonor: async (donorId?: string) => dbOps.getSponsorships(donorId),
};
