export interface CityArea {
  name: string;
  lat: number;
  lng: number;
}

export interface CityData {
  name: string;
  province: string;
  district: string;
  lat: number;
  lng: number;
  areas: string[];
}

export interface ProvinceData {
  name: string;
  shortName: string;
  cities: CityData[];
}

export const PAKISTAN_PROVINCES: ProvinceData[] = [
  {
    name: 'Punjab',
    shortName: 'PB',
    cities: [
      {
        name: 'Lahore',
        province: 'Punjab',
        district: 'Lahore',
        lat: 31.5204,
        lng: 74.3587,
        areas: ['Gulberg', 'DHA Phase 5', 'Model Town', 'Johar Town', 'Mall Road', 'Cantt', 'Bahria Town']
      },
      {
        name: 'Rawalpindi',
        province: 'Punjab',
        district: 'Rawalpindi',
        lat: 33.5984,
        lng: 73.0441,
        areas: ['Saddar', 'Bahria Town Phase 4', 'Satellite Town', 'Westridge', 'Chaklala Scheme III']
      },
      {
        name: 'Faisalabad',
        province: 'Punjab',
        district: 'Faisalabad',
        lat: 31.4504,
        lng: 73.1350,
        areas: ['D Ground', 'Peoples Colony', 'Madina Town', 'Clock Tower Bazar', 'Kohinoor City']
      },
      {
        name: 'Multan',
        province: 'Punjab',
        district: 'Multan',
        lat: 30.1575,
        lng: 71.5249,
        areas: ['Gulgasht Colony', 'Cantt', 'Shah Rukn-e-Alam', 'Bosan Road', 'New Multan']
      },
      {
        name: 'Gujranwala',
        province: 'Punjab',
        district: 'Gujranwala',
        lat: 32.1877,
        lng: 74.1945,
        areas: ['Model Town', 'DC Colony', 'Rahwali Cantt', 'Peoples Colony', 'Wapda Town']
      },
      {
        name: 'Sialkot',
        province: 'Punjab',
        district: 'Sialkot',
        lat: 32.4945,
        lng: 74.5229,
        areas: ['Cantt', 'Paris Road', 'Model Town', 'Small Industrial Estate', 'Ugoki']
      }
    ]
  },
  {
    name: 'Sindh',
    shortName: 'SD',
    cities: [
      {
        name: 'Karachi',
        province: 'Sindh',
        district: 'Karachi Central',
        lat: 24.8607,
        lng: 67.0011,
        areas: ['Clifton', 'DHA Phase 6', 'Gulshan-e-Iqbal', 'PECHS', 'North Nazimabad', 'Saddar', 'Bahria Town Karachi']
      },
      {
        name: 'Hyderabad',
        province: 'Sindh',
        district: 'Hyderabad',
        lat: 25.3960,
        lng: 68.3578,
        areas: ['Latifabad Unit 7', 'Qasimabad', 'Saddar Bazar', 'Auto Bhan Road', 'Citizen Colony']
      },
      {
        name: 'Sukkur',
        province: 'Sindh',
        district: 'Sukkur',
        lat: 27.7052,
        lng: 68.8574,
        areas: ['Military Road', 'Minara Road', 'Barrage Colony', 'Shikarpur Road']
      },
      {
        name: 'Larkana',
        province: 'Sindh',
        district: 'Larkana',
        lat: 27.5590,
        lng: 68.2120,
        areas: ['VIP Road', 'Resham Gali', 'Station Road', 'Bakrani Road']
      }
    ]
  },
  {
    name: 'Khyber Pakhtunkhwa',
    shortName: 'KP',
    cities: [
      {
        name: 'Peshawar',
        province: 'Khyber Pakhtunkhwa',
        district: 'Peshawar',
        lat: 34.0151,
        lng: 71.5249,
        areas: ['Hayatabad Phase 3', 'University Town', 'Peshawar Cantt', 'Saddar', 'Ring Road', 'Gulbahar']
      },
      {
        name: 'Abbottabad',
        province: 'Khyber Pakhtunkhwa',
        district: 'Abbottabad',
        lat: 34.1688,
        lng: 73.2215,
        areas: ['Supply', 'Mandian', 'Jadoon Plaza', 'Cantt', 'PMA Kakul Road', 'Nawanshehr', 'City Center']
      },
      {
        name: 'Mardan',
        province: 'Khyber Pakhtunkhwa',
        district: 'Mardan',
        lat: 34.1989,
        lng: 72.0450,
        areas: ['Sheikh Maltoon Town', 'Bagh-e-Iram', 'Mardan Cantt', 'Bank Road']
      },
      {
        name: 'Swat',
        province: 'Khyber Pakhtunkhwa',
        district: 'Swat',
        lat: 34.7717,
        lng: 72.3602,
        areas: ['Saidu Sharif', 'Mingora Bazar', 'Makanbagh', 'Fizagat']
      },
      {
        name: 'Haripur',
        province: 'Khyber Pakhtunkhwa',
        district: 'Haripur',
        lat: 33.9993,
        lng: 72.9341,
        areas: ['Main Bazar', 'Model Town', 'Circular Road', 'Sikanderpur']
      },
      {
        name: 'Mansehra',
        province: 'Khyber Pakhtunkhwa',
        district: 'Mansehra',
        lat: 34.3302,
        lng: 73.1968,
        areas: ['Karakoram Highway', 'Shinkiari Road', 'College Road', 'Daffar']
      },
      {
        name: 'Nowshera',
        province: 'Khyber Pakhtunkhwa',
        district: 'Nowshera',
        lat: 34.0153,
        lng: 71.9747,
        areas: ['Nowshera Cantt', 'Risalpur', 'Pabbi Bazar', 'Shobra']
      }
    ]
  },
  {
    name: 'Islamabad Capital Territory',
    shortName: 'ICT',
    cities: [
      {
        name: 'Islamabad',
        province: 'Islamabad Capital Territory',
        district: 'Islamabad',
        lat: 33.6844,
        lng: 73.0479,
        areas: ['F-6 / Super Market', 'F-7 / Jinnah Super', 'F-8 Markaz', 'G-9 Markaz', 'G-11 Markaz', 'Blue Area', 'I-8 Markaz', 'DHA Phase 2']
      }
    ]
  },
  {
    name: 'Balochistan',
    shortName: 'BA',
    cities: [
      {
        name: 'Quetta',
        province: 'Balochistan',
        district: 'Quetta',
        lat: 30.1798,
        lng: 66.9750,
        areas: ['Quetta Cantt', 'Jinnah Road', 'Zarghoon Road', 'Satellite Town', 'Chaman Phatak']
      }
    ]
  },
  {
    name: 'Azad Jammu & Kashmir',
    shortName: 'AJK',
    cities: [
      {
        name: 'Muzaffarabad',
        province: 'Azad Jammu & Kashmir',
        district: 'Muzaffarabad',
        lat: 34.3700,
        lng: 73.4708,
        areas: ['Medina Market', 'Upper Chattar', 'Plate Area', 'Neelum Road']
      },
      {
        name: 'Mirpur',
        province: 'Azad Jammu & Kashmir',
        district: 'Mirpur',
        lat: 33.1478,
        lng: 73.7519,
        areas: ['Sector F-1', 'Allama Iqbal Road', 'New City', 'Chowk Shaheedan']
      }
    ]
  },
  {
    name: 'Gilgit-Baltistan',
    shortName: 'GB',
    cities: [
      {
        name: 'Gilgit',
        province: 'Gilgit-Baltistan',
        district: 'Gilgit',
        lat: 35.9221,
        lng: 74.3087,
        areas: ['Jutial', 'River View Road', 'Airport Road', 'Nagar Road']
      },
      {
        name: 'Skardu',
        province: 'Gilgit-Baltistan',
        district: 'Skardu',
        lat: 35.2974,
        lng: 75.6337,
        areas: ['Hameed Garh', 'College Road', 'Yadgar Chowk', 'Gambas']
      }
    ]
  }
];

export const ALL_PAKISTAN_CITIES: CityData[] = PAKISTAN_PROVINCES.flatMap(p => p.cities);

export function getCityDetails(cityName: string): CityData | undefined {
  if (!cityName) return undefined;
  const clean = cityName.trim().toLowerCase();
  return ALL_PAKISTAN_CITIES.find(c => c.name.toLowerCase() === clean);
}

export function getCoordinatesForCity(cityName: string): { lat: number; lng: number } {
  const city = getCityDetails(cityName);
  if (city) return { lat: city.lat, lng: city.lng };
  return { lat: 33.6844, lng: 73.0479 };
}
